import sys
from PIL import Image
out=sys.argv[1]; fs=sys.argv[2:]; n=len(fs); cols=2 if n<=4 else 3; rows=(n+cols-1)//cols; S=600
c=Image.new('RGB',(cols*S,rows*S))
for i,f in enumerate(fs): c.paste(Image.open(f).resize((S,S)),((i%cols)*S,(i//cols)*S))
c.save(out)
