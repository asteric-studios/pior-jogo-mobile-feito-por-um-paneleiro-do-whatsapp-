"""Runtime animation model (mirrored 1:1 in Rust src/anim.rs)."""
import numpy as np, sys; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from qm import *
import rig
NB=len(rig.NAMES); IDX=rig.IDX; PAR=rig.PAR
T0=np.array([rig.BIND[i]-(rig.BIND[PAR[i]] if PAR[i]>=0 else 0) for i in range(NB)])
S2=IDX['Spine2']
LOWER=[IDX[n] for n in ['Hips','RightUpLeg','RightLeg','RightFoot','RightToeBase','LeftUpLeg','LeftLeg','LeftFoot','LeftToeBase']]
UPPER=[i for i in range(NB) if i not in LOWER]
class Pose:
    def __init__(s):
        s.rot=np.tile(q(),(NB,1)); s.hips=rig.BIND[0].copy()
        s.wpos=np.zeros(3); s.wrot=q(); s.mpos=np.zeros(3); s.mrot=q(); s.ikl=1.0; s.ikr=1.0; s.aimw=1.0; s.aimoff=0.0
    def copy(s):
        p=Pose(); p.__dict__={k:(v.copy() if isinstance(v,np.ndarray) else v) for k,v in s.__dict__.items()}; return p
def fk(p):
    Gr=np.zeros((NB,4)); Gp=np.zeros((NB,3))
    for i in range(NB):
        if PAR[i]<0: Gr[i]=p.rot[i]; Gp[i]=p.hips
        else:
            pa=PAR[i]; Gp[i]=Gp[pa]+qrot(Gr[pa],T0[i]); Gr[i]=qmul(Gr[pa],p.rot[i])
    Wp=Gp[S2]+qrot(Gr[S2],p.wpos); Wr=qmul(Gr[S2],p.wrot)
    return Gr,Gp,Wp,Wr
def hinge_axis(ia,ib,flex):
    d1=T0[ib]/np.linalg.norm(T0[ib]); h=np.cross(d1,flex); return d1,h/np.linalg.norm(h)
def ik2(p,ia,ib,ic,tp,tr,pole,flex,w=1.0):
    """IK anatomico de duas juntas: o membro superior e orientado pelo plano (ombro,cotovelo,pulso)
    e a junta do meio dobra so no eixo de dobradica (sem torcao acumulada)."""
    if w<=0: return
    Gr,Gp,_,_=fk(p)
    A,B=Gp[ia],Gp[ib]
    l1=np.linalg.norm(T0[ib]); l2=np.linalg.norm(T0[ic])
    d=tp-A; dist=np.linalg.norm(d); u=d/max(dist,1e-6); dist=np.clip(dist,abs(l1-l2)+1e-3,(l1+l2)*0.9999)
    v=pole-np.dot(pole,u)*u
    if np.linalg.norm(v)<1e-6: v=(B-A)-np.dot(B-A,u)*u
    if np.linalg.norm(v)<1e-6: v=np.cross(u,[1.0,0,0])
    v=v/np.linalg.norm(v)
    ca=np.clip((l1*l1+dist*dist-l2*l2)/(2*l1*dist),-1,1); sa=np.sqrt(1-ca*ca)
    E=A+u*l1*ca+v*l1*sa
    d1b,hb=hinge_axis(ia,ib,flex)
    d1=(E-A)/l1; n=np.cross(v,u); n=n-np.dot(n,d1)*d1; n/=np.linalg.norm(n)
    Ra=qmul(qfrombasis(d1,n,np.cross(d1,n)),qconj(qfrombasis(d1b,hb,np.cross(d1b,hb))))
    tgt=A+u*dist
    fl=qrot(qconj(Ra),(tgt-E)/np.linalg.norm(tgt-E))
    lb=qfromto(T0[ic]/l2,fl)
    Gb=qmul(Ra,lb)
    na=qmul(qconj(Gr[PAR[ia]]),Ra); nc=qmul(qconj(Gb),tr)
    p.rot[ia]=qslerp(p.rot[ia],na,w); p.rot[ib]=qslerp(p.rot[ib],lb,w); p.rot[ic]=qslerp(p.rot[ic],nc,w)
ARM_FLEX=np.array([0,0,1.0]); LEG_FLEX=np.array([0,0,-1.0])
def apply_twist(p):
    """Distribui a torcao do pulso (pronacao/supinacao) pelos ossos de twist do antebraco."""
    for s in ('Right','Left'):
        h=IDX[s+'Hand']; ax=T0[h]/np.linalg.norm(T0[h])
        _,tw=swing_twist(p.rot[h],ax)
        if tw[3]<0: tw=-tw
        p.rot[IDX[s+'ForeArmTwist1']]=qpow(tw,1/3); p.rot[IDX[s+'ForeArmTwist2']]=qpow(tw,2/3)
def pre_rotate_chain(p,bones,qtot):
    qs=qpow(qtot,1.0/len(bones))
    for b in bones:
        Gr,_,_,_=fk(p); p.rot[b]=qmul(qconj(Gr[PAR[b]]),qmul(qs,Gr[b]))
SPINE=[IDX['Spine'],IDX['Spine1'],IDX['Spine2']]
def aim_correct(p,desired,w):
    if w<=0: return
    for _ in range(2):
        _,_,_,Wr=fk(p); f=qrot(Wr,np.array([0,0,1.0]))
        pre_rotate_chain(p,SPINE,qpow(qfromto(f,desired),w))
def head_look(p,desired,w):
    if w<=0: return
    Gr,_,_,_=fk(p); f=qrot(Gr[IDX['Head']],np.array([0,0,1.0]))
    pre_rotate_chain(p,[IDX['Neck'],IDX['Head']],qpow(qfromto(f,desired),w))
# ---- hand grip frames (hand bone transform expressed in Weapon space) ----
def hand_bind_axes(side):
    h=IDX[side+'Hand']; f=IDX[side+'Fingers']
    d=rig.BIND[f]-rig.BIND[h]; d/=np.linalg.norm(d); pl=np.array([0,-1.0,0]); pl=pl-np.dot(pl,d)*d; pl/=np.linalg.norm(pl)
    return d,pl
def hand_frame(side,palm_point,d_t,p_t,palm_off=0.05,thick=0.018):
    d_b,p_b=hand_bind_axes(side)
    d_t=np.asarray(d_t,float); d_t/=np.linalg.norm(d_t); p_t=np.asarray(p_t,float); p_t=p_t-np.dot(p_t,d_t)*d_t; p_t/=np.linalg.norm(p_t)
    Bb=np.array([d_b,p_b,np.cross(d_b,p_b)]).T; Bt=np.array([d_t,p_t,np.cross(d_t,p_t)]).T
    R=Bt@Bb.T; r=qfrombasis(R[:,0],R[:,1],R[:,2])
    wrist=np.asarray(palm_point,float)-qrot(r,d_b*palm_off+p_b*thick)
    return wrist,r
POLE_R=np.array([-0.6,-1.0,-0.25]); POLE_L=np.array([0.5,-1.0,-0.2])
def arm_ik(p,grips,wr=1.0,wl=None):
    _,_,Wp,Wr=fk(p)
    (rp,rr),(lp,lr)=grips
    if wl is None: wl=p.ikl
    def tf(pp,rr): return Wp+qrot(Wr,pp), qmul(Wr,rr)
    Gr,_,_,_=fk(p); hipr=Gr[IDX['Spine2']]
    tp,tr=tf(rp,rr); ik2(p,IDX['RightArm'],IDX['RightForeArm'],IDX['RightHand'],tp,tr,qrot(hipr,POLE_R),ARM_FLEX,wr)
    tp,tr=tf(lp,lr); ik2(p,IDX['LeftArm'],IDX['LeftForeArm'],IDX['LeftHand'],tp,tr,qrot(hipr,POLE_L),ARM_FLEX,wl)
