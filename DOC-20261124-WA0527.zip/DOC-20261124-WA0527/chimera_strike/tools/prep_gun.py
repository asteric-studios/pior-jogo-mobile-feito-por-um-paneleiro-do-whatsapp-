# Normalize Howa Type 20: meters, +Z muzzle, +Y up, origin on bore axis; downscale textures.
import sys,io,json,numpy as np; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); from gltfio import *
from PIL import Image
S=0.00209; BORE_Z=112.7
R=np.array([[0,-1,0],[0,0,1],[-1,0,0]],float)  # raw->rifle
ORIGIN=np.array([0.0,0,BORE_Z])
def load_gun(texsize=1024):
    j,b=readglb(__import__('os').environ.get('GUN_GLB','source_models/howa_type_20.glb'))
    prims=[]
    for me in j['meshes']:
        for p in me['primitives']:
            a=p['attributes']; d={}
            d['POSITION']=((acc(j,b,a['POSITION'])-ORIGIN)@R.T*S).astype(np.float32)
            d['NORMAL']=(acc(j,b,a['NORMAL'])@R.T).astype(np.float32)
            if 'TANGENT' in a:
                t=acc(j,b,a['TANGENT']); t[:,:3]=t[:,:3]@R.T; d['TANGENT']=t.astype(np.float32)
            d['TEXCOORD_0']=acc(j,b,a['TEXCOORD_0']).astype(np.float32)
            idx=acc(j,b,p['indices']).reshape(-1).astype(np.uint32)
            prims.append((d,idx,p['material']))
    imgs=[]
    for im in j['images']:
        raw=bvbytes(j,b,im['bufferView']); I=Image.open(io.BytesIO(raw)); I.load()
        if max(I.size)>texsize: I=I.resize((texsize,texsize) if I.size[0]==I.size[1] else (min(texsize,I.size[0]),min(texsize,I.size[1])),Image.LANCZOS)
        out=io.BytesIO()
        if im['mimeType']=='image/jpeg' or I.mode=='RGB':
            I.convert('RGB').save(out,'JPEG',quality=88); mime='image/jpeg'
        else: I.save(out,'PNG',optimize=True); mime='image/png'
        imgs.append((out.getvalue(),mime,I.size))
    return prims,j['materials'],j['textures'],imgs
def add_gun(w,parent_children,texsize=1024,skip_mats=()):
    prims,mats,texs,imgs=load_gun(texsize)
    tex_map={}
    for ti,t in enumerate(texs):
        data,mime,_=imgs[t['source']]; tex_map[ti]=w.image(data,mime)
    mat_base=len(w.j['materials'])
    for m in mats:
        m=json.loads(json.dumps(m))
        def fix(o):
            if isinstance(o,dict):
                for k,v in o.items():
                    if k=='index' and isinstance(v,int): o[k]=tex_map[v]
                    else: fix(v)
        fix(m); m['doubleSided']=False if m.get('alphaMode')!='BLEND' else True
        w.j['materials'].append(m)
    gprims=[]; mprims=[]; groups={'Attachment':[],'Scope':[],'ScopeGlass':[]}
    MAGP=np.array([0,-0.072,0.032],np.float32)
    for d,idx,mat in prims:
        if mat in skip_mats: continue
        if mat in (2,3,4,5):
            key={2:'Attachment',3:'Attachment',4:'Scope',5:'ScopeGlass'}[mat]
            groups[key].append(_prim(w,d,idx,mat_base+mat)); continue
        P=d['POSITION']; tri=idx.reshape(-1,3); c=P[tri].mean(1)
        inmag=(c[:,1]<-0.074)&(c[:,2]>-0.024)&(c[:,2]<0.083)&(np.abs(c[:,0])<0.03)&(P[tri][:,:,1].max(1)<-0.066)
        for sel,lst,off in ((~inmag,gprims,np.zeros(3,np.float32)),(inmag,mprims,MAGP)):
            if sel.sum()==0: continue
            t=tri[sel]; used,inv=np.unique(t.reshape(-1),return_inverse=True)
            dd={k:v[used] for k,v in d.items()}; dd['POSITION']=dd['POSITION']-off
            lst.append(_prim(w,dd,inv.astype(np.uint32),mat_base+mat))
    w.j['meshes'].append({'name':'Howa20','primitives':gprims})
    w.j['nodes'].append({'name':'Howa20_mesh','mesh':len(w.j['meshes'])-1})
    parent_children.append(len(w.j['nodes'])-1)
    for key,pr in groups.items():
        if not pr: continue
        w.j['meshes'].append({'name':'Howa20_'+key,'primitives':pr})
        w.j['nodes'].append({'name':key,'mesh':len(w.j['meshes'])-1})
        parent_children.append(len(w.j['nodes'])-1)
    w.j['meshes'].append({'name':'Howa20_mag','primitives':mprims})
    w.j['nodes'].append({'name':'MagMesh','mesh':len(w.j['meshes'])-1})
    w.j['nodes'].append({'name':'Magazine','translation':[float(x) for x in MAGP],'children':[len(w.j['nodes'])-1]})
    parent_children.append(len(w.j['nodes'])-1)
    allp=np.concatenate([d['POSITION'] for d,_,_ in prims]); return allp
def _prim(w,d,idx,mat):
    if True:
        attrs={}
        attrs['POSITION']=w.accessor(d['POSITION'],5126,'VEC3',34962,minmax=True)
        attrs['NORMAL']=w.accessor(d['NORMAL'],5126,'VEC3',34962)
        if 'TANGENT' in d: attrs['TANGENT']=w.accessor(d['TANGENT'],5126,'VEC4',34962)
        attrs['TEXCOORD_0']=w.accessor(d['TEXCOORD_0'],5126,'VEC2',34962)
        ia=w.accessor(idx,5125,'SCALAR',34963)
        return {'attributes':attrs,'indices':ia,'material':mat}
if __name__=='__main__':
    w=Writer(); root={'name':'root','children':[]}; w.j['nodes'].append(root); w.j['scenes'][0]['nodes']=[0]
    P=add_gun(w,root['children'],512); print(P.min(0),P.max(0)); w.save('work/gun_norm.glb')
