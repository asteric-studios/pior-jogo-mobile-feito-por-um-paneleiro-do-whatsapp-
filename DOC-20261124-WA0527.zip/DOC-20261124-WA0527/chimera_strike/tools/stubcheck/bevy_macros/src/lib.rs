use proc_macro::{TokenStream, TokenTree, Delimiter};
fn name_and_tuple(input: TokenStream) -> (String, Option<String>) {
    let toks: Vec<TokenTree> = input.into_iter().collect();
    let mut i = 0;
    while i < toks.len() {
        if let TokenTree::Ident(id) = &toks[i] {
            let s = id.to_string();
            if s == "struct" || s == "enum" {
                let name = toks[i + 1].to_string();
                let mut field = None;
                if let Some(TokenTree::Group(g)) = toks.get(i + 2) {
                    if g.delimiter() == Delimiter::Parenthesis {
                        let inner: Vec<String> = g.stream().into_iter().map(|t| t.to_string()).filter(|t| t != "pub").collect();
                        field = Some(inner.join(" "));
                    }
                }
                return (name, field);
            }
        }
        i += 1;
    }
    panic!("no struct/enum")
}
fn imp(input: TokenStream, tr: &str) -> TokenStream {
    let (n, _) = name_and_tuple(input);
    format!("impl ::bevy::{tr} for {n} {{}}").parse().unwrap()
}
#[proc_macro_derive(Component)]
pub fn d_component(i: TokenStream) -> TokenStream { imp(i, "ecs::Component") }
#[proc_macro_derive(Resource)]
pub fn d_resource(i: TokenStream) -> TokenStream { imp(i, "ecs::Resource") }
#[proc_macro_derive(Event)]
pub fn d_event(i: TokenStream) -> TokenStream { imp(i, "ecs::Event") }
#[proc_macro_derive(SystemSet)]
pub fn d_set(i: TokenStream) -> TokenStream { imp(i, "ecs::SystemSet") }
#[proc_macro_derive(Deref)]
pub fn d_deref(i: TokenStream) -> TokenStream {
    let (n, f) = name_and_tuple(i);
    let f = f.expect("Deref needs tuple struct");
    format!("impl ::std::ops::Deref for {n} {{ type Target = {f}; fn deref(&self) -> &{f} {{ &self.0 }} }}").parse().unwrap()
}
#[proc_macro_attribute]
pub fn bevy_main(_a: TokenStream, item: TokenStream) -> TokenStream { item }
