#![allow(dead_code, unused_variables, clippy::all)]
//! Dublê de tipos do Bevy 0.14 (apenas assinaturas) para checagem de tipos offline.
use std::marker::PhantomData;
use std::ops::{Deref, DerefMut};
pub use bevy_macros::*;
fn u<T>() -> T { unimplemented!() }

pub mod math {
    pub use glam::*;
    #[derive(Clone, Copy, Debug)]
    pub struct Dir3(pub Vec3);
    impl std::ops::Deref for Dir3 { type Target = Vec3; fn deref(&self) -> &Vec3 { &self.0 } }
    impl std::ops::Neg for Dir3 { type Output = Dir3; fn neg(self) -> Dir3 { Dir3(-self.0) } }
    pub mod primitives {
        pub struct Cuboid; impl Cuboid { pub fn new(x: f32, y: f32, z: f32) -> Self { Cuboid } }
        pub struct Cylinder; impl Cylinder { pub fn new(r: f32, h: f32) -> Self { Cylinder } }
        pub struct Circle; impl Circle { pub fn new(r: f32) -> Self { Circle } }
        pub struct Rectangle; impl Rectangle { pub fn new(w: f32, h: f32) -> Self { Rectangle } }
    }
}
use math::*;

// ======================================================================= ECS
pub mod ecs {
    use super::*;
    pub trait Component: Send + Sync + 'static {}
    pub trait Resource: Send + Sync + 'static {}
    pub trait Event: Send + Sync + 'static {}
    pub trait SystemSet: Send + Sync + 'static {}
    #[derive(Clone, Copy, PartialEq, Eq, Hash, Debug, PartialOrd, Ord)]
    pub struct Entity(u64);
    impl Entity { pub const PLACEHOLDER: Entity = Entity(u64::MAX); }

    pub struct Mut<'w, T: ?Sized>(&'w mut T);
    impl<'w, T: ?Sized> Deref for Mut<'w, T> { type Target = T; fn deref(&self) -> &T { self.0 } }
    impl<'w, T: ?Sized> DerefMut for Mut<'w, T> { fn deref_mut(&mut self) -> &mut T { self.0 } }
    impl<'w, T: ?Sized> AsMut<T> for Mut<'w, T> { fn as_mut(&mut self) -> &mut T { self.0 } }

    pub trait QueryData { type Item<'w>; type ReadItem<'w>; }
    impl<T: Component> QueryData for &T { type Item<'w> = &'w T; type ReadItem<'w> = &'w T; }
    impl<T: Component> QueryData for &mut T { type Item<'w> = Mut<'w, T>; type ReadItem<'w> = &'w T; }
    impl QueryData for Entity { type Item<'w> = Entity; type ReadItem<'w> = Entity; }
    impl QueryData for () { type Item<'w> = (); type ReadItem<'w> = (); }
    impl<T: QueryData> QueryData for Option<T> { type Item<'w> = Option<T::Item<'w>>; type ReadItem<'w> = Option<T::ReadItem<'w>>; }
    macro_rules! qd_tuple { ($($n:ident),*) => {
        impl<$($n: QueryData),*> QueryData for ($($n,)*) { type Item<'w> = ($($n::Item<'w>,)*); type ReadItem<'w> = ($($n::ReadItem<'w>,)*); }
    } }
    qd_tuple!(A); qd_tuple!(A, B); qd_tuple!(A, B, C); qd_tuple!(A, B, C, D); qd_tuple!(A, B, C, D, E);
    qd_tuple!(A, B, C, D, E, F); qd_tuple!(A, B, C, D, E, F, G); qd_tuple!(A, B, C, D, E, F, G, H);

    pub trait QueryFilter {}
    pub struct With<T>(PhantomData<T>);
    pub struct Without<T>(PhantomData<T>);
    pub struct Added<T>(PhantomData<T>);
    pub struct Changed<T>(PhantomData<T>);
    impl QueryFilter for () {}
    impl<T: Component> QueryFilter for With<T> {}
    impl<T: Component> QueryFilter for Without<T> {}
    impl<T: Component> QueryFilter for Added<T> {}
    impl<T: Component> QueryFilter for Changed<T> {}
    macro_rules! qf_tuple { ($($n:ident),*) => { impl<$($n: QueryFilter),*> QueryFilter for ($($n,)*) {} } }
    qf_tuple!(A); qf_tuple!(A, B); qf_tuple!(A, B, C);

    #[derive(Debug)] pub struct QueryEntityError;
    #[derive(Debug)] pub struct QuerySingleError;
    pub struct Query<'w, 's, D: QueryData, F: QueryFilter = ()>(PhantomData<(&'w (), &'s (), D, F)>);
    impl<'w, 's, D: QueryData, F: QueryFilter> Query<'w, 's, D, F> {
        pub fn iter(&self) -> std::vec::IntoIter<D::ReadItem<'_>> { u() }
        pub fn iter_mut(&mut self) -> std::vec::IntoIter<D::Item<'_>> { u() }
        pub fn get(&self, e: Entity) -> Result<D::ReadItem<'_>, QueryEntityError> { u() }
        pub fn get_mut(&mut self, e: Entity) -> Result<D::Item<'_>, QueryEntityError> { u() }
        pub fn get_single(&self) -> Result<D::ReadItem<'_>, QuerySingleError> { u() }
        pub fn get_single_mut(&mut self) -> Result<D::Item<'_>, QuerySingleError> { u() }
        pub fn single(&self) -> D::ReadItem<'_> { u() }
        pub fn single_mut(&mut self) -> D::Item<'_> { u() }
        pub fn is_empty(&self) -> bool { u() }
    }
    pub struct Res<'w, T: Resource>(&'w T);
    impl<'w, T: Resource> Deref for Res<'w, T> { type Target = T; fn deref(&self) -> &T { self.0 } }
    pub struct ResMut<'w, T: Resource>(&'w mut T);
    impl<'w, T: Resource> Deref for ResMut<'w, T> { type Target = T; fn deref(&self) -> &T { self.0 } }
    impl<'w, T: Resource> DerefMut for ResMut<'w, T> { fn deref_mut(&mut self) -> &mut T { self.0 } }
    pub struct Local<'s, T: Default + Send + 'static>(&'s mut T);
    impl<'s, T: Default + Send> Deref for Local<'s, T> { type Target = T; fn deref(&self) -> &T { self.0 } }
    impl<'s, T: Default + Send> DerefMut for Local<'s, T> { fn deref_mut(&mut self) -> &mut T { self.0 } }
    pub struct EventReader<'w, 's, E: Event>(PhantomData<(&'w (), &'s (), E)>);
    impl<'w, 's, E: Event> EventReader<'w, 's, E> {
        pub fn read(&mut self) -> std::vec::IntoIter<&E> { u() }
        pub fn clear(&mut self) {}
    }
    pub struct EventWriter<'w, E: Event>(PhantomData<(&'w (), E)>);
    impl<'w, E: Event> EventWriter<'w, E> { pub fn send(&mut self, e: E) {} }

    pub trait Bundle: Send + Sync + 'static {}
    impl<T: Component> Bundle for T {}
    macro_rules! b_tuple { ($($n:ident),*) => { impl<$($n: Bundle),*> Bundle for ($($n,)*) {} } }
    b_tuple!(A); b_tuple!(A, B); b_tuple!(A, B, C); b_tuple!(A, B, C, D); b_tuple!(A, B, C, D, E); b_tuple!(A, B, C, D, E, F);
    b_tuple!(A, B, C, D, E, F, G); b_tuple!(A, B, C, D, E, F, G, H); b_tuple!(A, B, C, D, E, F, G, H, I); b_tuple!(A, B, C, D, E, F, G, H, I, J);
    b_tuple!(A, B, C, D, E, F, G, H, I, J, K); b_tuple!(A, B, C, D, E, F, G, H, I, J, K, L);

    pub struct Commands<'w, 's>(PhantomData<(&'w (), &'s ())>);
    pub struct EntityCommands<'a>(PhantomData<&'a ()>);
    pub struct ChildBuilder<'a>(PhantomData<&'a ()>);
    impl<'w, 's> Commands<'w, 's> {
        pub fn spawn<B: Bundle>(&mut self, b: B) -> EntityCommands<'_> { u() }
        pub fn entity(&mut self, e: Entity) -> EntityCommands<'_> { u() }
        pub fn get_entity(&mut self, e: Entity) -> Option<EntityCommands<'_>> { u() }
        pub fn insert_resource<R: Resource>(&mut self, r: R) {}
    }
    impl<'a> EntityCommands<'a> {
        pub fn id(&self) -> Entity { u() }
        pub fn insert<B: Bundle>(&mut self, b: B) -> &mut Self { self }
        pub fn remove<B: Bundle>(&mut self) -> &mut Self { self }
        pub fn with_children(&mut self, f: impl FnOnce(&mut ChildBuilder)) -> &mut Self { self }
        pub fn add_child(&mut self, c: Entity) -> &mut Self { self }
        pub fn set_parent(&mut self, p: Entity) -> &mut Self { self }
        pub fn remove_parent_in_place(&mut self) -> &mut Self { self }
        pub fn set_parent_in_place(&mut self, p: Entity) -> &mut Self { self }
        pub fn despawn_recursive(self) {}
    }
    impl<'a> ChildBuilder<'a> { pub fn spawn<B: Bundle>(&mut self, b: B) -> EntityCommands<'_> { u() } }

    // ---- sistemas
    pub struct SystemConfigs;
    pub struct FnMarker;
    pub struct TupleMarker;
    pub trait IntoSystemConfigs<M>: Sized {
        fn after<M2>(self, s: impl IntoSystemSet<M2>) -> SystemConfigs { SystemConfigs }
        fn before<M2>(self, s: impl IntoSystemSet<M2>) -> SystemConfigs { SystemConfigs }
        fn chain(self) -> SystemConfigs { SystemConfigs }
        fn in_set(self, s: impl SystemSet) -> SystemConfigs { SystemConfigs }
    }
    pub trait IntoSystemSet<M> {}
    impl<S: SystemSet> IntoSystemSet<()> for S {}
    impl IntoSystemConfigs<()> for SystemConfigs {}
    macro_rules! fn_sys { ($($p:ident),*) => {
        impl<Func, $($p),*> IntoSystemConfigs<(FnMarker, $($p,)*)> for Func where Func: Fn($($p),*) + Send + Sync + 'static {}
        impl<Func, $($p),*> IntoSystemSet<(FnMarker, $($p,)*)> for Func where Func: Fn($($p),*) + Send + Sync + 'static {}
    } }
    fn_sys!(A); fn_sys!(A, B); fn_sys!(A, B, C); fn_sys!(A, B, C, D); fn_sys!(A, B, C, D, E); fn_sys!(A, B, C, D, E, F);
    fn_sys!(A, B, C, D, E, F, G); fn_sys!(A, B, C, D, E, F, G, H); fn_sys!(A, B, C, D, E, F, G, H, I); fn_sys!(A, B, C, D, E, F, G, H, I, J);
    fn_sys!(A, B, C, D, E, F, G, H, I, J, K); fn_sys!(A, B, C, D, E, F, G, H, I, J, K, L); fn_sys!(A, B, C, D, E, F, G, H, I, J, K, L, M);
    fn_sys!(A, B, C, D, E, F, G, H, I, J, K, L, M, N); fn_sys!(A, B, C, D, E, F, G, H, I, J, K, L, M, N, O); fn_sys!(A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P);
    macro_rules! tup_sys { ($(($s:ident, $m:ident)),*) => {
        impl<$($s, $m),*> IntoSystemConfigs<(TupleMarker, $($m,)*)> for ($($s,)*) where $($s: IntoSystemConfigs<$m>),* {}
    } }
    tup_sys!((S0, M0), (S1, M1)); tup_sys!((S0, M0), (S1, M1), (S2, M2)); tup_sys!((S0, M0), (S1, M1), (S2, M2), (S3, M3));
    tup_sys!((S0, M0), (S1, M1), (S2, M2), (S3, M3), (S4, M4)); tup_sys!((S0, M0), (S1, M1), (S2, M2), (S3, M3), (S4, M4), (S5, M5));
    tup_sys!((S0, M0), (S1, M1), (S2, M2), (S3, M3), (S4, M4), (S5, M5), (S6, M6));
    // parâmetros de sistema: força cada função de sistema a só receber tipos válidos
    pub trait SystemParam {}
    impl<'w, 's, D: QueryData, F: QueryFilter> SystemParam for Query<'w, 's, D, F> {}
    impl<'w, T: Resource> SystemParam for Res<'w, T> {}
    impl<'w, T: Resource> SystemParam for ResMut<'w, T> {}
    impl<'s, T: Default + Send> SystemParam for Local<'s, T> {}
    impl<'w, 's> SystemParam for Commands<'w, 's> {}
    impl<'w, 's, E: Event> SystemParam for EventReader<'w, 's, E> {}
    impl<'w, E: Event> SystemParam for EventWriter<'w, E> {}
}
pub use ecs::*;

// ======================================================================= App
pub mod app {
    use super::*;
    pub trait Plugin: Send + Sync + 'static { fn build(&self, app: &mut App); }
    pub trait Plugins<M> {}
    impl<P: Plugin> Plugins<()> for P {}
    pub struct PluginsTuple;
    macro_rules! p_tuple { ($($p:ident),*) => { impl<$($p: Plugin),*> Plugins<PluginsTuple> for ($($p,)*) {} } }
    p_tuple!(A); p_tuple!(A, B); p_tuple!(A, B, C); p_tuple!(A, B, C, D); p_tuple!(A, B, C, D, E); p_tuple!(A, B, C, D, E, F); p_tuple!(A, B, C, D, E, F, G); p_tuple!(A, B, C, D, E, F, G, H); p_tuple!(A, B, C, D, E, F, G, H, I);
    pub trait ScheduleLabel {}
    pub struct Startup; pub struct Update; pub struct PostUpdate; pub struct PreUpdate;
    impl ScheduleLabel for Startup {} impl ScheduleLabel for Update {} impl ScheduleLabel for PostUpdate {} impl ScheduleLabel for PreUpdate {}
    pub struct App;
    impl App {
        pub fn new() -> App { App }
        pub fn insert_resource<R: Resource>(&mut self, r: R) -> &mut Self { self }
        pub fn init_resource<R: Resource + Default>(&mut self) -> &mut Self { self }
        pub fn add_event<E: Event>(&mut self) -> &mut Self { self }
        pub fn add_plugins<M>(&mut self, p: impl Plugins<M>) -> &mut Self { self }
        pub fn add_systems<M>(&mut self, s: impl ScheduleLabel, sys: impl IntoSystemConfigs<M>) -> &mut Self { self }
        pub fn run(&mut self) {}
    }
    pub struct DefaultPlugins;
    pub struct PluginGroupBuilder;
    impl DefaultPlugins { pub fn set<P: Plugin>(self, p: P) -> PluginGroupBuilder { PluginGroupBuilder } }
    impl PluginGroupBuilder { pub fn set<P: Plugin>(self, p: P) -> PluginGroupBuilder { self } }
    impl Plugins<PluginGroupBuilder> for PluginGroupBuilder {}
}
pub use app::*;

// ======================================================================= tempo, assets, transform
pub mod time { #[derive(Default)] pub struct Time; impl crate::ecs::Resource for Time {}
    impl Time { pub fn delta_seconds(&self) -> f32 { 0.0 } pub fn elapsed_seconds(&self) -> f32 { 0.0 } } }
pub use time::Time;
pub mod asset {
    use super::*;
    pub struct Handle<T>(PhantomData<T>);
    impl<T> Clone for Handle<T> { fn clone(&self) -> Self { Handle(PhantomData) } }
    impl<T> Default for Handle<T> { fn default() -> Self { Handle(PhantomData) } }
    impl<T: Send + Sync + 'static> Component for Handle<T> {}
    pub struct Assets<T>(PhantomData<T>);
    impl<T: Send + Sync + 'static> Resource for Assets<T> {}
    impl<T> Assets<T> {
        pub fn add(&mut self, a: impl Into<T>) -> Handle<T> { u() }
        pub fn get_mut(&mut self, h: &Handle<T>) -> Option<&mut T> { u() }
        pub fn get(&self, h: &Handle<T>) -> Option<&T> { u() }
    }
    pub struct AssetServer; impl Resource for AssetServer {}
    impl AssetServer { pub fn load<A>(&self, path: impl Into<String>) -> Handle<A> { u() } }
    #[derive(Default)] pub enum AssetMetaCheck { #[default] Always, Never }
    #[derive(Default)] pub struct AssetPlugin { pub meta_check: AssetMetaCheck, pub file_path: String }
    impl Plugin for AssetPlugin { fn build(&self, app: &mut App) {} }
}
pub use asset::{AssetServer, Assets, Handle};

pub mod transform {
    use super::*;
    #[derive(Clone, Copy, Debug)]
    pub struct Transform { pub translation: Vec3, pub rotation: Quat, pub scale: Vec3 }
    impl Default for Transform { fn default() -> Self { Transform { translation: Vec3::ZERO, rotation: Quat::IDENTITY, scale: Vec3::ONE } } }
    impl Component for Transform {}
    impl Transform {
        pub const IDENTITY: Transform = Transform { translation: Vec3::ZERO, rotation: Quat::IDENTITY, scale: Vec3::ONE };
        pub fn from_xyz(x: f32, y: f32, z: f32) -> Self { u() }
        pub fn from_translation(v: Vec3) -> Self { u() }
        pub fn from_matrix(m: Mat4) -> Self { u() }
        pub fn with_rotation(self, q: Quat) -> Self { self }
        pub fn with_scale(self, s: Vec3) -> Self { self }
        pub fn looking_at(self, t: Vec3, up: impl Into<Vec3>) -> Self { self }
        pub fn compute_matrix(&self) -> Mat4 { u() }
    }
    #[derive(Clone, Copy, Debug, Default)]
    pub struct GlobalTransform(Affine3A);
    impl Component for GlobalTransform {}
    impl GlobalTransform {
        pub fn translation(&self) -> Vec3 { u() }
        pub fn forward(&self) -> Dir3 { u() }
        pub fn right(&self) -> Dir3 { u() }
        pub fn up(&self) -> Dir3 { u() }
        pub fn compute_matrix(&self) -> Mat4 { u() }
        pub fn affine(&self) -> Affine3A { u() }
        pub fn transform_point(&self, p: Vec3) -> Vec3 { u() }
    }
    #[derive(Debug, Clone, PartialEq, Eq, Hash)]
    pub enum TransformSystem { TransformPropagate }
    impl SystemSet for TransformSystem {}
}
pub use transform::{GlobalTransform, Transform};

pub mod hierarchy {
    use super::*;
    pub struct Children(Vec<Entity>); impl Component for Children {}
    pub trait HierarchyQueryExt { fn iter_descendants(&self, e: Entity) -> std::vec::IntoIter<Entity>; }
    impl<'w, 's, F: QueryFilter> HierarchyQueryExt for Query<'w, 's, &Children, F> { fn iter_descendants(&self, e: Entity) -> std::vec::IntoIter<Entity> { u() } }
}
pub mod core { use super::*; pub struct Name(String); impl Component for Name {} impl Name { pub fn as_str(&self) -> &str { u() } } }

// ======================================================================= render
pub mod color {
    #[derive(Clone, Copy, Debug)] pub struct Color;
    pub trait Alpha: Sized { fn with_alpha(&self, a: f32) -> Self; fn alpha(&self) -> f32; fn set_alpha(&mut self, a: f32); }
    impl Alpha for Color { fn with_alpha(&self, a: f32) -> Self { Color } fn alpha(&self) -> f32 { 1.0 } fn set_alpha(&mut self, a: f32) {} }
    impl Color { pub const NONE: Color = Color; pub const WHITE: Color = Color; pub const BLACK: Color = Color; pub fn srgb(r: f32, g: f32, b: f32) -> Color { Color } pub fn srgba(r: f32, g: f32, b: f32, a: f32) -> Color { Color } }
    impl Default for Color { fn default() -> Self { Color } }
    #[derive(Clone, Copy, Debug, Default)] pub struct LinearRgba;
    impl LinearRgba { pub const fn rgb(r: f32, g: f32, b: f32) -> Self { LinearRgba } }
}
pub use color::{Color, LinearRgba};
pub mod render {
    pub mod render_asset { #[derive(Clone, Copy)] pub struct RenderAssetUsages; impl RenderAssetUsages { pub const RENDER_WORLD: Self = RenderAssetUsages; pub const MAIN_WORLD: Self = RenderAssetUsages; } impl Default for RenderAssetUsages { fn default() -> Self { RenderAssetUsages } } }
    pub mod render_resource {
        #[derive(Clone, Copy, Default)] pub struct Extent3d { pub width: u32, pub height: u32, pub depth_or_array_layers: u32 }
        #[derive(Clone, Copy)] pub enum TextureDimension { D1, D2, D3 }
        #[derive(Clone, Copy)] pub enum TextureFormat { Rgba8UnormSrgb, Rgba8Unorm }
        #[derive(Clone, Copy, Debug)] pub enum Face { Front, Back }
        #[derive(Clone, Default)] pub struct TextureDescriptor { pub mip_level_count: u32, pub size: Extent3d }
    }
    pub mod texture {
        use super::render_resource::*;
        #[derive(Clone, Copy, Default)] pub enum ImageAddressMode { #[default] ClampToEdge, Repeat, MirrorRepeat }
        #[derive(Clone, Copy, Default)] pub enum ImageFilterMode { #[default] Nearest, Linear }
        #[derive(Clone, Default)] pub struct ImageSamplerDescriptor { pub address_mode_u: ImageAddressMode, pub address_mode_v: ImageAddressMode, pub address_mode_w: ImageAddressMode, pub mag_filter: ImageFilterMode, pub min_filter: ImageFilterMode, pub mipmap_filter: ImageFilterMode, pub anisotropy_clamp: u16 }
        impl ImageSamplerDescriptor { pub fn linear() -> Self { Self::default() } }
        #[derive(Clone, Default)] pub enum ImageSampler { #[default] Default, Descriptor(ImageSamplerDescriptor) }
        #[derive(Clone)] pub struct Image { pub data: Vec<u8>, pub texture_descriptor: TextureDescriptor, pub sampler: ImageSampler }
        impl Image { pub fn new(size: Extent3d, d: TextureDimension, data: Vec<u8>, f: TextureFormat, u: super::render_asset::RenderAssetUsages) -> Self { unimplemented!() } }
    }
    pub mod mesh {
        pub use super::render_resource::*;
        #[derive(Clone, Copy)] pub enum PrimitiveTopology { TriangleList }
        pub enum Indices { U16(Vec<u16>), U32(Vec<u32>) }
        pub struct MeshVertexAttribute;
        pub enum VertexAttributeValues { F2(Vec<[f32; 2]>), F3(Vec<[f32; 3]>), F4(Vec<[f32; 4]>) }
        impl From<Vec<[f32; 3]>> for VertexAttributeValues { fn from(v: Vec<[f32; 3]>) -> Self { VertexAttributeValues::F3(v) } }
        impl From<Vec<[f32; 2]>> for VertexAttributeValues { fn from(v: Vec<[f32; 2]>) -> Self { VertexAttributeValues::F2(v) } }
        pub struct Mesh;
        impl Mesh {
            pub const ATTRIBUTE_POSITION: MeshVertexAttribute = MeshVertexAttribute;
            pub const ATTRIBUTE_NORMAL: MeshVertexAttribute = MeshVertexAttribute;
            pub const ATTRIBUTE_UV_0: MeshVertexAttribute = MeshVertexAttribute;
            pub fn new(t: PrimitiveTopology, u: super::render_asset::RenderAssetUsages) -> Self { Mesh }
            pub fn with_inserted_attribute(self, a: MeshVertexAttribute, v: impl Into<VertexAttributeValues>) -> Self { self }
            pub fn with_inserted_indices(self, i: Indices) -> Self { self }
        }
        impl From<crate::math::primitives::Cuboid> for Mesh { fn from(_: crate::math::primitives::Cuboid) -> Self { Mesh } }
        impl From<crate::math::primitives::Cylinder> for Mesh { fn from(_: crate::math::primitives::Cylinder) -> Self { Mesh } }
        impl From<crate::math::primitives::Circle> for Mesh { fn from(_: crate::math::primitives::Circle) -> Self { Mesh } }
        impl From<crate::math::primitives::Rectangle> for Mesh { fn from(_: crate::math::primitives::Rectangle) -> Self { Mesh } }
    }
    pub mod view {
        #[derive(Clone, Copy, Default, PartialEq, Eq, Debug)] pub enum Visibility { #[default] Inherited, Hidden, Visible }
        impl crate::ecs::Component for Visibility {}
        #[derive(Clone, Copy, Default)] pub enum Msaa { Off, Sample2, #[default] Sample4, Sample8 }
        impl crate::ecs::Resource for Msaa {}
        pub type Layer = usize;
        #[derive(Clone, Default, PartialEq, Eq, Debug)] pub struct RenderLayers;
        impl RenderLayers { pub const fn layer(n: Layer) -> Self { RenderLayers } pub fn from_layers(l: &[Layer]) -> Self { RenderLayers } }
        impl crate::ecs::Component for RenderLayers {}
        pub struct NoFrustumCulling; impl crate::ecs::Component for NoFrustumCulling {}
    }
    pub mod camera {
        #[derive(Clone, Default)] pub struct PerspectiveProjection { pub fov: f32, pub aspect_ratio: f32, pub near: f32, pub far: f32 }
        #[derive(Clone)] pub enum Projection { Perspective(PerspectiveProjection), Orthographic(()) }
        impl Default for Projection { fn default() -> Self { Projection::Perspective(Default::default()) } }
        impl crate::ecs::Component for Projection {}
        #[derive(Clone, Default)] pub enum ClearColorConfig { #[default] Default, Custom(crate::Color), None }
        #[derive(Clone)] pub struct Camera { pub order: isize, pub is_active: bool, pub clear_color: ClearColorConfig, pub hdr: bool }
        impl Default for Camera { fn default() -> Self { Camera { order: 0, is_active: true, clear_color: ClearColorConfig::Default, hdr: false } } }
        impl crate::ecs::Component for Camera {}
        #[derive(Default)] pub struct ClearColor(pub crate::Color);
        impl crate::ecs::Resource for ClearColor {}
    }
}
pub use render::camera::{Camera, ClearColor, ClearColorConfig, PerspectiveProjection, Projection};
pub use render::mesh::Mesh;
pub use render::texture::Image;
pub use render::view::{Msaa, Visibility};

#[derive(Clone, Copy, Default, Debug, PartialEq)] pub enum AlphaMode { #[default] Opaque, Blend, Add, Multiply, Mask(f32) }
#[derive(Clone, Default)]
pub struct StandardMaterial {
    pub base_color: Color, pub base_color_texture: Option<Handle<Image>>, pub emissive: LinearRgba, pub perceptual_roughness: f32, pub metallic: f32,
    pub normal_map_texture: Option<Handle<Image>>, pub double_sided: bool, pub cull_mode: Option<render::render_resource::Face>, pub unlit: bool, pub alpha_mode: AlphaMode,
    pub uv_transform: Affine2,
}
pub struct Scene;

pub mod pbr {
    use super::*;
    #[derive(Clone, Default)] pub struct DirectionalLight { pub color: Color, pub illuminance: f32, pub shadows_enabled: bool }
    #[derive(Clone, Default)] pub struct PointLight { pub color: Color, pub intensity: f32, pub range: f32, pub radius: f32, pub shadows_enabled: bool }
    impl Component for PointLight {}
    #[derive(Clone, Default)] pub struct CascadeShadowConfig;
    #[derive(Clone, Default)] pub struct CascadeShadowConfigBuilder { pub num_cascades: usize, pub minimum_distance: f32, pub maximum_distance: f32, pub first_cascade_far_bound: f32, pub overlap_proportion: f32 }
    impl From<CascadeShadowConfigBuilder> for CascadeShadowConfig { fn from(_: CascadeShadowConfigBuilder) -> Self { CascadeShadowConfig } }
    #[derive(Default)] pub struct DirectionalLightShadowMap { pub size: usize } impl Resource for DirectionalLightShadowMap {}
    #[derive(Default)] pub struct AmbientLight { pub color: Color, pub brightness: f32 } impl Resource for AmbientLight {}
    pub struct NotShadowCaster; impl Component for NotShadowCaster {}
    #[derive(Clone)] pub enum FogFalloff { Linear { start: f32, end: f32 }, Exponential { density: f32 } }
    impl Default for FogFalloff { fn default() -> Self { FogFalloff::Linear { start: 0.0, end: 100.0 } } }
    #[derive(Clone, Default)] pub struct FogSettings { pub color: Color, pub directional_light_color: Color, pub directional_light_exponent: f32, pub falloff: FogFalloff }
    impl Component for FogSettings {}
    #[derive(Default)] pub struct PbrBundle { pub mesh: Handle<Mesh>, pub material: Handle<StandardMaterial>, pub transform: Transform, pub global_transform: GlobalTransform, pub visibility: Visibility }
    impl Bundle for PbrBundle {}
    #[derive(Default)] pub struct DirectionalLightBundle { pub directional_light: DirectionalLight, pub cascade_shadow_config: CascadeShadowConfig, pub transform: Transform, pub global_transform: GlobalTransform, pub visibility: Visibility }
    impl Bundle for DirectionalLightBundle {}
    #[derive(Default)] pub struct PointLightBundle { pub point_light: PointLight, pub transform: Transform, pub global_transform: GlobalTransform, pub visibility: Visibility }
    impl Bundle for PointLightBundle {}
}
pub use pbr::{AmbientLight, DirectionalLight, DirectionalLightBundle, PbrBundle, PointLight, PointLightBundle};
#[derive(Default)] pub struct SceneBundle { pub scene: Handle<Scene>, pub transform: Transform, pub global_transform: GlobalTransform, pub visibility: Visibility }
impl Bundle for SceneBundle {}
#[derive(Default)] pub struct SpatialBundle { pub visibility: Visibility, pub transform: Transform, pub global_transform: GlobalTransform }
impl SpatialBundle { pub const fn from_transform(t: Transform) -> Self { unimplemented!() } }
impl Bundle for SpatialBundle {}
#[derive(Default)] pub struct Camera3dBundle { pub camera: render::camera::Camera, pub projection: Projection, pub transform: Transform, pub global_transform: GlobalTransform }
impl Bundle for Camera3dBundle {}
pub mod core_pipeline { pub mod fxaa { #[derive(Default)] pub struct Fxaa { pub enabled: bool } impl crate::ecs::Component for Fxaa {} } }

// ======================================================================= UI
pub mod ui {
    pub struct IsDefaultUiCamera; impl crate::ecs::Component for IsDefaultUiCamera {}
    use super::*;
    #[derive(Clone, Copy, Debug, Default, PartialEq)] pub enum Val { #[default] Auto, Px(f32), Percent(f32), Vw(f32), Vh(f32) }
    #[derive(Clone, Copy, Default)] pub struct UiRect { pub left: Val, pub right: Val, pub top: Val, pub bottom: Val }
    impl UiRect { pub fn all(v: Val) -> Self { UiRect { left: v, right: v, top: v, bottom: v } } }
    #[derive(Clone, Copy, Default)] pub enum PositionType { #[default] Relative, Absolute }
    #[derive(Clone, Copy, Default)] pub enum JustifyContent { #[default] Default, Center, FlexStart }
    #[derive(Clone, Copy, Default)] pub enum AlignItems { #[default] Default, Center }
    #[derive(Clone, Copy, Default, PartialEq)] pub enum Display { #[default] Flex, None, Grid }
    #[derive(Clone, Default)] pub struct Style { pub display: Display, pub position_type: PositionType, pub left: Val, pub right: Val, pub top: Val, pub bottom: Val, pub width: Val, pub height: Val, pub margin: UiRect, pub border: UiRect, pub padding: UiRect, pub justify_content: JustifyContent, pub align_items: AlignItems }
    impl Component for Style {}
    #[derive(Clone, Copy, Default)] pub struct BackgroundColor(pub Color); impl Component for BackgroundColor {}
    #[derive(Clone, Copy, Default)] pub struct BorderColor(pub Color); impl Component for BorderColor {}
    #[derive(Clone, Copy, Default)] pub struct BorderRadius; impl BorderRadius { pub const MAX: Self = BorderRadius; pub const ZERO: Self = BorderRadius; pub const fn all(v: Val) -> Self { BorderRadius } }
    #[derive(Default)] pub struct NodeBundle { pub style: Style, pub background_color: BackgroundColor, pub border_color: BorderColor, pub border_radius: BorderRadius, pub visibility: Visibility, pub transform: Transform }
    impl Bundle for NodeBundle {}
    #[derive(Clone, Default)] pub struct TextStyle { pub font_size: f32, pub color: Color }
    #[derive(Clone, Default)] pub struct TextSection { pub value: String, pub style: TextStyle }
    #[derive(Clone, Default)] pub struct Text { pub sections: Vec<TextSection> } impl Component for Text {}
    #[derive(Default)] pub struct TextBundle { pub text: Text, pub style: Style }
    impl Bundle for TextBundle {}
    impl TextBundle {
        pub fn from_section(v: impl Into<String>, s: TextStyle) -> Self { u() }
        pub fn with_style(self, s: Style) -> Self { self }
    }
}
pub use ui::*;

// ======================================================================= janela e entrada
pub mod window {
    use super::*;
    #[derive(Clone, Copy, Default, PartialEq, Eq, Debug)] pub enum WindowMode { #[default] Windowed, BorderlessFullscreen, Fullscreen }
    #[derive(Clone, Copy, Default, PartialEq, Eq, Debug)] pub enum CursorGrabMode { #[default] None, Confined, Locked }
    #[derive(Clone, Default)] pub struct Cursor { pub visible: bool, pub grab_mode: CursorGrabMode }
    #[derive(Clone, Default)] pub struct Window { pub title: String, pub mode: WindowMode, pub resizable: bool, pub cursor: Cursor }
    impl Component for Window {}
    impl Window { pub fn width(&self) -> f32 { 0.0 } pub fn height(&self) -> f32 { 0.0 } }
    pub struct PrimaryWindow; impl Component for PrimaryWindow {}
    #[derive(Default)] pub struct WindowPlugin { pub primary_window: Option<Window> }
    impl Plugin for WindowPlugin { fn build(&self, app: &mut App) {} }
}
pub use window::{Window, WindowPlugin};
pub mod input {
    use super::*;
    #[derive(Debug, Clone, PartialEq, Eq, Hash)] pub struct InputSystem; impl SystemSet for InputSystem {}
    pub mod mouse { #[derive(Clone, Copy)] pub struct MouseMotion { pub delta: crate::math::Vec2 } impl crate::ecs::Event for MouseMotion {} }
    #[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)] pub enum KeyCode { KeyW, KeyA, KeyS, KeyD, KeyR, KeyC, KeyG, KeyV, Space, ShiftLeft, ControlLeft, Escape }
    #[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)] pub enum MouseButton { Left, Right, Middle }
    pub struct ButtonInput<T>(PhantomData<T>);
    impl<T: Send + Sync + 'static> Resource for ButtonInput<T> {}
    impl<T> ButtonInput<T> { pub fn pressed(&self, t: T) -> bool { false } pub fn just_pressed(&self, t: T) -> bool { false } }
    pub struct Touch; impl Touch { pub fn position(&self) -> Vec2 { u() } pub fn id(&self) -> u64 { 0 } pub fn start_position(&self) -> Vec2 { u() } }
    pub struct Touches; impl Resource for Touches {}
    impl Touches {
        pub fn iter(&self) -> std::vec::IntoIter<&Touch> { u() }
        pub fn iter_just_pressed(&self) -> std::vec::IntoIter<&Touch> { u() }
        pub fn iter_just_released(&self) -> std::vec::IntoIter<&Touch> { u() }
        pub fn get_pressed(&self, id: u64) -> Option<&Touch> { u() }
    }
}
pub use input::{ButtonInput, KeyCode, MouseButton};
pub use input::Touches;

pub fn default<T: Default>() -> T { T::default() }

pub mod prelude {
    pub use crate::math::*;
    pub use crate::math::primitives::*;
    pub use crate::ecs::{Added, Bundle, Changed, Commands, Component, Entity, EntityCommands, Event, EventReader, EventWriter, IntoSystemConfigs, Local, Mut, Query, Res, ResMut, Resource, SystemSet, With, Without};
    pub use crate::app::{App, DefaultPlugins, Plugin, PostUpdate, PreUpdate, Startup, Update};
    pub use crate::{AlphaMode, StandardMaterial, SceneBundle, SpatialBundle, Camera3dBundle, default};
    pub use bevy_macros::{bevy_main, Component, Resource, Event, SystemSet, Deref};
    pub use crate::time::Time;
    pub use crate::asset::{AssetPlugin, AssetServer, Assets, Handle};
    pub use crate::transform::{GlobalTransform, Transform};
    pub use crate::hierarchy::Children;
    pub use crate::core::Name;
    pub use crate::color::{Color, LinearRgba};
    pub use crate::render::camera::{Camera, ClearColor, ClearColorConfig, PerspectiveProjection, Projection};
    pub use crate::render::mesh::Mesh;
    pub use crate::render::texture::Image;
    pub use crate::render::view::{Msaa, Visibility};
    pub use crate::pbr::{AmbientLight, DirectionalLight, DirectionalLightBundle, PbrBundle, PointLight, PointLightBundle};
    pub use crate::ui::*;
    pub use crate::window::{Window, WindowPlugin};
    pub use crate::input::{ButtonInput, KeyCode, MouseButton, Touches};
}
