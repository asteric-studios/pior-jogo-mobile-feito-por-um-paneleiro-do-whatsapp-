#![allow(dead_code, unused_variables)]
//! Dublê de tipos do bevy_rapier3d 0.27 (assinaturas conferidas no código-fonte).
pub mod prelude {
    use bevy::ecs::{Component, Entity, Resource, SystemSet};
    use bevy::math::{Quat, Vec3};
    use std::marker::PhantomData;
    fn u<T>() -> T { unimplemented!() }
    pub type Vect = Vec3;
    pub type Rot = Quat;
    pub type Real = f32;
    #[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Default)]
    pub struct Group(u32);
    impl Group {
        pub const GROUP_1: Group = Group(1); pub const GROUP_2: Group = Group(2); pub const GROUP_3: Group = Group(4); pub const GROUP_4: Group = Group(8);
        pub const ALL: Group = Group(u32::MAX); pub const NONE: Group = Group(0);
        pub fn bits(&self) -> u32 { self.0 }
    }
    impl std::ops::BitOr for Group { type Output = Group; fn bitor(self, o: Group) -> Group { Group(self.0 | o.0) } }
    #[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
    pub struct CollisionGroups { pub memberships: Group, pub filters: Group }
    impl CollisionGroups { pub const fn new(memberships: Group, filters: Group) -> Self { CollisionGroups { memberships, filters } } }
    impl Component for CollisionGroups {}
    #[derive(Copy, Clone, Default)]
    pub struct QueryFilter<'a> { p: PhantomData<&'a ()> }
    impl<'a> QueryFilter<'a> {
        pub fn groups(self, g: CollisionGroups) -> Self { self }
        pub fn exclude_collider(self, e: Entity) -> Self { self }
        pub fn exclude_rigid_body(self, e: Entity) -> Self { self }
        pub fn exclude_sensors(self) -> Self { self }
    }
    #[derive(Copy, Clone, Debug, PartialEq)]
    pub struct RayIntersection { pub time_of_impact: Real, pub point: Vect, pub normal: Vect }
    pub struct RapierContext;
    impl Resource for RapierContext {}
    impl RapierContext {
        pub fn cast_ray(&self, ray_origin: Vect, ray_dir: Vect, max_toi: Real, solid: bool, filter: QueryFilter) -> Option<(Entity, Real)> { u() }
        pub fn cast_ray_and_get_normal(&self, ray_origin: Vect, ray_dir: Vect, max_toi: Real, solid: bool, filter: QueryFilter) -> Option<(Entity, RayIntersection)> { u() }
    }
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub enum RigidBody { Dynamic, Fixed, KinematicPositionBased, KinematicVelocityBased }
    impl Component for RigidBody {}
    #[derive(Clone)]
    pub struct Collider;
    impl Component for Collider {}
    impl Collider {
        pub fn ball(r: Real) -> Self { Collider }
        pub fn cuboid(hx: Real, hy: Real, hz: Real) -> Self { Collider }
        pub fn capsule_y(half_height: Real, radius: Real) -> Self { Collider }
        pub fn cylinder(half_height: Real, radius: Real) -> Self { Collider }
        pub fn compound(shapes: Vec<(Vect, Rot, Collider)>) -> Self { Collider }
    }
    #[derive(Copy, Clone, Debug, PartialEq)] pub enum CharacterLength { Relative(Real), Absolute(Real) }
    #[derive(Copy, Clone, Debug, PartialEq)] pub struct CharacterAutostep { pub max_height: CharacterLength, pub min_width: CharacterLength, pub include_dynamic_bodies: bool }
    #[derive(Clone, Debug)]
    pub struct KinematicCharacterController {
        pub translation: Option<Vect>, pub custom_shape: Option<(Collider, Vect, Rot)>, pub custom_mass: Option<Real>, pub up: Vect, pub offset: CharacterLength,
        pub slide: bool, pub autostep: Option<CharacterAutostep>, pub max_slope_climb_angle: Real, pub min_slope_slide_angle: Real,
        pub apply_impulse_to_dynamic_bodies: bool, pub snap_to_ground: Option<CharacterLength>, pub filter_groups: Option<CollisionGroups>, pub normal_nudge_factor: Real,
    }
    impl std::fmt::Debug for Collider { fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result { Ok(()) } }
    impl Default for KinematicCharacterController { fn default() -> Self { u() } }
    impl Component for KinematicCharacterController {}
    #[derive(Clone, Debug, Default)]
    pub struct KinematicCharacterControllerOutput { pub grounded: bool, pub desired_translation: Vect, pub effective_translation: Vect, pub is_sliding_down_slope: bool }
    impl Component for KinematicCharacterControllerOutput {}
    #[derive(Clone, Copy)] pub struct Friction; impl Friction { pub const fn coefficient(c: f32) -> Self { Friction } } impl Component for Friction {}
    #[derive(Clone, Copy)] pub struct Restitution; impl Restitution { pub const fn coefficient(c: f32) -> Self { Restitution } } impl Component for Restitution {}
    #[derive(Clone, Copy, Default)] pub struct Damping { pub linear_damping: f32, pub angular_damping: f32 } impl Component for Damping {}
    #[derive(Clone, Copy, Default)] pub struct ExternalImpulse { pub impulse: Vect, pub torque_impulse: Vect } impl Component for ExternalImpulse {}
    #[derive(Clone, Copy, Default)] pub struct Velocity { pub linvel: Vect, pub angvel: Vect } impl Component for Velocity {}
    #[derive(Clone, Copy)] pub enum ColliderMassProperties { Density(f32), Mass(f32) } impl Component for ColliderMassProperties {}
    pub struct NoUserData;
    pub struct RapierPhysicsPlugin<T>(PhantomData<T>);
    impl<T> Default for RapierPhysicsPlugin<T> { fn default() -> Self { RapierPhysicsPlugin(PhantomData) } }
    impl<T: Send + Sync + 'static> bevy::app::Plugin for RapierPhysicsPlugin<T> { fn build(&self, app: &mut bevy::app::App) {} }
    #[derive(Debug, Clone, PartialEq, Eq, Hash)] pub enum PhysicsSet { SyncBackend, StepSimulation, Writeback }
    impl SystemSet for PhysicsSet {}
}
