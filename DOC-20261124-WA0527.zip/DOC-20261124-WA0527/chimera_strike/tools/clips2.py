"""Clipes de corpo inteiro (queda/ferido/morte) autorados por keyframes + IK."""
import numpy as np, sys, os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from qm import *; import rig, anim, clips
from anim import Pose, fk, ik2, IDX, T0
D=np.pi/180
_aim,_=clips.upper_aim(0); _low,_=clips.upper_low(0)
W_AIM=(_aim.wpos.copy(),_aim.wrot.copy()); W_LOW=(_low.wpos.copy(),_low.wrot.copy())
EASE={'s':smooth,'in':lambda u:u*u,'out':lambda u:1-(1-u)**2,'lin':lambda u:u,
      'bounce':lambda u: 1-(1-u)**2+0.08*np.sin(np.pi*u)}
def interp(keys,t):
    if t<=keys[0][0]: return dict(keys[0][1])
    for i in range(len(keys)-1):
        a,b=keys[i],keys[i+1]
        if a[0]<=t<=b[0]:
            u=EASE[b[1].get('e','s')]((t-a[0])/max(b[0]-a[0],1e-6))
            out={}
            for k,va in a[1].items():
                vb=b[1].get(k,va)
                if isinstance(va,(int,float,tuple,list,np.ndarray)) and not isinstance(va,str):
                    out[k]=np.asarray(va,float)*(1-u)+np.asarray(vb,float)*u
                else: out[k]=va if u<0.5 else vb
            for k,vb in b[1].items():
                if k not in out: out[k]=vb
            return out
    return dict(keys[-1][1])
def place_foot(p,side,v):
    x,y,z,yaw,pitch=v
    rf=qmul(qy(yaw*D),qx(pitch*D))
    Gr,_,_,_=fk(p)
    pole=qrot(Gr[0],np.array([0.12 if side=='Left' else -0.12,0,1.0]))
    ik2(p,IDX[side+'UpLeg'],IDX[side+'Leg'],IDX[side+'Foot'],np.array([x,y,z]),rf,pole,anim.LEG_FLEX,1.0)
    p.rot[IDX[side+'ToeBase']]=qx(-max(0,pitch)*0.5*D)
def build_pose(k):
    p=Pose()
    p.hips=np.asarray(k['hips'],float); p.rot[0]=ypr(*k['hr'])
    sp=k.get('sp',(0,0,0))
    for b,a in zip(('Spine','Spine1','Spine2'),(0.3,0.35,0.35)):
        p.rot[IDX[b]]=ypr(sp[0]*a,sp[1]*a,sp[2]*a)
    p.rot[IDX['Neck']]=ypr(*k.get('neck',(0,0,0))); p.rot[IDX['Head']]=ypr(*k.get('head',(0,0,0)))
    p.rot[IDX['RightShoulder']]=ypr(*k.get('rcl',(0,0,-6))); p.rot[IDX['LeftShoulder']]=ypr(*k.get('lcl',(-14,0,4)))
    place_foot(p,'Right',k['rf']); place_foot(p,'Left',k['lf'])
    p.ikl=float(k.get('ikl',1.0)); p.aimw=float(k.get('aimw',0.0)); p.aimoff=0.0
    p.ikr=0.0 if k.get('arms','gun')=='free' else 1.0
    p.mpos=clips.MAG_REST.copy()
    if k.get('arms','gun')=='gun':
        p.rot[IDX['RightFingers']]=qz(78*D); p.rot[IDX['LeftFingers']]=qz(-70*D)
        m=float(k.get('wmix',0.0))
        wp=W_AIM[0]*(1-m)+W_LOW[0]*m; wr=qslerp(W_AIM[1],W_LOW[1],m)
        ex=k.get('wex',(0,0,0)); wr=qmul(wr,ypr(*ex)); wp=wp+np.asarray(k.get('wofs',(0,0,0)),float)
        p.wpos=wp; p.wrot=wr
        anim.arm_ik(p,clips.GRIPS,1.0,p.ikl)
    else:
        # bracos livres: alvos das maos no espaco da raiz
        Gr,_,_,_=fk(p); chest=Gr[anim.S2]
        for side,pole in (('Right',anim.POLE_R),('Left',anim.POLE_L)):
            tgt=np.asarray(k['rh' if side=='Right' else 'lh'],float)
            ik2(p,IDX[side+'Arm'],IDX[side+'ForeArm'],IDX[side+'Hand'],tgt,q(),qrot(chest,pole),anim.ARM_FLEX,1.0)
            p.rot[IDX[side+'Hand']]=ypr(*k.get('rhl' if side=='Right' else 'lhl',(0,0,0)))
        p.rot[IDX['RightFingers']]=qz(float(k.get('curl',35))*D); p.rot[IDX['LeftFingers']]=qz(-float(k.get('curl',35))*D)
        # arma caindo (so para visualizacao; no jogo ela vira um objeto fisico)
        if 'wworld' in k:
            Gr,Gp,_,_=fk(p); wpw=np.asarray(k['wworld'][:3],float); wrw=ypr(*k['wworld'][3:])
            p.wrot=qmul(qconj(Gr[anim.S2]),wrw); p.wpos=qrot(qconj(Gr[anim.S2]),wpw-Gp[anim.S2])
    anim.apply_twist(p)
    return p
CX=rig.CX
STAND=dict(hips=(CX,0.955,0.0),hr=(-28,2,0),sp=(12,3,0),neck=(8,-6,0),head=(14,8,9),
           rf=(-0.18,0.10,-0.10,-48,0),lf=(0.10,0.10,0.11,-14,0),arms='gun',wmix=0.0,aimw=1.0)
# ferido sentado/reclinado no chao, segurando o fuzil (base do "last stand")
WOUND=dict(hips=(CX,0.20,-0.02),hr=(-8,-48,4),sp=(6,30,-4),neck=(0,8,0),head=(4,10,4),
           rf=(-0.13,0.09,0.78,-4,-70),lf=(0.14,0.10,0.40,8,-10),arms='gun',wmix=0.35,wex=(0,0,0),aimw=0.85)
def k(base,**kw):
    d=dict(base); d.update(kw); return d
FULL={}
FULL['wound_fall']=(1.25,[
    (0.00,k(STAND)),
    (0.14,k(STAND,e='out',hips=(CX-0.03,0.86,-0.03),hr=(-24,10,-10),sp=(10,14,-6),head=(10,18,4),rf=(-0.17,0.20,-0.13,-40,30),wmix=0.3,aimw=0.4)),   # perna direita cede
    (0.38,k(STAND,e='in',hips=(CX-0.06,0.52,0.02),hr=(-16,22,-18),sp=(8,20,-10),head=(6,14,0),rf=(-0.16,0.10,-0.40,-30,70),lf=(0.12,0.10,0.18,-6,0),wmix=0.6,aimw=0.2)),  # cai sobre o joelho
    (0.62,k(STAND,e='in',hips=(CX-0.04,0.24,0.08),hr=(-12,-25,-12),sp=(4,30,-8),head=(2,16,0),rf=(-0.15,0.09,0.45,-10,-40),lf=(0.15,0.10,0.35,4,-5),wmix=0.7,aimw=0.1)), # senta
    (0.82,k(WOUND,e='out',hips=(CX,0.17,-0.04),hr=(-8,-58,6),sp=(4,22,-4),wmix=0.6,aimw=0.3)),  # bate as costas
    (1.25,k(WOUND,e='s')),
])
def crawl_keys(T=1.25):
    ks=[]
    for i,ph in enumerate(np.linspace(0,1,11)):
        push=ph<0.6
        u=ph/0.6 if push else (ph-0.6)/0.4
        fz=0.30+0.34*smooth(u) if push else 0.64-0.34*smooth(u)
        fy=0.10 if push else 0.10+0.09*np.sin(np.pi*u)
        hy=0.20+0.035*np.sin(np.pi*u) if push else 0.20
        sway=4*np.sin(2*np.pi*ph)
        ks.append((ph*T,k(WOUND,e='lin',hips=(CX,hy,-0.02),hr=(-8+sway,-50,4+sway*0.6),sp=(6-sway,26,-4),
                         lf=(0.15,fy,fz,8,-12+18*(fz-0.3)),rf=(-0.13,0.09,0.80,-4,-72),wmix=0.85,wex=(10,8,-10),aimw=0.0)))
    return ks
FULL['wound_crawl']=(1.25,crawl_keys(1.25))
FULL['wound_aim']=(3.0,[(0.0,k(WOUND)),(1.5,k(WOUND,sp=(6,32,-4),head=(4,12,6))),(3.0,k(WOUND))])
LIE_BACK=dict(hips=(CX,0.13,-0.55),hr=(-10,-86,8),sp=(4,-4,6),neck=(10,-8,0),head=(30,-10,10),
              rf=(-0.24,0.11,0.30,-20,-80),lf=(0.20,0.11,0.25,25,-75),arms='free',
              rh=(-0.62,0.10,-0.95),lh=(0.55,0.10,-0.75),rhl=(0,0,30),lhl=(0,0,-30),curl=30,ikl=0,aimw=0)
FULL['death_back']=(1.35,[
    (0.00,k(STAND)),
    (0.12,k(STAND,e='out',hips=(CX,0.93,-0.10),hr=(-20,-12,6),sp=(10,-14,4),head=(10,-25,6),wmix=0.4,aimw=0.0)),  # impacto: tronco para tras
    (0.40,k(STAND,e='s',hips=(CX,0.80,-0.22),hr=(-14,-16,8),sp=(8,-10,6),head=(16,-20,8),rf=(-0.18,0.10,-0.30,-40,10),lf=(0.12,0.16,0.05,-8,-10),arms='free',
          rh=(-0.45,1.05,0.05),lh=(0.32,1.15,0.15),rhl=(0,0,20),lhl=(0,0,-20),ikl=0,wworld=(-0.3,0.95,0.35,30,0,85))),
    (0.78,k(LIE_BACK,e='in',hips=(CX,0.42,-0.42),hr=(-12,-55,8),sp=(4,-8,6),rf=(-0.22,0.16,0.10,-20,-30),lf=(0.18,0.20,0.12,20,-40),
          rh=(-0.70,0.55,-0.50),lh=(0.60,0.60,-0.40),wworld=(-0.5,0.30,0.55,50,0,85))),
    (1.00,k(LIE_BACK,e='in',hips=(CX,0.14,-0.56),wworld=(-0.55,0.04,0.6,60,0,85))),
    (1.35,k(LIE_BACK,e='bounce',wworld=(-0.55,0.04,0.6,60,0,85))),
])
LIE_FWD=dict(hips=(CX,0.16,0.55),hr=(25,84,-10),sp=(-6,6,-8),neck=(-20,10,0),head=(-55,0,10),
             rf=(-0.20,0.10,-0.34,20,85),lf=(0.18,0.10,-0.38,-15,85),arms='free',
             rh=(-0.40,0.10,1.15),lh=(0.42,0.10,0.95),rhl=(0,0,10),lhl=(0,0,-10),curl=40,ikl=0,aimw=0)
FULL['death_fwd']=(1.3,[
    (0.00,k(STAND)),
    (0.12,k(STAND,e='out',hips=(CX,0.92,0.08),hr=(-24,16,-6),sp=(10,22,-4),head=(6,30,0),wmix=0.5,aimw=0)),
    (0.42,k(STAND,e='in',hips=(CX,0.55,0.12),hr=(-10,24,-4),sp=(4,30,-6),head=(0,35,0),rf=(-0.17,0.10,-0.20,-30,60),lf=(0.12,0.10,0.10,-8,40),arms='free',
          rh=(-0.30,0.75,0.45),lh=(0.28,0.80,0.50),ikl=0,wworld=(-0.2,0.55,0.6,20,0,85))),   # cai de joelhos
    (0.80,k(LIE_FWD,e='in',hips=(CX,0.38,0.40),hr=(10,60,-8),rf=(-0.18,0.10,-0.20,0,80),lf=(0.15,0.10,-0.22,0,80),
          rh=(-0.42,0.30,1.00),lh=(0.40,0.30,0.95),wworld=(-0.35,0.04,0.95,30,0,85))),
    (1.00,k(LIE_FWD,e='in',wworld=(-0.4,0.04,1.0,40,0,85))),
    (1.30,k(LIE_FWD,e='bounce',wworld=(-0.4,0.04,1.0,40,0,85))),
])
LIE_W=k(LIE_BACK,hips=(CX,0.13,-0.10),rf=(-0.13,0.10,0.80,-4,-80),lf=(0.18,0.10,0.70,20,-80))
FULL['death_wounded']=(1.0,[
    (0.00,k(WOUND)),
    (0.20,k(WOUND,e='out',hips=(CX,0.19,-0.04),hr=(-8,-62,8),sp=(4,8,-4),head=(4,-10,6),aimw=0)),
    (0.65,k(LIE_W,e='in',rh=(-0.60,0.10,-0.40),lh=(0.55,0.10,-0.30),wworld=(-0.45,0.04,0.45,40,0,85))),
    (1.00,k(LIE_W,e='bounce',rh=(-0.60,0.10,-0.40),lh=(0.55,0.10,-0.30),wworld=(-0.45,0.04,0.45,40,0,85))),
])
def full_clip(name):
    dur,keys=FULL[name]; loop=name in ('wound_crawl','wound_aim')
    n=int(round(dur*30)); fr=[]
    for i in range(n if loop else n+1):
        t=min(i/30.0,dur); fr.append(build_pose(interp(keys,t)))
    return dur,fr,loop
FULL_NAMES=list(FULL.keys())
