import sys,numpy as np
sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fbxparse
from PIL import Image, ImageDraw
o=fbxparse.load(__import__('os').environ.get('SOLDIER_FBX','source_models/Soldier.fbx'))[0]
P=o['pos']*0.0254; T=o['tris']; N=o['nrm']
def render(ax_h,ax_v,depth_ax,sign,fn,S=500):
    W=int(1.9*S/1.0); H=int(2.0*S)
    img=np.zeros((H,W,3)); zb=np.full((H,W),-1e9)
    x=(P[:,ax_h]*sign+0.95)*S; y=(1.95-P[:,ax_v])*S; z=P[:,depth_ax]*sign*(1 if depth_ax!=0 else 1)
    light=np.array([0.3,0.5,0.8])
    for t in T:
        xs,ys,zs=x[t],y[t],z[t]
        x0,x1=int(max(0,xs.min())),int(min(W-1,xs.max())+1); y0,y1=int(max(0,ys.min())),int(min(H-1,ys.max())+1)
        if x1<=x0 or y1<=y0: continue
        gx,gy=np.meshgrid(np.arange(x0,x1)+.5,np.arange(y0,y1)+.5)
        d=(ys[1]-ys[2])*(xs[0]-xs[2])+(xs[2]-xs[1])*(ys[0]-ys[2])
        if abs(d)<1e-9: continue
        a=((ys[1]-ys[2])*(gx-xs[2])+(xs[2]-xs[1])*(gy-ys[2]))/d
        b=((ys[2]-ys[0])*(gx-xs[2])+(xs[0]-xs[2])*(gy-ys[2]))/d
        c=1-a-b; m=(a>=0)&(b>=0)&(c>=0)
        zz=a*zs[0]+b*zs[1]+c*zs[2]
        n=N[t].mean(0); sh=0.25+0.75*abs(n@np.array([0.3,0.6,0.7]))
        sub=zb[y0:y1,x0:x1]; upd=m&(zz>sub); sub[upd]=zz[upd]; img[y0:y1,x0:x1][upd]=sh
    im=Image.fromarray((img*255).astype(np.uint8)); d=ImageDraw.Draw(im)
    for k in range(0,20):
        yy=(1.95-k*0.1)*S; d.line([(0,yy),(W,yy)],fill=(255,0,0) if k%5==0 else (90,0,0)); d.text((2,yy-10),f"{k/10:.1f}",fill=(255,255,0))
    for k in range(-9,10):
        xx=(k*0.1+0.95)*S; d.line([(xx,0),(xx,H)],fill=(0,0,255) if k%5==0 else (0,0,90)); d.text((xx+2,2),f"{k/10*sign:.1f}",fill=(0,255,255))
    im.save(fn)
render(0,1,2,1,'work/front.png',S=400)
render(2,1,0,-1,'work/side.png',S=400)
