import sys,numpy as np; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fbxparse
CX=-0.02
# name, parent, world bind position
J=[('Hips',None,(CX,0.97,0.0)),('Spine','Hips',(CX,1.08,0.0)),('Spine1','Spine',(CX,1.22,-0.01)),('Spine2','Spine1',(CX,1.36,-0.02)),
   ('Neck','Spine2',(CX,1.52,-0.025)),('Head','Neck',(CX,1.615,-0.005)),
   ('RightShoulder','Spine2',(CX-0.045,1.455,-0.02)),('RightArm','RightShoulder',(-0.205,1.425,-0.03)),('RightForeArm','RightArm',(-0.445,1.33,-0.03)),('RightHand','RightForeArm',(-0.645,1.262,0.045)),('RightFingers','RightHand',(-0.735,1.236,0.06)),
   ('LeftShoulder','Spine2',(CX+0.045,1.455,-0.02)),('LeftArm','LeftShoulder',(0.185,1.425,-0.03)),('LeftForeArm','LeftArm',(0.425,1.335,-0.035)),('LeftHand','LeftForeArm',(0.62,1.258,0.05)),('LeftFingers','LeftHand',(0.71,1.232,0.065)),
   ('RightUpLeg','Hips',(-0.115,0.925,0.0)),('RightLeg','RightUpLeg',(-0.165,0.52,-0.02)),('RightFoot','RightLeg',(-0.2,0.1,-0.045)),('RightToeBase','RightFoot',(-0.21,0.03,0.1)),
   ('LeftUpLeg','Hips',(0.075,0.925,0.0)),('LeftLeg','LeftUpLeg',(0.115,0.525,-0.02)),('LeftFoot','LeftLeg',(0.155,0.1,-0.045)),('LeftToeBase','LeftFoot',(0.165,0.03,0.1))]
def _lerp(a,b,t): return tuple(a[i]+(b[i]-a[i])*t for i in range(3))
_B={n:p for n,_,p in J}
for _s in ('Right','Left'):
    for _k in (1,2):
        J.append((_s+'ForeArmTwist%d'%_k,_s+'ForeArm',_lerp(_B[_s+'ForeArm'],_B[_s+'Hand'],_k/3.0)))
ENDS={'Head':(CX,1.84,0.0),'RightFingers':(-0.80,1.21,0.065),'LeftFingers':(0.78,1.205,0.07),'RightToeBase':(-0.21,0.02,0.2),'LeftToeBase':(0.165,0.02,0.2),
      'Hips':(CX,1.08,0)}
NAMES=[j[0] for j in J]; IDX={n:i for i,n in enumerate(NAMES)}
PAR=[IDX[p] if p else -1 for _,p,_ in J]
BIND=np.array([j[2] for j in J],float)
def children(i): return [k for k in range(len(J)) if PAR[k]==i]
def seg(i):
    n=NAMES[i]; a=BIND[i]
    ch=[k for k in children(i) if not NAMES[k].endswith('Shoulder') and NAMES[k] not in ('RightUpLeg','LeftUpLeg')]
    b=np.array(ENDS[n]) if n in ENDS else (BIND[ch[0]] if ch else a)
    return a,b
def dseg(P,a,b):
    ab=b-a; t=np.clip(((P-a)@ab)/max(ab@ab,1e-9),0,1); return np.linalg.norm(P-(a+np.outer(t,ab)),axis=1)
def load_body():
    o=fbxparse.load(__import__('os').environ.get('SOLDIER_FBX','source_models/Soldier.fbx'))[0]
    return o
def weights(ctrlP, tris_ctrl):
    P=ctrlP; n=len(P); nb=len(J)
    D=np.stack([dseg(P,*seg(i)) for i in range(nb)],1)
    allow=np.zeros((n,nb),bool)
    x=P[:,0]-CX; y=P[:,1]; ax=np.abs(x); side=np.where(x<0,'Right','Left')
    def A(mask,names):
        for nm in names: allow[mask,IDX[nm]]=True
    for sd in ('Right','Left'):
        S=(side==sd)
        arm=S&(ax>0.17)&(y>1.12)
        A(arm&(ax<0.30),[sd+'Shoulder',sd+'Arm','Spine2'])
        A(arm&(ax>=0.24),[sd+'Arm',sd+'ForeArm'])
        A(arm&(ax>=0.40),[sd+'ForeArm',sd+'Hand'])
        A(arm&(ax>=0.60),[sd+'Hand',sd+'Fingers'])
        torso=S&(ax<=0.24)&(y>0.86)&(y<1.56)
        A(torso,['Hips','Spine','Spine1','Spine2'])
        A(torso&(y>1.38)&(ax>0.06),[sd+'Shoulder'])
        A(torso&(y>1.34)&(ax>0.15),[sd+'Arm'])
        A(torso&(y>1.45),['Neck'])
        leg=S&(y<1.0)
        A(leg,[sd+'UpLeg'])
        A(leg&(y>0.86),['Hips'])
        A(leg&(y<0.62),[sd+'Leg'])
        A(leg&(y<0.16),[sd+'Foot',sd+'ToeBase'])
    head=(y>1.50)&(ax<0.17); A(head,['Neck','Head'])
    A(head&(y<1.56),['Spine2'])
    # fallback
    none=~allow.any(1); allow[none]=True
    W=np.where(allow,1.0/(D+0.01)**4,0); W/=W.sum(1,keepdims=True)
    # adjacency smoothing
    import scipy.sparse as sp
    t=tris_ctrl; r=np.concatenate([t[:,0],t[:,1],t[:,2],t[:,1],t[:,2],t[:,0]]); c=np.concatenate([t[:,1],t[:,2],t[:,0],t[:,0],t[:,1],t[:,2]])
    Adj=sp.coo_matrix((np.ones(len(r)),(r,c)),shape=(n,n)).tocsr(); Adj.data[:]=1
    deg=np.asarray(Adj.sum(1)).ravel(); deg[deg==0]=1
    for it in range(6):
        Wn=(Adj@W)/deg[:,None]; W=0.5*W+0.5*Wn; W=np.where(allow,W,0); W/=W.sum(1,keepdims=True)+1e-12
    # split forearm weight into ForeArm / Twist1 / Twist2 / Hand along the forearm (hat functions)
    for sd in ('Right','Left'):
        fa,t1,t2,ha=IDX[sd+'ForeArm'],IDX[sd+'ForeArmTwist1'],IDX[sd+'ForeArmTwist2'],IDX[sd+'Hand']
        a=BIND[fa]; b=BIND[ha]; ab=b-a; s_=np.clip(((P-a)@ab)/(ab@ab),0,1)
        wf=W[:,fa].copy()
        knots=[(fa,0.0),(t1,1/3),(t2,2/3),(ha,1.0)]
        W[:,fa]=0
        for k,(bi,kt) in enumerate(knots):
            h=np.clip(1-np.abs(s_-kt)*3,0,1)
            W[:,bi]+=wf*h
    W/=W.sum(1,keepdims=True)
    # top4
    idx=np.argsort(-W,1)[:,:4]; w=np.take_along_axis(W,idx,1); w[w<0.02]=0; w/=w.sum(1,keepdims=True)
    return idx.astype(np.uint16),w.astype(np.float32)
