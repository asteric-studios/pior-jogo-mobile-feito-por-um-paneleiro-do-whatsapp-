# Prévia de 1ª pessoa: corpo de 3ª pessoa (cabeça/braços recolhidos) visto dos olhos + viewmodel por cima.
import sys,json,subprocess,numpy as np; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); import bake,anim,clips
from anim import Pose
NB=anim.NB
LC=bake.lower_cache(); UC=bake.upper_cache()
shots=[('olhando_baixo','idle',-55,'hip',72,None),('olhando_pes','walk_f',-78,'hip',72,None),('andando_hip','walk_f',-8,'hip',72,None),('ads_luneta','idle',0,'ads',40,0.18),('olhando_baixo_ads','idle',-35,'ads',40,0.18)]
combos={f'b{i}':(lo,'up_aim',float(np.clip(pit,-14.3,20)),0.0) for i,(n,lo,pit,_,_,_) in enumerate(shots)}
bake.export_glb('work/fp/body.glb',combos,LC,UC,texsize=512)
roots={}
for l in open('tools/rust_anim_test/vm_poses.txt'):
    r=l.strip().split(','); v=list(map(float,r[1:])); roots[r[0]]=','.join(str(x) for x in v[NB*4+17:NB*4+24])
jobs=[]
for i,(n,lo,pit,st,fov,gh) in enumerate(shots):
    ldur,lfr=LC[lo]; udur,ufr,uoff=UC['up_aim']
    p=bake.compose(lfr[0],ufr[0],float(np.clip(pit,-14.3,20)),uoff[0])
    Gr,Gp,Wp,Wr=bake.fk(p)
    head=Gp[anim.IDX['Head']]; a=np.radians(pit); d=np.array([0,np.sin(a),np.cos(a)])
    eye=head+np.array([0,0.07+0.04*np.sin(a),0])+np.array([0,0,1.0])*(0.09+0.03*np.cos(a)+0.10*max(0.0,-np.sin(a))); tgt=eye+d
    url=(f"f=work/fp/body.glb&anim=b{i}&t=0&cam={','.join('%.4f'%x for x in eye)}&tgt={','.join('%.4f'%x for x in tgt)}&fov={fov}"
         f"&hide=Neck,RightArm,LeftArm&hidew=1&vm=work/vm_states.glb&vmanim={st}&vmroot={roots[st]}&w=640&h=360"+(f"&ghost={gh}" if gh else ""))
    jobs.append([url,f'work/fp/{n}.png'])
json.dump(jobs,open('work/fp/jobs.json','w')); json.dump([s[0] for s in shots]+[s[5] for s in shots],open('work/fp/meta.json','w'))
