const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage({viewport:{width:1600,height:1600}});
p.on('console',m=>{if(m.type()==='error')console.log('CONSOLE',m.text())});
const jobs=JSON.parse(process.argv[2]);
for(const [q,out] of jobs){await p.goto('http://localhost:8765/index.html?'+q);
 await p.waitForFunction(()=>document.title.startsWith('DONE')||document.title.startsWith('ERR')||document.title=='NOCLIP',null,{timeout:120000});
 const t=await p.title(); if(t!='DONE') console.log(out,t);
 await p.locator('canvas').screenshot({path:out});}
await b.close();})();
