import sys,json,numpy as np; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from gltfio import Writer; import rig, body, prep_gun
def tangents(B):
    P=B['pos'].astype(np.float64); N=B['nrm'].astype(np.float64); UV=B['uv'].astype(np.float64); I=B['idx'].reshape(-1,3)
    t=np.zeros_like(P); bt=np.zeros_like(P)
    e1=P[I[:,1]]-P[I[:,0]]; e2=P[I[:,2]]-P[I[:,0]]; d1=UV[I[:,1]]-UV[I[:,0]]; d2=UV[I[:,2]]-UV[I[:,0]]
    r=d1[:,0]*d2[:,1]-d2[:,0]*d1[:,1]; r=np.where(np.abs(r)<1e-12,1e-12,r)
    sd=(e1*d2[:,1:2]-e2*d1[:,1:2])/r[:,None]; td=(e2*d1[:,0:1]-e1*d2[:,0:1])/r[:,None]
    for k in range(3): np.add.at(t,I[:,k],sd); np.add.at(bt,I[:,k],td)
    t=t-N*(N*t).sum(1,keepdims=True); n=np.linalg.norm(t,axis=1,keepdims=True)
    fb=np.cross(N,np.array([0,1.0,0])); fb[np.linalg.norm(fb,axis=1)<1e-6]=[1,0,0]
    t=np.where(n>1e-9,t/np.maximum(n,1e-12),fb/np.linalg.norm(fb,axis=1,keepdims=True))
    wv=np.where((np.cross(N,t)*bt).sum(1)<0,-1.0,1.0)
    return np.concatenate([t,wv[:,None]],1).astype(np.float32)
def build(out, anims=None, gun=True, texsize=1024, weapon_rest=None, variant='soldier'):
    B=body.build_body() if variant in ('soldier','viewmodel') else body.build_spetsnaz(); w=Writer(); j=w.j
    if variant=='viewmodel':
        # so bracos/maos (triangulos cujos 3 vertices sao dominados por ossos do braco)
        arm=set(rig.IDX[s+n] for s in ('Right','Left') for n in ('Arm','ForeArm','Hand','Fingers','ForeArmTwist1','ForeArmTwist2'))
        dom=B['joints'][np.arange(len(B['joints'])),np.argmax(B['wts'],1)]
        ok=np.array([d in arm for d in dom])
        tri=B['idx'].reshape(-1,3); keep=ok[tri].all(1)
        B['idx']=tri[keep].reshape(-1).astype(np.uint32)
    base,nm=body.fabric_textures()
    if variant!='soldier': base=body.snow_camo_texture()
    tb=w.image(base,'image/jpeg'); tn=w.image(nm,'image/png')
    j['materials'].append({'name':'SoldierCloth','pbrMetallicRoughness':{'baseColorTexture':{'index':tb},'metallicFactor':0.0,'roughnessFactor':0.9},'normalTexture':{'index':tn,'scale':0.5},'doubleSided':True})
    a={'POSITION':w.accessor(B['pos'],5126,'VEC3',34962,minmax=True),'NORMAL':w.accessor(B['nrm'],5126,'VEC3',34962),
       'TEXCOORD_0':w.accessor(B['uv'],5126,'VEC2',34962),'COLOR_0':w.accessor(B['col'],5126,'VEC4',34962),
       'TANGENT':w.accessor(tangents(B),5126,'VEC4',34962),
       'JOINTS_0':w.accessor(B['joints'],5123,'VEC4',34962),'WEIGHTS_0':w.accessor(B['wts'],5126,'VEC4',34962)}
    j['meshes'].append({'name':'SoldierBody','primitives':[{'attributes':a,'indices':w.accessor(B['idx'],5125,'SCALAR',34963),'material':0}]})
    # nodes: 0 Soldier root, 1 Body, then joints
    j['nodes'].append({'name':'Soldier','children':[]}); j['nodes'].append({'name':'SoldierBody','mesh':0,'skin':0})
    J0=len(j['nodes'])
    for i,n in enumerate(rig.NAMES):
        p=rig.PAR[i]; t=rig.BIND[i]-(rig.BIND[p] if p>=0 else 0)
        j['nodes'].append({'name':n,'translation':[float(v) for v in t]})
    for i in range(len(rig.NAMES)):
        ch=[J0+k for k in rig.children(i)]
        if ch: j['nodes'][J0+i]['children']=ch
    j['nodes'][0]['children']=[1,J0]
    ibm=np.zeros((len(rig.NAMES),16),np.float32)
    for i in range(len(rig.NAMES)):
        M=np.eye(4); M[:3,3]=-rig.BIND[i]; ibm[i]=M.T.reshape(-1)
    j['skins']=[{'name':'SoldierSkin','joints':[J0+i for i in range(len(rig.NAMES))],'skeleton':J0,'inverseBindMatrices':w.accessor(ibm,5126,'MAT4')}]
    if gun:
        sp=J0+rig.IDX['Spine2']
        wr=weapon_rest or {'translation':[-0.1,0.0,0.45],'rotation':[0,0,0,1]}
        wn={'name':'Weapon','children':[],**wr}; j['nodes'].append(wn); wi=len(j['nodes'])-1
        j['nodes'][sp].setdefault('children',[]).append(wi)
        prep_gun.add_gun(w,wn['children'],texsize,skip_mats=(2,3,5) if variant=='viewmodel' else ())
        j['nodes'].append({'name':'Muzzle','translation':[0,0.0,0.545]}); wn['children'].append(len(j['nodes'])-1)
    j['scenes'][0]['nodes']=[0]
    if anims: anims(w,J0)
    w.save(out); return B
if __name__=='__main__':
    build('work/soldier_static.glb',gun=False)
