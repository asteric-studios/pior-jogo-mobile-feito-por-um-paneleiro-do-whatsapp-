import numpy as np
R=np.load('work/refs.npy'); mx=0;mq=0;per=[]
for i,line in enumerate(open('tools/rust_anim_test/rust_out.txt')):
    a,b=line.strip().split('|'); g,w=a.split('W')
    G=np.array([[float(x) for x in t.split(',')] for t in g.strip(';').split(';')]).ravel()
    W=np.array([float(x) for x in w.split(',')]); Q=np.array([float(x) for x in b.split(',')])
    ref=R[i]; n=len(G); e=max(np.abs(G-ref[:n]).max(),np.abs(W-ref[n:n+3]).max()); eq=min(np.abs(Q-ref[n+3:]).max(),np.abs(Q+ref[n+3:]).max())
    per.append(e); mx=max(mx,e); mq=max(mq,eq)
print('casos',len(per),'diferenca maxima posicoes %.3f mm, quat twist %.5f'%(mx*1000,mq)); print(np.round(np.array(per)*1000,3))
