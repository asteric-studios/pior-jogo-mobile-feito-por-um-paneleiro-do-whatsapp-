#[path = "../../../src/anim_core.rs"]
mod anim_core;
#[path = "../../../src/animator.rs"]
mod animator;
#[path = "../../../src/nav.rs"]
mod nav;
#[path = "../../../src/map.rs"]
mod map;
use anim_core::*;
use animator::*;
use bevy::math::{Vec2, Vec3};
use std::io::Write;

fn compare(d: &AnimData) {
    let txt = std::fs::read_to_string("cases.txt").unwrap();
    let mut out = String::new();
    for line in txt.lines() {
        let f: Vec<&str> = line.split('|').collect();
        let (lo, li, up, ui) = (f[0], f[1].parse::<usize>().unwrap(), f[2], f[3].parse::<usize>().unwrap());
        let v: Vec<f32> = f[4].split(',').map(|x| x.parse().unwrap()).collect();
        let l = d.clip(lo).frames[li];
        let u = d.clip(up).frames[ui];
        let pr = Procedural {
            legs_yaw: v[2], hips_dy: v[3], feet: if v[4] > 0.5 { Some((v[5], v[6])) } else { None },
            bob_phase: v[7], bob_amt: v[8], lean_roll: v[9], lean_pitch: v[10],
            sway_yaw: v[11], sway_pitch: v[12], flinch: Vec3::new(v[13], v[14], v[15]), recoil: v[16],
        };
        let p = d.compose(&l, &u, v[0], v[1], &pr);
        let fk = d.fk(&p);
        for i in 0..NB { out += &format!("{:.5},{:.5},{:.5};", fk.gp[i].x, fk.gp[i].y, fk.gp[i].z); }
        let r = p.rot[24];
        out += &format!("W{:.5},{:.5},{:.5}|{:.5},{:.5},{:.5},{:.5}\n", fk.wp.x, fk.wp.y, fk.wp.z, r.x, r.y, r.z, r.w);
    }
    std::fs::write("rust_out.txt", out).unwrap();
}

fn sim(d: &AnimData) {
    let mut a = Animator::default();
    let mut f = std::fs::File::create("sim_poses.txt").unwrap();
    let dt = 1.0 / 30.0;
    let mut t = 0.0f32;
    let mut worst_hand = 0.0f32;
    let mut nan = false;
    // roteiro: (duração, velocidade local, giro/s da raiz, agachado, sprint, ads, mira, recarga, no ar, corpo inteiro)
    struct Seg { dur: f32, vel: Vec2, yaw_rate: f32, crouch: bool, sprint: bool, ads: bool, upper: UpperMode, reload: bool, air: bool, full: Option<&'static str>, hit: bool }
    let s = |dur, vel: Vec2, yaw_rate, upper| Seg { dur, vel, yaw_rate, crouch: false, sprint: false, ads: false, upper, reload: false, air: false, full: None, hit: false };
    let mut segs = vec![
        s(1.0, Vec2::ZERO, 0.0, UpperMode::Low),
        s(1.0, Vec2::ZERO, 1.6, UpperMode::Low),            // gira parado -> pernas dão passos
        s(1.0, Vec2::new(0.0, 3.6), 0.0, UpperMode::Low),    // corre
        s(1.0, Vec2::new(-1.6, 1.6), 0.3, UpperMode::Aim),   // diagonal mirando
        Seg { sprint: true, ..s(1.0, Vec2::new(0.0, 6.0), 0.0, UpperMode::Sprint) },
        Seg { crouch: true, ..s(1.0, Vec2::new(1.5, 0.0), 0.0, UpperMode::Aim) },
        Seg { air: true, ..s(0.5, Vec2::new(0.0, 3.0), 0.0, UpperMode::Low) },
        Seg { reload: true, ..s(2.3, Vec2::ZERO, 0.0, UpperMode::Aim) },
        Seg { hit: true, ..s(0.6, Vec2::ZERO, 0.0, UpperMode::Aim) },
        Seg { full: Some("wound_fall"), ..s(1.25, Vec2::ZERO, 0.0, UpperMode::Aim) },
        Seg { full: Some("wound_crawl"), ..s(2.5, Vec2::new(0.0, -0.3), 0.0, UpperMode::Aim) },
        Seg { full: Some("wound_aim"), ..s(1.0, Vec2::ZERO, 0.0, UpperMode::Aim) },
        Seg { full: Some("death_wounded"), ..s(1.2, Vec2::ZERO, 0.0, UpperMode::Aim) },
    ];
    let mut frame = 0;
    let mut was_air = false;
    for seg in segs.drain(..) {
        let n = (seg.dur / dt).round() as i32;
        let mut st = 0.0f32;
        for k in 0..n {
            if seg.hit && k == 2 { a.hit(Vec3::new(0.0, 0.0, -1.0), 1, 1.0); }
            if was_air && !seg.air { a.land(5.0); }
            was_air = seg.air;
            let inp = AnimInput {
                dt, vel_local: seg.vel, grounded: !seg.air, crouch: seg.crouch, sprint: seg.sprint, ads: seg.ads,
                upper: seg.upper, reload_t: if seg.reload { Some(st) } else { None }, aim_yaw: 0.0, aim_pitch: 0.1,
                root_yaw_delta: seg.yaw_rate * dt, pitch_delta: 0.0, recoil: 0.0,
                feet: Some((0.0, 0.0)), full: seg.full.map(|c| (c, st)),
            };
            let p = a.update(d, &inp);
            let fk = d.fk(&p);
            for q in p.rot.iter() { if !q.is_finite() { nan = true; } }
            if p.ikr > 0.99 && a.full_w < 0.01 && seg.reload == false {
                let tw = fk.wp + fk.wr * d.grips[0].0;
                worst_hand = worst_hand.max((fk.gp[R_HAND] - tw).length());
            }
            let mut line = format!("{frame}");
            for q in p.rot.iter() { line += &format!(",{},{},{},{}", q.x, q.y, q.z, q.w); }
            for v in [p.hips, p.wpos, p.mpos] { line += &format!(",{},{},{}", v.x, v.y, v.z); }
            for q in [p.wrot, p.mrot] { line += &format!(",{},{},{},{}", q.x, q.y, q.z, q.w); }
            writeln!(f, "{line}").unwrap();
            frame += 1;
            st += dt;
            t += dt;
        }
    }
    println!("sim: {frame} quadros, {t:.1}s, NaN={nan}, erro max mao direita {:.2} mm, legs_yaw final {:.3}", worst_hand * 1000.0, a.legs_yaw);
}

fn navtest() {
    let obs = map::obstacles();
    let g = nav::NavGrid::build(&obs, map::HALF, 0.5, 0.45);
    let covers = nav::gen_covers(&obs, &g);
    let blocked = g.blocked.iter().filter(|b| **b).count();
    println!("nav: grade {}x{}, {} celulas bloqueadas, {} pontos de cobertura ({} baixas)", g.w, g.h, blocked, covers.len(), covers.iter().filter(|c| c.low).count());
    let t0 = std::time::Instant::now();
    let p = g.path(Vec3::new(0.0, 0.0, -24.0), Vec3::new(0.0, 0.0, 8.0)).expect("sem caminho");
    println!("caminho com {} pontos em {:?}: {:?}", p.len(), t0.elapsed(), p.iter().map(|v| (v.x * 10.0).round() / 10.0).zip(p.iter().map(|v| (v.z * 10.0).round() / 10.0)).collect::<Vec<_>>());
    for w in p.windows(2) { assert!(g.clear_line(w[0], w[1]), "caminho atravessa obstaculo"); }
    let p2 = g.path(Vec3::new(-14.0, 0.0, 8.0), Vec3::new(16.0, 0.0, 10.0));
    println!("caminho para dentro de obstaculos: {:?}", p2.map(|v| v.len()));
    // raio x cápsula
    let h = nav::ray_capsule(Vec3::new(0.0, 1.0, 5.0), Vec3::NEG_Z, Vec3::new(0.0, 0.5, 0.0), Vec3::new(0.0, 1.5, 0.0), 0.2);
    let m = nav::ray_capsule(Vec3::new(0.5, 1.0, 5.0), Vec3::NEG_Z, Vec3::new(0.0, 0.5, 0.0), Vec3::new(0.0, 1.5, 0.0), 0.2);
    println!("raio-capsula: acerto {:?} (esperado ~4.8), erro {:?}", h, m);
    let mut s = String::new();
    for c in &covers { s += &format!("{},{},{},{},{}\n", c.pos.x, c.pos.z, c.normal.x, c.normal.z, c.low as u8); }
    std::fs::write("covers.txt", s).unwrap();
    let mut s = String::new();
    for y in 0..g.h { for x in 0..g.w { s.push(if g.blocked[y * g.w + x] { '#' } else { '.' }); } s.push('\n'); }
    std::fs::write("grid.txt", s).unwrap();
    let mut s = String::new();
    for v in &p { s += &format!("{},{}\n", v.x, v.z); }
    std::fs::write("path.txt", s).unwrap();
}

fn vmtest(d: &AnimData) {
    let mut v = ViewmodelAnim::default();
    let mut out = String::new();
    let mut inp = VmInput { dt: 1.0 / 60.0, grounded: true, ..Default::default() };
    let mut dump = |name: &str, root: Rt, p: &Pose, out: &mut String| {
        let mut l = format!("{name}");
        for q in p.rot.iter() { l += &format!(",{},{},{},{}", q.x, q.y, q.z, q.w); }
        for x in [p.hips, p.wpos, p.mpos] { l += &format!(",{},{},{}", x.x, x.y, x.z); }
        for q in [p.wrot, p.mrot] { l += &format!(",{},{},{},{}", q.x, q.y, q.z, q.w); }
        l += &format!(",{},{},{},{},{},{},{}\n", root.p.x, root.p.y, root.p.z, root.r.x, root.r.y, root.r.z, root.r.w);
        out.push_str(&l);
    };
    let mut last = (Rt { p: Vec3::ZERO, r: bevy::math::Quat::IDENTITY }, Pose::default());
    for _ in 0..60 { last = v.update(d, &inp); }
    dump("hip", last.0, &last.1, &mut out);
    inp.ads = true;
    for _ in 0..60 { last = v.update(d, &inp); }
    dump("ads", last.0, &last.1, &mut out);
    // alinhamento: centro da luneta no eixo da câmera
    let f = d.fk(&last.1);
    let eye = last.0.p + last.0.r * (f.wp + f.wr * Vec3::new(0.0, 0.0975, 0.2));
    let dir = last.0.r * (f.wr * Vec3::Z);
    println!("ADS: ponto da luneta na camera {:?}, direcao {:?}", (eye * 1000.0).round() / 1000.0, (dir * 1000.0).round() / 1000.0);
    inp.ads = false; inp.vel_local = Vec2::new(0.0, 3.7);
    for _ in 0..37 { last = v.update(d, &inp); }
    dump("walk", last.0, &last.1, &mut out);
    inp.sprint = true; inp.vel_local = Vec2::new(0.0, 6.0);
    for _ in 0..60 { last = v.update(d, &inp); }
    dump("sprint", last.0, &last.1, &mut out);
    inp.sprint = false; inp.vel_local = Vec2::ZERO;
    for k in 0..80 { inp.reload_t = Some(k as f32 / 60.0); last = v.update(d, &inp); }
    dump("reload", last.0, &last.1, &mut out);
    inp.reload_t = None;
    for _ in 0..40 { last = v.update(d, &inp); }
    inp.shot = true; last = v.update(d, &inp); inp.shot = false;
    for _ in 0..3 { last = v.update(d, &inp); }
    dump("recoil", last.0, &last.1, &mut out);
    inp.yaw_delta = 0.05;
    for _ in 0..8 { last = v.update(d, &inp); }
    dump("sway", last.0, &last.1, &mut out);
    std::fs::write("vm_poses.txt", out).unwrap();
}

/// Estresse do viewmodel: entradas aleatórias com dt variável; mede saltos por quadro,
/// NaN e o erro das mãos no punho/guarda-mão.
fn vmstress(d: &AnimData) {
    let mut v = ViewmodelAnim::default();
    let mut rng = 0x9E3779B97F4A7C15u64;
    let mut rnd = || { rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17; (rng >> 11) as f32 / (1u64 << 53) as f32 };
    let mut inp = VmInput { dt: 1.0 / 60.0, grounded: true, ..Default::default() };
    let mut prev: Option<(Rt, Vec3)> = None;
    let (mut max_dp, mut max_da, mut worst_r, mut worst_l, mut nan) = (0.0f32, 0.0f32, 0.0f32, 0.0f32, false);
    let mut reload: Option<f32> = None;
    let mut t = 0.0;
    let mut since_shot = 0.0;
    while t < 60.0 {
        let dt = if rnd() < 0.1 { 1.0 / 20.0 } else { 1.0 / 60.0 };
        inp.dt = dt;
        if rnd() < 0.01 { inp.ads = !inp.ads; }
        if rnd() < 0.006 { inp.sprint = !inp.sprint && !inp.ads && reload.is_none(); }
        if rnd() < 0.004 { inp.crouch = !inp.crouch; }
        if reload.is_none() && rnd() < 0.002 { reload = Some(0.0); inp.sprint = false; }
        if let Some(r) = reload { let r = r + dt; reload = if r > 2.3 { None } else { Some(r) }; }
        inp.reload_t = reload;
        let spd = if inp.sprint { 6.0 } else if rnd() < 0.5 { 3.5 } else { 0.0 };
        inp.vel_local = Vec2::new((rnd() - 0.5) * spd * 0.5, spd);
        inp.yaw_delta = (rnd() - 0.5) * 0.06;
        inp.pitch_delta = (rnd() - 0.5) * 0.03;
        since_shot += dt;
        inp.shot = reload.is_none() && !inp.sprint && since_shot > 0.1 && rnd() < 0.3;
        if inp.shot { since_shot = 0.0; }
        inp.landed = if rnd() < 0.003 { 6.0 } else { 0.0 };
        let (root, p) = v.update(d, &inp);
        if !root.p.is_finite() || !root.r.is_finite() || p.rot.iter().any(|q| !q.is_finite()) { nan = true; }
        let fk0 = d.fk(&p);
        let wcam = Rt { p: root.p + root.r * fk0.wp, r: root.r * fk0.wr };
        let lh = root.p + root.r * fk0.gp[L_HAND];
        if let Some((pr, plh)) = prev {
            let j = (wcam.p - pr.p).length().max((lh - plh).length() * 0.5) / (dt * 60.0);
            max_dp = max_dp.max(j);
            max_da = max_da.max(wcam.r.angle_between(pr.r).to_degrees() / (dt * 60.0));
        }
        prev = Some((wcam, lh));
        let fk = d.fk(&p);
        if reload.is_none() && p.ikr > 0.99 {
            worst_r = worst_r.max((fk.gp[R_HAND] - (fk.wp + fk.wr * d.grips[0].0)).length());
        }
        if reload.is_none() && p.ikl > 0.99 {
            worst_l = worst_l.max((fk.gp[L_HAND] - (fk.wp + fk.wr * d.grips[1].0)).length());
        }
        t += dt;
    }
    println!("viewmodel 60s: NaN={nan}, salto max {:.1} mm/quadro60, giro max {:.2} graus/quadro60, erro mao D {:.2} mm, E {:.2} mm",
        max_dp * 1000.0, max_da, worst_r * 1000.0, worst_l * 1000.0);
}

fn main() {
    let d = AnimData::parse(&std::fs::read("../../assets/anims.bin").unwrap());
    compare(&d);
    sim(&d);
    navtest();
    vmtest(&d);
    vmstress(&d);
}
