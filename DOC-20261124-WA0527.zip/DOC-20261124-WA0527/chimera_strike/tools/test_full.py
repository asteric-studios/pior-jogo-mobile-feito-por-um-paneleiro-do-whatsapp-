import sys; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); import bake,clips,clips2
LC={};UC={}; combos={}
for n in clips2.FULL_NAMES:
    d,fr,loop=clips2.full_clip(n); LC[n]=(d,fr); UC[n]=(d,fr,[0.0]*len(fr))
    if not loop: bake.NONLOOP.add(n)
    combos[n]=(n,n,0,d)
bake.export_glb('work/full_test.glb',combos,LC,UC,texsize=256,variant='spetsnaz')
