import numpy as np, sys, struct, json; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from qm import *; import rig, anim, clips, build
from anim import IDX, fk
NONLOOP=set()
def compose(lo,up,aim_pitch_deg,off_deg,recoil=None):
    p=up.copy(); p.hips=lo.hips.copy()
    for i in anim.LOWER: p.rot[i]=lo.rot[i].copy()
    a=(aim_pitch_deg-off_deg)*np.pi/180
    anim.aim_correct(p,np.array([0,np.sin(a),np.cos(a)]),p.aimw)
    b=aim_pitch_deg*np.pi/180
    anim.head_look(p,np.array([0,np.sin(b),np.cos(b)]),0.5*p.aimw+0.2)
    anim.arm_ik(p,clips.GRIPS,1.0,p.ikl)
    anim.apply_twist(p)
    return p
def hand_err(p):
    Gr,Gp,Wp,Wr=fk(p); e=[]
    for side,(gp,gr) in zip(('Right','Left'),clips.GRIPS):
        e.append(np.linalg.norm(Gp[IDX[side+'Hand']]-(Wp+qrot(Wr,gp))))
    return e
def lower_cache():
    return {n:clips.lower_clip(n) for n in clips.LOWER_CLIPS}
def upper_cache():
    return {n:clips.upper_clip(n) for n in clips.UPPER_CLIPS}
def write_bin(path,LC,UC):
    out=bytearray(); f32=lambda *a: struct.pack('<%df'%len(a),*a)
    out+=b'CHA2'; out+=struct.pack('<I',anim.NB)
    for i in range(anim.NB): out+=f32(*anim.T0[i])
    for gp,gr in clips.GRIPS: out+=f32(*gp,*gr)
    out+=f32(*clips.MAG_REST)
    SPD={'walk':1.35,'jog':3.0,'sprint':5.0,'crouch':1.3}
    import clips2
    allc=[(n,0,d,fr,[0]*len(fr)) for n,(d,fr) in LC.items()]+[(n,2 if n=='up_reload' else 1,d,fr,offs) for n,(d,fr,offs) in UC.items()]
    for n in clips2.FULL_NAMES:
        d,fr,loop=clips2.full_clip(n); allc.append((n,3 if loop else 4,d,fr,[0.0]*len(fr)))
    out+=struct.pack('<I',len(allc))
    for n,kind,dur,fr,offs in allc:
        nb=n.encode(); sp=SPD.get(n.split('_')[0],0.0) if kind==0 and '_' in n and n!='crouch_idle' else 0.0
        out+=struct.pack('<I',len(nb))+nb+struct.pack('<IffI',kind,dur,sp,len(fr))
        for p,o in zip(fr,offs):
            for i in range(anim.NB): out+=f32(*p.rot[i])
            out+=f32(*p.hips,*p.wpos,*p.wrot,*p.mpos,*p.mrot,p.ikl,p.ikr,p.aimw,o)
    open(path,'wb').write(out); return len(out)
def export_glb(path,combos,LC,UC,texsize=1024,variant='soldier'):
    ref,_=clips.upper_aim(0)
    def anims_fn(w,J0):
        j=w.j; nid={n['name']:i for i,n in enumerate(j['nodes']) if 'name' in n}
        j['animations']=[]
        for name,(ln,un,pitch,dur) in combos.items():
            ldur,lfr=LC[ln]; udur,ufr,uoff=UC[un]; n=int(round(dur*30))+1
            frames=[]
            for k in range(n):
                t=k/30
                nonloop=(un=='up_reload' or un in NONLOOP)
                lo=lfr[min(int(round(t*30)),len(lfr)-1)] if ln in NONLOOP else lfr[int(round(t/ldur*len(lfr)))%len(lfr)]
                ui=min(int(round(t*30)),len(ufr)-1) if nonloop else int(round(t*30))%len(ufr)
                frames.append(compose(lo,ufr[ui],pitch,uoff[ui]))
            times=np.arange(n,dtype=np.float32)/30; ta=w.accessor(times.reshape(-1,1),5126,'SCALAR',minmax=True)
            ch=[];sm=[]
            def add(node,path,vals,typ):
                sm.append({'input':ta,'output':w.accessor(np.array(vals,np.float32),5126,typ),'interpolation':'LINEAR'})
                ch.append({'sampler':len(sm)-1,'target':{'node':node,'path':path}})
            for i in range(anim.NB):
                vals=[f.rot[i] for f in frames]
                for k in range(1,len(vals)):
                    if np.dot(vals[k],vals[k-1])<0: vals[k]=-vals[k]
                add(J0+i,'rotation',vals,'VEC4')
            add(J0,'translation',[f.hips for f in frames],'VEC3')
            add(nid['Weapon'],'translation',[f.wpos for f in frames],'VEC3'); add(nid['Weapon'],'rotation',[f.wrot for f in frames],'VEC4')
            add(nid['Magazine'],'translation',[f.mpos for f in frames],'VEC3'); add(nid['Magazine'],'rotation',[f.mrot for f in frames],'VEC4')
            j['animations'].append({'name':name,'channels':ch,'samplers':sm})
            err=np.array([hand_err(f) for f in frames]); print(f'{name:14s} hand err max R={err[:,0].max()*1000:.1f}mm L={np.max(err[:,1]*np.array([f.ikl for f in frames]))*1000:.1f}mm')
    build.build(path,anims=anims_fn,texsize=texsize,variant=variant,weapon_rest={'translation':[float(x) for x in ref.wpos],'rotation':[float(x) for x in ref.wrot]})
def final_assets(outdir):
    LC=lower_cache(); UC=upper_cache(); ref,_=clips.upper_aim(0)
    wr={'translation':[float(x) for x in ref.wpos],'rotation':[float(x) for x in ref.wrot]}
    build.build(outdir+'/soldier.glb',texsize=1024,weapon_rest=wr)
    build.build(outdir+'/spetsnaz.glb',texsize=1024,weapon_rest=wr,variant='spetsnaz')
    build.build(outdir+'/viewmodel.glb',texsize=1024,weapon_rest=wr,variant='viewmodel')
    print('bin',write_bin(outdir+'/anims.bin',LC,UC))
if __name__=='__main__' and len(sys.argv)>1 and sys.argv[1]=='final':
    final_assets(sys.argv[2]); sys.exit(0)
if __name__=='__main__':
    LC=lower_cache(); UC=upper_cache()
    combos={'idle_aim':('idle','up_aim',0,3.0),'idle_low':('idle','up_low',0,3.0),'jog_f_aim':('jog_f','up_aim',0,clips.LOWER_SPECS['jog']['T']*2),
            'walk_f':('walk_f','up_aim',0,2.0),'walk_l':('walk_l','up_aim',0,2.0),'walk_b':('walk_b','up_aim',0,2.0),'jog_r':('jog_r','up_aim',0,1.32),
            'sprint':('sprint_f','up_sprint',0,clips.SPR_T*2),'crouch_f':('crouch_f','up_aim',0,2.0),'crouch_idle':('crouch_idle','up_aim',0,3.0),
            'reload':('idle','up_reload',0,clips.RELOAD_T),'aim_up':('idle','up_aim',35,1.0),'aim_down':('idle','up_aim',-35,1.0),'jump':('jump','up_aim',0,1.0)}
    export_glb('work/soldier_anim.glb',combos,LC,UC,texsize=int(sys.argv[1]) if len(sys.argv)>1 else 512)
    print('bin bytes',write_bin('work/anims.bin',LC,UC))
