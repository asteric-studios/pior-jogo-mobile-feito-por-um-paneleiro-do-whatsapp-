"""Modelo de referencia da composicao em tempo real (espelhado 1:1 em src/anim_core.rs)."""
import numpy as np, sys, os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from qm import *; import anim, clips
from anim import fk, ik2, IDX, T0, PAR
D=np.pi/180
SPINE=[IDX['Spine'],IDX['Spine1'],IDX['Spine2']]
def aim_dir(yaw,pitch): return np.array([np.sin(yaw)*np.cos(pitch),np.sin(pitch),np.cos(yaw)*np.cos(pitch)])
def axis_angle(v):
    a=np.linalg.norm(v)
    return q() if a<1e-8 else qaxis(v/a,a)
def foot_ground(p,dl,dr):
    drop=min(0.0,dl,dr)
    Gr,Gp,_,_=fk(p)
    feet={s:(Gp[IDX[s+'Foot']].copy(),Gr[IDX[s+'Foot']].copy(),Gp[IDX[s+'Leg']].copy(),Gp[IDX[s+'UpLeg']].copy()) for s in ('Right','Left')}
    p.hips=p.hips+np.array([0,drop,0])
    for s,d in (('Right',dr),('Left',dl)):
        ank,fr,knee,hip=feet[s]
        if abs(d-drop)<1e-4 and abs(drop)<1e-4: continue
        tgt=ank+np.array([0,d,0])
        mid=(hip+ank)*0.5; pole=knee-mid
        if np.linalg.norm(pole)<1e-4: pole=qrot(fr,np.array([0,0,1.0]))
        ik2(p,IDX[s+'UpLeg'],IDX[s+'Leg'],IDX[s+'Foot'],tgt,fr,pole,anim.LEG_FLEX,1.0)
def compose2(lo,up,aim_yaw,aim_pitch,P):
    p=up.copy(); p.hips=lo.hips.copy()
    for i in anim.LOWER: p.rot[i]=lo.rot[i].copy()
    # 1) giro das pernas (turn in place) + queda de quadril (aterrissagem)
    ly=P.get('legs_yaw',0.0)
    if abs(ly)>1e-6:
        r=qy(ly); p.rot[0]=qmul(r,p.rot[0]); h=p.hips.copy(); hx=qrot(r,np.array([h[0],0,h[2]])); p.hips=np.array([hx[0],h[1],hx[2]])
    p.hips=p.hips+np.array([0,P.get('hips_dy',0.0),0])
    # 2) IK dos pes no terreno
    if P.get('feet') is not None:
        dl,dr=P['feet']; foot_ground(p,dl,dr)
    # 3) balanco do passo e inclinacao (no tronco)
    ph,amt=P.get('bob',(0.0,0.0))
    if amt>0:
        s1=IDX['Spine1']; s=np.sin(2*np.pi*ph); s2=np.sin(4*np.pi*ph)
        p.rot[s1]=qmul(p.rot[s1],ypr(4*amt*s,1.5*amt*s2,3*amt*s))
    lr,lp=P.get('lean',(0.0,0.0))
    if abs(lr)+abs(lp)>1e-6: anim.pre_rotate_chain(p,[IDX['Spine']],qmul(qx(lp),qz(lr)))
    # 4) correcao de mira + cabeca
    aimw=p.aimw
    anim.aim_correct(p,aim_dir(aim_yaw,aim_pitch-p.aimoff*D),aimw)
    anim.head_look(p,aim_dir(aim_yaw,aim_pitch),0.5*aimw+0.2)
    # 5) balanco da arma (atraso ao girar) e reacao a tiro
    sy,sp=P.get('sway',(0.0,0.0)); fl=np.asarray(P.get('flinch',(0,0,0)),float)
    qs=qmul(ypr(sy,sp,0,deg=False),axis_angle(fl))
    if abs(qs[3])<0.999999: anim.pre_rotate_chain(p,[IDX['Spine1'],IDX['Spine2']],qs)
    if np.linalg.norm(fl)>1e-6: anim.pre_rotate_chain(p,[IDX['Neck'],IDX['Head']],axis_angle(fl*0.6))
    # 6) recuo
    rc=P.get('recoil',0.0)
    if rc>0:
        Gr,_,_,_=fk(p); s2=IDX['Spine2']
        p.rot[s2]=qmul(qconj(Gr[PAR[s2]]),qmul(qx(-rc*3.5*D),Gr[s2]))
        p.wpos=p.wpos+qrot(p.wrot,np.array([0,0.004*rc,-0.03*rc])); p.wrot=qmul(p.wrot,qx(-rc*2.5*D))
    # 7) IK das maos e torcao do antebraco
    anim.arm_ik(p,clips.GRIPS,p.ikr,p.ikl)
    anim.apply_twist(p)
    return p
