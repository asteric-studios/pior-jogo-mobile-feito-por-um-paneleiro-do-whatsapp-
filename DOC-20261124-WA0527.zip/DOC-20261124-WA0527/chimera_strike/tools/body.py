import sys,io,numpy as np; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fbxparse, rig
from PIL import Image, ImageFilter
def build_body():
    o=fbxparse.load(__import__('os').environ.get('SOLDIER_FBX','source_models/Soldier.fbx'))[0]
    ctrl=o['ctrl']; nctrl=ctrl.max()+1
    CP=np.zeros((nctrl,3)); CP[ctrl]=o['pos']*0.0254
    tris_ctrl=ctrl[o['tris']]
    o['nrm']=smooth_normals(CP,tris_ctrl,o['tris'],len(ctrl))
    # dedupe corners
    key=np.concatenate([ctrl[:,None].astype(np.float64),np.round(o['nrm'],3),np.round(o['uv'],4)],1)
    _,first,inv=np.unique(key,axis=0,return_index=True,return_inverse=True)
    inv=inv.reshape(-1)
    vctrl=ctrl[first]; pos=CP[vctrl]; nrm=o['nrm'][first]; uv=o['uv'][first].copy(); uv[:,1]=1-uv[:,1]
    idx=inv[o['tris']].reshape(-1).astype(np.uint32)
    ji,jw=rig.weights(CP,tris_ctrl)
    col=region_colors(CP)[vctrl]
    return dict(pos=pos.astype(np.float32),nrm=nrm.astype(np.float32),uv=uv.astype(np.float32),idx=idx,joints=ji[vctrl],wts=jw[vctrl],col=col.astype(np.float32),CP=CP,tris_ctrl=tris_ctrl,vctrl=vctrl)
def smooth_normals(CP,tc,tris,ncorner,crease=55):
    fn=np.cross(CP[tc[:,1]]-CP[tc[:,0]],CP[tc[:,2]]-CP[tc[:,0]])
    area=np.linalg.norm(fn,axis=1,keepdims=True); fu=fn/(area+1e-12)
    from collections import defaultdict
    vf=defaultdict(list)
    for f,t in enumerate(tc):
        for c in t: vf[c].append(f)
    out=np.zeros((ncorner,3)); cc=np.cos(np.radians(crease))
    for f,t in enumerate(tc):
        for k in range(3):
            fs=vf[t[k]]; m=[g for g in fs if fu[g]@fu[f]>cc]
            n=fn[m].sum(0); out[tris[f,k]]=n/(np.linalg.norm(n)+1e-12)
    return out
def srgb2lin(c): c=np.asarray(c,float)/255; return np.where(c<=0.04045,c/12.92,((c+0.055)/1.055)**2.4)
def region_colors(P):
    x=P[:,0]-rig.CX; y=P[:,1]; z=P[:,2]; ax=np.abs(x)
    UNI=(88,92,66); VEST=(118,104,78); HELM=(104,98,76); SKIN=(170,122,96); GLOVE=(38,38,36); BOOT=(58,46,36); PAD=(40,40,38); BELT=(52,50,44); POUCH=(110,96,70); DARK=(30,30,30)
    C=np.tile(np.array(UNI,float),(len(P),1))
    vest=(ax<0.215)&(y>0.97)&(y<1.53); C[vest]=VEST
    pouch=vest&(z>0.13)&(y<1.25); C[pouch]=POUCH
    belt=(ax<0.22)&(y>0.93)&(y<1.0); C[belt]=BELT
    glove=(ax>0.60)&(y>1.1); C[glove]=GLOVE
    boot=(y<0.15); C[boot]=BOOT
    knee=(y>0.44)&(y<0.60)&(z>0.03)&(ax<0.3); C[knee]=PAD
    head=(y>1.53)&(ax<0.17)
    C[head]=HELM
    face=head&(y>1.55)&(y<1.71)&(z>0.0)&(ax<0.085); C[face]=SKIN
    neck=(y>1.50)&(y<1.58)&(ax<0.09)&(z>-0.03)&(z<0.08); C[neck]=SKIN
    ear=head&(ax>0.075)&(y>1.58)&(y<1.70)&(z>-0.06)&(z<0.06); C[ear]=DARK
    rng=np.random.default_rng(3); C=C*(0.92+0.16*rng.random((len(P),1)))
    lin=srgb2lin(np.clip(C,0,255)); return np.concatenate([lin,np.ones((len(P),1))],1)
def fabric_textures(S=512):
    rng=np.random.default_rng(7)
    def tile_noise(scale):
        n=rng.random((S//scale,S//scale)); im=Image.fromarray((n*255).astype(np.uint8)).resize((S,S),Image.BICUBIC)
        return np.asarray(im,float)/255
    yy,xx=np.mgrid[0:S,0:S]
    weave=0.5+0.5*np.sin(xx*np.pi*2/4)*np.sin(yy*np.pi*2/4)
    h=0.55*tile_noise(64)+0.30*tile_noise(16)+0.10*tile_noise(4)+0.05*weave
    h=(h-h.min())/(h.max()-h.min())
    albedo=(0.86+0.14*h); A=np.stack([albedo]*3,-1)
    base=Image.fromarray((A*255).astype(np.uint8))
    gx=np.roll(h,-1,1)-np.roll(h,1,1); gy=np.roll(h,-1,0)-np.roll(h,1,0)
    k=0.9; n=np.stack([-gx*k,-gy*k,np.ones_like(h)],-1); n/=np.linalg.norm(n,axis=-1,keepdims=True)
    nm=Image.fromarray(((n*0.5+0.5)*255).astype(np.uint8))
    b1=io.BytesIO(); base.save(b1,'JPEG',quality=90); b2=io.BytesIO(); nm.save(b2,'PNG',optimize=True)
    return b1.getvalue(),b2.getvalue()

# ======================= variante: Spetsnaz de neve (manequim inimigo) =======================
HEAD_C=np.array([rig.CX,1.668,-0.012]); HEAD_R=np.array([0.088,0.122,0.104])
def balaclava_positions(P):
    """Encolhe capacete/fones sobre um elipsoide do cranio -> balaclava justa."""
    P=P.copy(); x=P[:,0]-rig.CX; ax=np.abs(x); y=P[:,1]; z=P[:,2]
    head=(y>1.535)&(ax<0.19)&(z>-0.2)
    face=(z>0.035)&(y<1.725)&(y>1.54)&(ax<0.075)
    d=(P-HEAD_C)/HEAD_R; r=np.linalg.norm(d,axis=1)
    m=head&~face&(r>1.0)
    # cranio: projeta na superficie do elipsoide (pequena folga para nao afundar no rosto)
    tgt=HEAD_C+(d[m]/r[m,None])*HEAD_R*1.02
    # transicao suave perto do pescoco
    k=np.clip((y[m]-1.535)/0.05,0,1)[:,None]
    P[m]=P[m]*(1-k)+tgt*k
    return P
def spetsnaz_colors(P):
    x=P[:,0]-rig.CX; y=P[:,1]; z=P[:,2]; ax=np.abs(x)
    SNOW=(236,238,240); VEST=(150,168,112); MASK=(22,22,24); SKIN=(176,128,104); GLOVE=(52,52,54); BOOT=(36,34,32); BELT=(70,74,58)
    C=np.tile(np.array(SNOW,float),(len(P),1))
    vest=(ax<0.215)&(y>0.97)&(y<1.53); C[vest]=VEST
    belt=(ax<0.22)&(y>0.93)&(y<1.0); C[belt]=BELT
    C[(ax>0.60)&(y>1.1)]=GLOVE
    C[y<0.15]=BOOT
    head=(y>1.535)&(ax<0.19); C[head]=MASK
    eyes=(y>1.662)&(y<1.692)&(z>0.045)&(ax<0.062); C[eyes]=SKIN
    rng=np.random.default_rng(5); C=C*(0.95+0.08*rng.random((len(P),1)))
    lin=srgb2lin(np.clip(C,0,255)); flags=vest|belt|head|(y<0.15)|((ax>0.60)&(y>1.1))
    return np.concatenate([lin,np.ones((len(P),1))],1),flags
CAMO_U=0.45
def snow_camo_texture(W=1024,H=1024):
    """Atlas: u<0.55 = camuflagem de neve listrada (periodica no angulo); u>0.6 = tecido liso."""
    rng=np.random.default_rng(11)
    img=np.ones((H,W,3))*0.95
    uu,vv=np.meshgrid((np.arange(W)+0.5)/W,(np.arange(H)+0.5)/H)
    ang=uu/CAMO_U*2*np.pi
    # listras verticais irregulares (padrao "berezka"/neve), periodicas no angulo
    pat=np.zeros_like(uu)
    for k in range(70):
        a0=rng.uniform(0,2*np.pi); w=rng.uniform(0.025,0.07); v0=rng.uniform(0,1); L=rng.uniform(0.05,0.18)
        da=np.angle(np.exp(1j*(ang-a0)))
        wav=0.05*np.sin(vv*55+k*1.7)+0.02*np.sin(vv*170+k)
        band=np.exp(-((da+wav)/w)**2*2.5)*np.exp(-((((vv-v0+0.5)%1)-0.5)/L)**2)
        pat=np.maximum(pat,band)
    blot=np.zeros_like(uu)
    for k in range(140):
        a0=rng.uniform(0,2*np.pi); v0=rng.uniform(0,1); s=rng.uniform(0.008,0.03)
        da=np.angle(np.exp(1j*(ang-a0)))/(2*np.pi)*0.9
        blot=np.maximum(blot,np.exp(-(da**2+((vv-v0)*0.6)**2)/(s*s)))
    g=np.clip(pat*0.9+blot*0.6,0,1)
    gray=np.array([0.50,0.55,0.56]); white=np.array([0.97,0.97,0.98])
    camo=white*(1-g[...,None])+gray*g[...,None]
    camo*=0.94+0.06*rng.random((H,W,1))
    plain=uu>=0.6
    img=np.where(plain[...,None],0.93+0.07*rng.random((H,W,1)),camo)
    from PIL import Image as _I
    b=io.BytesIO(); _I.fromarray((np.clip(img,0,1)*255).astype(np.uint8)).save(b,'JPEG',quality=90); return b.getvalue()
def projected_uv(P,flags):
    """UV cilindrico por regiao (tronco/pernas em torno de Y, bracos em torno de X)."""
    x=P[:,0]-rig.CX; y=P[:,1]; z=P[:,2]; ax=np.abs(x)
    arm=(ax>0.215)&(y>1.12)
    ang=np.where(arm,np.arctan2(y-1.33,z),np.arctan2(x,z))
    u=(ang+np.pi)/(2*np.pi)*CAMO_U
    v=np.where(arm,ax/1.9+0.2,1-y/1.9)
    uv=np.stack([u,v],1)
    uv[flags]=[0.8,0.5]
    return uv
def build_spetsnaz():
    o=fbxparse.load(__import__('os').environ.get('SOLDIER_FBX','source_models/Soldier.fbx'))[0]
    ctrl=o['ctrl']; nctrl=ctrl.max()+1
    CP0=np.zeros((nctrl,3)); CP0[ctrl]=o['pos']*0.0254
    CP=balaclava_positions(CP0)
    tris=o['tris']; tris_ctrl=ctrl[tris]
    nrm=smooth_normals(CP,tris_ctrl,tris,len(ctrl))
    col,flags=spetsnaz_colors(CP0)
    uvc=projected_uv(CP0,flags)
    # UV por canto com "desembrulho" da costura do angulo por triangulo
    cuv=uvc[ctrl].copy()
    for t in tris:
        us=cuv[t,0]
        if us.max()-us.min()>CAMO_U*0.5:
            for k in t:
                if cuv[k,0]<CAMO_U*0.5 and not flags[ctrl[k]]: cuv[k,0]+=CAMO_U
    key=np.concatenate([ctrl[:,None].astype(np.float64),np.round(nrm,3),np.round(cuv,4)],1)
    _,first,inv=np.unique(key,axis=0,return_index=True,return_inverse=True); inv=inv.reshape(-1)
    vctrl=ctrl[first]
    ji,jw=rig.weights(CP0,tris_ctrl)
    return dict(pos=CP[vctrl].astype(np.float32),nrm=nrm[first].astype(np.float32),uv=cuv[first].astype(np.float32),
                idx=inv[tris].reshape(-1).astype(np.uint32),joints=ji[vctrl],wts=jw[vctrl],col=col[vctrl].astype(np.float32),CP=CP,tris_ctrl=tris_ctrl,vctrl=vctrl)
