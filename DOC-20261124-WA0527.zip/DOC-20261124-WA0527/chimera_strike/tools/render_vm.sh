#!/bin/bash
# uso: SOLDIER_FBX=... GUN_GLB=... tools/render_vm.sh (a partir da raiz do projeto; servidor http em tools/viewer:8765)
ROOT=$(pwd)
cd tools/rust_anim_test && cargo build --offline -q 2>&1 | grep -E "^error" -A8 | head -20; ./target/debug/animtest | tail -1
cd "$ROOT" && python3 - <<'PY' > /dev/null
import sys,numpy as np; sys.path.insert(0,'tools'); import bake,anim
from anim import Pose
rows=[l.strip().split(',') for l in open('animtest/vm_poses.txt')]
LC={};UC={};combos={};roots={}
for r in rows:
    name=r[0]; v=list(map(float,r[1:])); NB=anim.NB; p=Pose()
    p.rot=np.array(v[:NB*4]).reshape(NB,4); o=NB*4
    p.hips=np.array(v[o:o+3]); p.wpos=np.array(v[o+3:o+6]); p.mpos=np.array(v[o+6:o+9]); p.wrot=np.array(v[o+9:o+13]); p.mrot=np.array(v[o+13:o+17])
    roots[name]=','.join(str(x) for x in v[o+17:o+24])
    LC[name]=(0.1,[p]); UC[name]=(0.1,[p],[0]); combos[name]=(name,name,0,0.0)
bake.compose=lambda lo,up,pitch,off: up
bake.export_glb('work/vm_states.glb',combos,LC,UC,texsize=512,variant='viewmodel')
J=[f'["f=work/vm_states.glb&anim={n}&t=0&cam=0,0,0&tgt=0,0,-1&fov=54&root={roots[n]}&w=640&h=360","work/st_{n}.png"]' for n in roots]
open('work/jobs.json','w').write('['+','.join(J)+']'); open('work/names.txt','w').write(' '.join(roots))
PY
cd tools/viewer && node shot.js "$(cat ../work/jobs.json)" && cd .. && python3 - <<'PY'
from PIL import Image, ImageDraw
names=open('work/names.txt').read().split()
c=Image.new('RGB',(1280,360*4),(20,20,20)); d=ImageDraw.Draw(c)
for i,n in enumerate(names):
    x,y=(i%2)*640,(i//2)*360; c.paste(Image.open(f'work/st_{n}.png'),(x,y)); d.text((x+8,y+8),n,fill=(255,255,0))
c.save('work/vmstates.png')
PY
