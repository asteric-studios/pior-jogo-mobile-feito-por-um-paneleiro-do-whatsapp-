import sys,numpy as np; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__))); import clips,clips2,runtime,anim
from anim import fk
rng=np.random.default_rng(1)
LC={n:clips.lower_clip(n) for n in ['idle','jog_f','walk_l','crouch_b','sprint_f']}
UC={n:clips.upper_clip(n)[:2] for n in ['up_aim','up_low','up_reload','up_sprint']}
for n in ['wound_aim','death_back','wound_fall']:
    d,fr,_=clips2.full_clip(n); LC[n]=(d,fr); UC[n]=(d,fr)
cases=[('idle','up_aim'),('jog_f','up_aim'),('walk_l','up_low'),('crouch_b','up_reload'),('sprint_f','up_sprint'),('wound_aim','wound_aim'),('death_back','death_back'),('wound_fall','wound_fall'),('idle','up_reload'),('jog_f','up_low')]
lines=[];refs=[]
for k,(lo,up) in enumerate(cases*2):
    li=int(rng.integers(len(LC[lo][1]))); ui=int(rng.integers(len(UC[up][1])))
    if lo==up: ui=li
    feet=1.0 if k%2==0 and lo in ('idle','jog_f','walk_l') else 0.0
    v=[rng.uniform(-0.5,0.5),rng.uniform(-0.6,0.6),rng.uniform(-0.8,0.8)*(k%3==0),rng.uniform(-0.05,0),feet,rng.uniform(-0.12,0.08),rng.uniform(-0.12,0.08),
       rng.uniform(0,1),rng.uniform(0,1),rng.uniform(-0.1,0.1),rng.uniform(-0.1,0.1),rng.uniform(-0.08,0.08),rng.uniform(-0.08,0.08),*rng.uniform(-0.3,0.3,3),rng.uniform(0,1)]
    v=[float(np.float32(x)) for x in v]
    P=dict(legs_yaw=v[2],hips_dy=v[3],feet=(v[5],v[6]) if feet else None,bob=(v[7],v[8]),lean=(v[9],v[10]),sway=(v[11],v[12]),flinch=v[13:16],recoil=v[16])
    p=runtime.compose2(LC[lo][1][li],UC[up][1][ui],v[0],v[1],P)
    Gr,Gp,Wp,Wr=fk(p); refs.append(np.concatenate([Gp.ravel(),Wp,p.rot[24]]))
    lines.append(f"{lo}|{li}|{up}|{ui}|"+",".join(repr(x) for x in v))
open('tools/rust_anim_test/cases.txt','w').write("\n".join(lines)+"\n")
np.save('work/refs.npy',np.array(refs))
