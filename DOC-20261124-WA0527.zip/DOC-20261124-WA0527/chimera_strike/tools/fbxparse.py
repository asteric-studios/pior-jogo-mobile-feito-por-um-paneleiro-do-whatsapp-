import re, numpy as np, sys, json
def euler(rx,ry,rz):
    rx,ry,rz=np.radians([rx,ry,rz])
    X=np.array([[1,0,0],[0,np.cos(rx),-np.sin(rx)],[0,np.sin(rx),np.cos(rx)]])
    Y=np.array([[np.cos(ry),0,np.sin(ry)],[0,1,0],[-np.sin(ry),0,np.cos(ry)]])
    Z=np.array([[np.cos(rz),-np.sin(rz),0],[np.sin(rz),np.cos(rz),0],[0,0,1]])
    return Z@Y@X
def m4(R=np.eye(3),t=(0,0,0),s=(1,1,1)):
    M=np.eye(4); M[:3,:3]=R@np.diag(s); M[:3,3]=t; return M
def arr(block,name):
    m=re.search(name+r': \*\d+ \{\s*a: ([^}]*)\}',block)
    return None if m is None else np.array([float(x) for x in m.group(1).replace('\n','').split(',')])
def load(path):
    txt=open(path).read()
    geoms={}; models={}
    for m in re.finditer(r'\n\tGeometry: (\d+), "Geometry::[^"]*", "Mesh" \{(.*?)\n\t\}',txt,re.S):
        gid,b=m.group(1),m.group(2)
        g={'v':arr(b,'Vertices').reshape(-1,3),'pvi':arr(b,'PolygonVertexIndex').astype(np.int64)}
        nb=re.search(r'LayerElementNormal: 0 \{(.*?)\n\t\t\}',b,re.S).group(1)
        g['nmap']=re.search(r'MappingInformationType: "(\w+)"',nb).group(1)
        g['n']=arr(nb,'Normals').reshape(-1,3)
        ub=re.search(r'LayerElementUV: 0 \{(.*?)\n\t\t\}',b,re.S)
        if ub:
            ub=ub.group(1); g['uv']=arr(ub,'UV').reshape(-1,2); g['uvi']=arr(ub,'UVIndex')
            g['uvi']=g['uvi'].astype(np.int64) if g['uvi'] is not None else None
            g['uvmap']=re.search(r'MappingInformationType: "(\w+)"',ub).group(1)
        geoms[gid]=g
    for m in re.finditer(r'\n\tModel: (\d+), "Model::([^"]*)", "(\w+)" \{(.*?)\n\t\}',txt,re.S):
        mid,name,typ,b=m.groups()
        def P(k,d):
            r=re.search(r'P: "'+k+r'", [^\n]*?,([-0-9.e]+),([-0-9.e]+),([-0-9.e]+)\n',b)
            return np.array([float(x) for x in r.groups()]) if r else np.array(d,float)
        L=m4(euler(*P('PreRotation',(0,0,0)))@euler(*P('Lcl Rotation',(0,0,0))),P('Lcl Translation',(0,0,0)),P('Lcl Scaling',(1,1,1)))
        G=m4(euler(*P('GeometricRotation',(0,0,0))),P('GeometricTranslation',(0,0,0)),P('GeometricScaling',(1,1,1)))
        models[mid]={'name':name,'type':typ,'L':L,'G':G,'parent':None,'geom':None}
    conn=txt[txt.index('\nConnections:'):]
    for a,b in re.findall(r'C: "OO",(\d+),(\d+)',conn):
        if a in geoms and b in models: models[b]['geom']=a
        elif a in models and (b in models): models[a]['parent']=b
    def world(mid):
        M=models[mid]['L']; p=models[mid]['parent']
        return world(p)@M if p else M
    out=[]
    for mid,md in models.items():
        if md['geom'] is None: continue
        g=geoms[md['geom']]; W=world(mid)@md['G']
        # triangulate polygons
        pvi=g['pvi']; polys=[]; cur=[]
        for k,ix in enumerate(pvi):
            cur.append(k)
            if ix<0: polys.append(cur); cur=[]
        corners=np.where(pvi<0,-pvi-1,pvi)
        tris=[]
        for p in polys:
            for i in range(1,len(p)-1): tris.append((p[0],p[i],p[i+1]))
        tris=np.array(tris)  # polygon-vertex indices
        pos=(W[:3,:3]@g['v'][corners].T).T+W[:3,3]
        N=g['n'] if g['nmap']=='ByPolygonVertex' else g['n'][corners]
        nrm=(np.linalg.inv(W[:3,:3]).T@N.T).T; nrm/=np.linalg.norm(nrm,axis=1,keepdims=True)+1e-12
        uv=None
        if 'uv' in g:
            if g['uvmap']=='ByPolygonVertex': uv=g['uv'][g['uvi']] if g['uvi'] is not None else g['uv']
            else: uv=g['uv'][corners]
        out.append({'name':md['name'],'pos':pos,'nrm':nrm,'uv':uv,'tris':tris,'ctrl':corners})
    return out
if __name__=='__main__':
    for o in load(sys.argv[1]):
        p=o['pos']*0.0254
        print(o['name'],len(o['tris']),np.round(p.min(0),3),np.round(p.max(0),3))
