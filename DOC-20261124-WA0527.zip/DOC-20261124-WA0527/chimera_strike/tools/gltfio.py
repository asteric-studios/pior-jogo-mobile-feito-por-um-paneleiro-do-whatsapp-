import json,struct,numpy as np
CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def readglb(path):
    d=open(path,'rb').read(); l=struct.unpack('<I',d[12:16])[0]
    j=json.loads(d[20:20+l]); off=20+l; bl=struct.unpack('<I',d[off:off+4])[0]; b=d[off+8:off+8+bl]
    return j,b
def acc(j,b,i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
    n=NC[a['type']]; dt=CT[a['componentType']]
    o=bv.get('byteOffset',0)+a.get('byteOffset',0); st=bv.get('byteStride',0)
    isz=np.dtype(dt).itemsize*n
    if st and st!=isz:
        raw=np.frombuffer(b,np.uint8,count=st*(a['count']-1)+isz,offset=o)
        arr=np.lib.stride_tricks.as_strided(raw,(a['count'],isz),(st,1)).copy().view(dt).reshape(a['count'],n)
    else: arr=np.frombuffer(b,dt,count=a['count']*n,offset=o).reshape(a['count'],n).copy()
    if a.get('normalized'):
        arr=arr.astype(np.float32)/np.iinfo(dt).max
    return arr
def bvbytes(j,b,i):
    bv=j['bufferViews'][i]; o=bv.get('byteOffset',0); return b[o:o+bv['byteLength']]
class Writer:
    def __init__(s): s.j={'asset':{'version':'2.0','generator':'chimera-tools'},'buffers':[],'bufferViews':[],'accessors':[],'nodes':[],'meshes':[],'materials':[],'textures':[],'images':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}],'scenes':[{'nodes':[]}],'scene':0}; s.bin=bytearray()
    def view(s,data,target=None):
        while len(s.bin)%4: s.bin+=b'\0'
        v={'buffer':0,'byteOffset':len(s.bin),'byteLength':len(data)}
        if target: v['target']=target
        s.bin+=data; s.j['bufferViews'].append(v); return len(s.j['bufferViews'])-1
    def accessor(s,arr,ctype,typ,target=None,minmax=False,normalized=False):
        arr=np.ascontiguousarray(arr)
        v=s.view(arr.tobytes(),target)
        a={'bufferView':v,'componentType':ctype,'count':int(arr.shape[0]),'type':typ}
        if normalized: a['normalized']=True
        if minmax: a['min']=[float(x) for x in arr.reshape(arr.shape[0],-1).min(0)]; a['max']=[float(x) for x in arr.reshape(arr.shape[0],-1).max(0)]
        s.j['accessors'].append(a); return len(s.j['accessors'])-1
    def image(s,data,mime):
        v=s.view(data); s.j['images'].append({'bufferView':v,'mimeType':mime}); s.j['textures'].append({'source':len(s.j['images'])-1,'sampler':0}); return len(s.j['textures'])-1
    def save(s,path):
        for k in ['textures','images','materials','meshes']:
            if not s.j[k]: del s.j[k]
        if not s.j.get('skins',1): del s.j['skins']
        while len(s.bin)%4: s.bin+=b'\0'
        s.j['buffers']=[{'byteLength':len(s.bin)}]
        js=json.dumps(s.j,separators=(',',':')).encode()
        while len(js)%4: js+=b' '
        out=struct.pack('<III',0x46546C67,2,12+8+len(js)+8+len(s.bin))+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(s.bin),0x004E4942)+bytes(s.bin)
        open(path,'wb').write(out)
