"""Protótipo do posicionamento do viewmodel (espelhado em src/viewmodel.rs)."""
import sys,numpy as np,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from qm import *; import clips,anim
from anim import fk
def vm_pose(up):
    p=up.copy(); anim.arm_ik(p,clips.GRIPS,p.ikr,p.ikl); anim.apply_twist(p); return p
RY=qy(np.pi)
W_HIP=(np.array([0.115,-0.150,-0.30]),qmul(RY,ypr(-3,1.5,-4)))
W_ADS=(np.array([0.0,-0.0975,-0.17]),RY)
def root_for(p,wc):
    Gr,Gp,Wp,Wr=fk(p)
    rr=qmul(wc[1],qconj(Wr)); return wc[0]-qrot(rr,Wp),rr
