import numpy as np, sys; sys.path.insert(0,__import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from qm import *; import rig, anim
from anim import Pose, fk, ik2, IDX, T0
D=np.pi/180
# ---------------- grips (hand bone frames in Weapon space) ----------------
GRIP_R=anim.hand_frame('Right',(-0.013,-0.100,-0.140),(0.22,-0.32,0.92),(1,0,0.25))
_f=np.radians(58)  # pegada na AFG: palma para dentro, polegar por cima (pulso quase neutro)
GRIP_L=anim.hand_frame('Left',(0.006+0.02*np.sin(_f),-0.036-0.01*np.sin(_f),0.150),(-0.45*np.cos(_f),-0.3*np.sin(_f),0.85),(-np.sin(_f),np.cos(_f),0.0))
GRIPS=(GRIP_R,GRIP_L)
MAG_REST=np.array([0,-0.072,0.032])
BALL=T0[IDX['RightToeBase']].copy(); HEEL=np.array([0,-0.085,-0.06])
# ---------------- lower body ----------------
def leg_place(p,side,ankle_flat,yaw,pitch,toe_bend=0.0):
    """ankle_flat: ankle pos if foot flat. pitch>0 heel up (pivot ball), pitch<0 toes up (pivot heel)."""
    rf=qmul(qy(yaw),qx(pitch)); r0=qy(yaw)
    if pitch>0: piv=ankle_flat+qrot(r0,BALL); ankle=piv-qrot(rf,BALL)
    else: piv=ankle_flat+qrot(r0,HEEL); ankle=piv-qrot(rf,HEEL)
    pole=qrot(qy(yaw),np.array([0.15 if side=='Left' else -0.15,0,1.0]))
    ik2(p,IDX[side+'UpLeg'],IDX[side+'Leg'],IDX[side+'Foot'],ankle,rf,pole,anim.LEG_FLEX,1.0)
    p.rot[IDX[side+'ToeBase']]=qx(-toe_bend)
def stance_pose(hips_h=0.955,yaw=-28,feet=None,lean=2,breath=0.0,roll=0,shift=0.0):
    p=Pose(); p.hips=np.array([rig.CX+0.018*shift,hips_h+breath*0.004-0.006*abs(shift),0.006*shift]); p.rot[0]=ypr(yaw+1.5*shift,lean,roll-2.0*shift)
    if feet is None: feet=((-0.18,-0.10,-48),(0.10,0.11,-14))
    for side,(x,z,fy) in zip(('Right','Left'),feet):
        leg_place(p,side,np.array([x,0.10,z]),fy*D,0.0)
    return p
def gait_pose(t,m,v,T,s,hips_h,bob,lift,lean,yaw,run,width=0.125,bias=-0.04,sway=0.02,hyaw=5,hroll=3,crouch=False):
    m=np.array([m[0],0,m[1]],float); m/=np.linalg.norm(m)
    p=Pose(); L=v*T*s
    ph=(t/T)%1.0
    fwdness=m[2]; latness=abs(m[0])
    # hips
    b=-np.cos(4*np.pi*(ph-s/2)) if not run else np.cos(4*np.pi*(ph-s/2))
    sy=np.sin(2*np.pi*(ph-s/2))
    p.hips=np.array([rig.CX+sway*sy*(1-latness), hips_h+bob*b*0.5-bob*0.5, 0.0])
    p.rot[0]=ypr(yaw+hyaw*np.sin(2*np.pi*ph)*fwdness, lean*np.sign(fwdness+1e-3)*max(abs(fwdness),0.4), hroll*sy)
    wmul=1.3 if fwdness<-0.3 else (1.15 if latness>0.6 else 1.0)
    for side,off in (('Right',0.0),('Left',0.5)):
        q_=(ph+off)%1.0
        lat=(-width if side=='Right' else width)*wmul
        base=np.array([rig.CX+lat,0.10,0.0])
        # crossing guard for strafes
        if q_<s:
            u=q_/s; x=(0.5-u)*L+bias; h=0.0
            if fwdness>0.3: pitch=-12*D*(1-smooth(u/0.18))+ (28*D*smooth((u-0.7)/0.3) if True else 0)
            elif fwdness<-0.3: pitch=18*D*(1-smooth(u/0.25))
            else: pitch=8*D*smooth((u-0.75)/0.25)
        else:
            u=(q_-s)/(1-s); x=(-0.5+smooth(u))*L+bias; h=lift*np.sin(np.pi*u)**1.2
            if fwdness>0.3: pitch=(28*D)*(1-smooth(u/0.5)) - 12*D*smooth((u-0.6)/0.4)
            elif fwdness<-0.3: pitch=18*D*smooth((u-0.5)/0.5)*1.0
            else: pitch=8*D*(1-smooth(u/0.5))
        pos=base+m*x+np.array([0,h,0])
        if latness>0.6:  # keep feet apart in strafes
            pos[0]=base[0]+m[0]*x*0.85 + (0.03 if side=='Left' else -0.03)
        fy=(yaw+(-10 if side=='Right' else 6))*D
        toe=max(0,pitch)*0.9 if q_<s else 0
        leg_place(p,side,pos,fy,pitch,toe)
    return p
LOWER_SPECS={
 'walk': dict(v=1.35,T=1.0,s=0.6,hips_h=0.905,bob=0.022,lift=0.10,lean=3,yaw=-14,run=False),
 'jog':  dict(v=3.0,T=0.66,s=0.38,hips_h=0.875,bob=0.035,lift=0.17,lean=7,yaw=-12,run=True,bias=-0.06),
 'sprint':dict(v=5.0,T=0.58,s=0.32,hips_h=0.865,bob=0.045,lift=0.24,lean=16,yaw=0,run=True,bias=-0.08,hyaw=8,width=0.10),
 'crouch':dict(v=1.3,T=1.0,s=0.6,hips_h=0.68,bob=0.015,lift=0.09,lean=15,yaw=-12,run=False,width=0.11,hroll=2),
}
DIRS={'f':(0,1),'b':(0,-1),'l':(1,0),'r':(-1,0)}
def lower_clip(name):
    fps=30
    if name=='idle':
        dur=6.0; fr=[stance_pose(breath=np.sin(2*np.pi*t/3.0),shift=np.sin(2*np.pi*t/dur)) for t in np.arange(int(dur*fps))/fps]; return dur,fr
    if name=='crouch_idle':
        dur=3.0; fr=[stance_pose(hips_h=0.67,yaw=-24,lean=16,feet=((-0.17,-0.24,-30),(0.10,0.20,-8)),breath=np.sin(2*np.pi*t/dur)) for t in np.arange(int(dur*fps))/fps]; return dur,fr
    if name=='jump':
        dur=1.0; fr=[]
        for t in np.arange(int(dur*fps))/fps:
            p=Pose(); p.hips=np.array([rig.CX,0.97,0]); p.rot[0]=ypr(-10,6,0)
            leg_place(p,'Right',np.array([-0.15,0.42,-0.08]),-16*D,25*D,0)
            leg_place(p,'Left',np.array([0.11,0.30,0.16]),-4*D,-5*D,0)
            fr.append(p)
        return dur,fr
    base,d=name.split('_'); sp=dict(LOWER_SPECS[base]); m=DIRS[d]
    if d in 'lr': sp['lean']=sp['lean']*0.5
    T=sp['T']; n=int(round(T*fps)); fr=[gait_pose(i*T/n,m,**sp) for i in range(n)]
    return T,fr
LOWER_CLIPS=['idle','crouch_idle','jump']+[f'{b}_{d}' for b in ('walk','jog','crouch') for d in 'fblr']+['sprint_f']
# ---------------- upper body ----------------
REF=stance_pose()
def set_weapon_root(p,pos,rot):
    Gr,Gp,_,_=fk(p); s2r=Gr[anim.S2]; s2p=Gp[anim.S2]
    p.wrot=qmul(qconj(s2r),rot); p.wpos=qrot(qconj(s2r),np.asarray(pos)-s2p)
def weapon_from_butt(pocket,rot):
    return np.asarray(pocket)-qrot(rot,np.array([0,-0.045,-0.37])),rot
def base_upper(p,spine=(10,4,0),neck=(8,-6,0),head=(14,8,9),rcl=(0,0,-6),lcl=(-14,0,4),curl=(78,70)):
    for b,a in zip(('Spine','Spine1','Spine2'),(0.3,0.35,0.35)):
        p.rot[IDX[b]]=ypr(spine[0]*a,spine[1]*a,spine[2]*a)
    p.rot[IDX['Neck']]=ypr(*neck); p.rot[IDX['Head']]=ypr(*head)
    p.rot[IDX['RightShoulder']]=ypr(*rcl); p.rot[IDX['LeftShoulder']]=ypr(*lcl)
    p.rot[IDX['RightFingers']]=qz(curl[0]*D); p.rot[IDX['LeftFingers']]=qz(-curl[1]*D)
def with_lower(lp):
    p=REF.copy() if lp is None else lp.copy(); return p
def finalize_arms(p):
    anim.arm_ik(p,GRIPS,1.0,1.0)
AIM_POCKET=np.array([-0.135,1.452,-0.03])
def upper_aim(t,dur=3.0,lp=None):
    p=with_lower(lp); br=np.sin(2*np.pi*t/dur)
    base_upper(p,spine=(12+0.6*np.sin(2*np.pi*t/dur),3+1.1*br,0.5*np.sin(2*np.pi*t/dur)))
    w=qmul(ypr(0.7*np.sin(2*np.pi*t/dur*2),0.8*br,0.4*np.sin(2*np.pi*t/dur)),q())
    pos,rot=weapon_from_butt(AIM_POCKET+np.array([0,0.003*br,0]),w); set_weapon_root(p,pos,rot)
    p.mpos=MAG_REST.copy(); p.ikl=1; p.aimw=1; finalize_arms(p); return p,0.0
def upper_low(t,dur=3.0,lp=None):
    p=with_lower(lp); br=np.sin(2*np.pi*t/dur)
    sw=np.sin(2*np.pi*t/dur)
    base_upper(p,spine=(10+1.5*sw,5+1.2*br,1.0*sw),head=(8+3*sw,4,2))
    w=ypr(10+1.5*sw,32+1.2*br,-6+2*sw)
    pos,rot=weapon_from_butt(AIM_POCKET+np.array([0.01,-0.03,0.0]),w); set_weapon_root(p,pos,rot)
    p.mpos=MAG_REST.copy(); p.ikl=1; p.aimw=1; finalize_arms(p); return p,32.0
SPR_T=LOWER_SPECS['sprint']['T']
def upper_sprint(t,dur=SPR_T,lp=None):
    p=with_lower(lp); ph=2*np.pi*t/dur
    base_upper(p,spine=(18+4*np.sin(ph),2,0),neck=(-6,-8,0),head=(-8,-6,0),rcl=(-4,0,-2),lcl=(-10,0,6))
    w=ypr(62+5*np.sin(ph),22+2*np.sin(2*ph),-28)
    pos=np.array([-0.06,1.27+0.012*np.sin(2*ph),0.20])
    Gr,Gp,_,_=fk(p)
    set_weapon_root(p,pos,w)
    p.mpos=MAG_REST.copy(); p.ikl=1; p.aimw=0; finalize_arms(p); return p,0.0
RELOAD_T=2.3
def upper_reload(t,lp=None):
    p=with_lower(lp)
    base_upper(p,spine=(10,6,0),head=(6,12,4),curl=(78,70))
    # weapon tilt envelope
    k=smooth(t/0.25)*(1-smooth((t-1.95)/0.3))
    w0=ypr(0,0,0); w1=ypr(18,18,-32)
    rot=qslerp(w0,w1,k)
    pocket=AIM_POCKET+np.array([0.02,-0.06,0.02])*k
    pos,rot=weapon_from_butt(pocket,rot); set_weapon_root(p,pos,rot)
    Gr,Gp,Wp,Wr=fk(p)
    def wtf(pp,rr): return Wp+qrot(Wr,pp),qmul(Wr,rr)
    lhand_grip=wtf(*GRIP_L)
    # left hand on magazine (hand frame relative to weapon): palm on mag side/bottom
    magp,magr=anim.hand_frame('Left',MAG_REST+np.array([0.022,-0.07,0.012]),(-0.2,-0.2,0.95),(-1,0.15,0))
    on_mag=wtf(magp,magr)
    pouch=(np.array([0.07,1.13,0.21]),qmul(Gr[anim.S2],anim.hand_frame('Left',(0,0,0),(-0.3,-0.9,0.3),(-0.6,0,-1))[1]))
    bolt=wtf(*anim.hand_frame('Left',(0.04,-0.02,-0.03),(-0.2,0.1,1),(-1,0,0)))
    slapp=(on_mag[0]+qrot(Wr,np.array([0,-0.05,0])),on_mag[1])
    keys=[(0.0,lhand_grip),(0.22,on_mag),(0.42,on_mag),(0.62,(on_mag[0]+qrot(Wr,np.array([0,-0.16,0.02])),on_mag[1])),
          (0.90,pouch),(1.10,pouch),(1.32,(on_mag[0]+qrot(Wr,np.array([0,-0.14,0.0])),on_mag[1])),(1.47,on_mag),(1.53,slapp),(1.60,on_mag),
          (1.78,bolt),(1.86,bolt),(2.12,lhand_grip),(2.3,lhand_grip)]
    for i in range(len(keys)-1):
        if keys[i][0]<=t<=keys[i+1][0]:
            a,b=keys[i],keys[i+1]; u=smooth((t-a[0])/(b[0]-a[0])); break
    else: a=b=keys[-1]; u=0
    tp=a[1][0]*(1-u)+b[1][0]*u; tr=qslerp(a[1][1],b[1][1],u)
    p.ikl=1.0-smooth(t/0.12)+smooth((t-2.05)/0.1)
    p.ikl=float(np.clip(p.ikl,0,1)); p.aimw=1.0
    anim.arm_ik(p,GRIPS,1.0,0.0)
    ik2(p,IDX['LeftArm'],IDX['LeftForeArm'],IDX['LeftHand'],tp,tr,qrot(Gr[anim.S2],anim.POLE_L),anim.ARM_FLEX,1.0)
    # magazine follows hand between 0.42 and 1.47
    if 0.42<t<1.47:
        Gr2,Gp2,Wp2,Wr2=fk(p); h=IDX['LeftHand']
        hp,hr=Gp2[h],Gr2[h]
        # offset hand->mag fixed (computed at grab pose)
        mg_world_p=Wp+qrot(Wr,MAG_REST); mg_world_r=Wr
        off_p=qrot(qconj(on_mag[1]),mg_world_p-on_mag[0]); off_r=qmul(qconj(on_mag[1]),mg_world_r)
        mp=hp+qrot(hr,off_p); mr=qmul(hr,off_r)
        p.mpos=qrot(qconj(Wr2),mp-Wp2); p.mrot=qmul(qconj(Wr2),mr)
    else: p.mpos=MAG_REST.copy(); p.mrot=q()
    return p,14.0
UPPER_CLIPS={'up_aim':(3.0,upper_aim),'up_low':(3.0,upper_low),'up_sprint':(SPR_T,upper_sprint),'up_reload':(RELOAD_T,lambda t,lp=None:upper_reload(t,lp))}
def upper_clip(name):
    dur,f=UPPER_CLIPS[name]; n=int(round(dur*30)); fr=[]; offs=[]
    for i in range(n+ (1 if name=='up_reload' else 0)):
        t=min(i/30.0,dur); p,off=f(t); p.aimoff=off; fr.append(p); offs.append(off)
    return dur,fr,offs
