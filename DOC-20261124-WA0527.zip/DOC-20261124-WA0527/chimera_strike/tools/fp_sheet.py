from PIL import Image, ImageDraw
import os; os.chdir('work/fp')
names=['olhando_baixo','olhando_pes','andando_hip','ads_luneta','olhando_baixo_ads']
def reticle(im):
    d=ImageDraw.Draw(im,'RGBA'); cx,cy=im.width//2,im.height//2; g,tl,pl=9,72,170
    for (x0,y0,x1,y1) in [(cx+g,cy,cx+g+tl,cy),(cx-g-tl,cy,cx-g,cy),(cx,cy+g,cx,cy+g+tl),(cx,cy-g-tl,cx,cy-g)]: d.line([(x0,y0),(x1,y1)],fill=(5,5,5,215),width=1)
    for (x0,y0,x1,y1) in [(cx+g+tl,cy,cx+g+tl+pl,cy),(cx-g-tl-pl,cy,cx-g-tl,cy),(cx,cy+g+tl,cx,cy+g+tl+pl),(cx,cy-g-tl-pl,cx,cy-g-tl)]: d.line([(x0,y0),(x1,y1)],fill=(5,5,5,230),width=3)
    d.ellipse([cx-2.5,cy-2.5,cx+2.5,cy+2.5],fill=(255,20,12,255))
def cross(im):
    d=ImageDraw.Draw(im,'RGBA'); cx,cy=im.width//2,im.height//2; g=20
    for (x0,y0,x1,y1) in [(cx+g,cy,cx+g+10,cy),(cx-g-10,cy,cx-g,cy),(cx,cy+g,cx,cy+g+10),(cx,cy-g-10,cx,cy-g)]: d.line([(x0,y0),(x1,y1)],fill=(255,255,255,230),width=2)
c=Image.new('RGB',(1280,1080),(20,20,20))
for i,n in enumerate(names):
    im=Image.open(n+'.png').convert('RGB'); (reticle if 'ads' in n else cross)(im); ImageDraw.Draw(im).text((8,8),n,fill=(255,255,0))
    c.paste(im,((i%2)*640,(i//2)*360))
c.save('fp_sheet.png')
