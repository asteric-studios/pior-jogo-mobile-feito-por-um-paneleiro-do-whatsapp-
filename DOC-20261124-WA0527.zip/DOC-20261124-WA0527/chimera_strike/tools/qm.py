import numpy as np
def q(x=0,y=0,z=0,w=1): return np.array([x,y,z,w],float)
def qmul(a,b):
    ax,ay,az,aw=a; bx,by,bz,bw=b
    return np.array([aw*bx+ax*bw+ay*bz-az*by, aw*by-ax*bz+ay*bw+az*bx, aw*bz+ax*by-ay*bx+az*bw, aw*bw-ax*bx-ay*by-az*bz])
def qconj(a): return np.array([-a[0],-a[1],-a[2],a[3]])
def qnorm(a): return a/np.linalg.norm(a)
def qrot(a,v):
    u=a[:3]; w=a[3]; t=2*np.cross(u,v); return v+w*t+np.cross(u,t)
def qaxis(ax,ang):
    ax=np.asarray(ax,float); ax=ax/np.linalg.norm(ax); s=np.sin(ang/2); return np.array([*(ax*s),np.cos(ang/2)])
def qx(a): return qaxis((1,0,0),a)
def qy(a): return qaxis((0,1,0),a)
def qz(a): return qaxis((0,0,1),a)
def ypr(y=0,p=0,r=0,deg=True):
    k=np.pi/180 if deg else 1; return qmul(qy(y*k),qmul(qx(p*k),qz(r*k)))
def qfromto(a,b):
    a=a/np.linalg.norm(a); b=b/np.linalg.norm(b); d=np.dot(a,b)
    if d< -0.999999:
        ax=np.cross([1,0,0],a)
        if np.linalg.norm(ax)<1e-6: ax=np.cross([0,1,0],a)
        return qaxis(ax,np.pi)
    c=np.cross(a,b); return qnorm(np.array([*c,1+d]))
def qslerp(a,b,t):
    d=np.dot(a,b)
    if d<0: b=-b; d=-d
    if d>0.9995: return qnorm(a+(b-a)*t)
    th=np.arccos(d); return (np.sin((1-t)*th)*a+np.sin(t*th)*b)/np.sin(th)
def qpow(a,t): return qslerp(q(),a,t)
def qfrombasis(X,Y,Z):
    m=np.array([X,Y,Z]).T; tr=m.trace()
    if tr>0:
        s=np.sqrt(tr+1)*2; return qnorm(np.array([(m[2,1]-m[1,2])/s,(m[0,2]-m[2,0])/s,(m[1,0]-m[0,1])/s,0.25*s]))
    i=np.argmax(np.diag(m))
    if i==0:
        s=np.sqrt(1+m[0,0]-m[1,1]-m[2,2])*2; return qnorm(np.array([0.25*s,(m[0,1]+m[1,0])/s,(m[0,2]+m[2,0])/s,(m[2,1]-m[1,2])/s]))
    if i==1:
        s=np.sqrt(1+m[1,1]-m[0,0]-m[2,2])*2; return qnorm(np.array([(m[0,1]+m[1,0])/s,0.25*s,(m[1,2]+m[2,1])/s,(m[0,2]-m[2,0])/s]))
    s=np.sqrt(1+m[2,2]-m[0,0]-m[1,1])*2; return qnorm(np.array([(m[0,2]+m[2,0])/s,(m[1,2]+m[2,1])/s,0.25*s,(m[1,0]-m[0,1])/s]))
def swing_twist(r,axis):
    p=np.dot(r[:3],axis)*axis; t=np.array([*p,r[3]]); n=np.linalg.norm(t)
    t=q() if n<1e-9 else t/n
    return qmul(r,qconj(t)),t
def smooth(t): t=np.clip(t,0,1); return t*t*(3-2*t)
