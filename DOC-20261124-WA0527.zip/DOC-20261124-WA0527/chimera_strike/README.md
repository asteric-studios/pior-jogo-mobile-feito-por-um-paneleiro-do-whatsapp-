# Chimera Strike — protótipo de tiro 3D mobile (Rust + Bevy + Rapier)

Jogo de tiro em terceira pessoa (câmera sobre o ombro, estilo CoD) para Android, com um manequim
inimigo (Spetsnaz de neve) com IA. Renderização e ECS com **Bevy 0.14.2**; física com **Rapier 3D**
(`bevy_rapier3d 0.27`).

![animações](docs/preview_animacoes.png)
![manequim](docs/preview_manequim.png)

## Como gerar o APK (GitHub Actions)

1. Crie um repositório no GitHub (pode ser privado) e envie esta pasta inteira:
   ```bash
   git init && git add . && git commit -m "Chimera Strike"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/chimera-strike.git
   git push -u origin main
   ```
   Pelo celular: crie o repositório e use "Add file → Upload files" (mantenha a pasta `.github/workflows`).
2. Abra a aba **Actions**. O workflow **Build APK (Android)** roda sozinho (ou clique em **Run workflow**).
3. Quando ficar verde (de 20 a 40 min na primeira vez), baixe o artefato **ChimeraStrike-apk**.
4. Instale no celular: precisa de **ARM64 com Android 9 ou superior**.

Se a build falhar, me mande o log do passo que falhou.

## Controles

| Ação | Celular | PC |
|---|---|---|
| Andar | joystick flutuante (lado esquerdo) | WASD |
| Correr | empurre o joystick além do círculo | Shift |
| Câmera | arraste no lado direito | mouse (clique para capturar) |
| Atirar | **FOGO** (direita ou esquerda) | botão esquerdo |
| Mira (ADS) | **MIRA** | botão direito |
| Recarregar | **R** | R |
| Pular / Agachar | **PULO** / **AGACH** | Espaço / C |
| Imortal (testes) | **IMORTAL** (topo, fica verde quando ligado) | G |
| 1ª / 3ª pessoa | **1P/3P** (topo, fica azul em 1ª pessoa) | V |

No PC: `cargo run --release --example desktop`.

## Manequim (IA inspirada no MW2)

Mesmo personagem do soldado, mas sem capacete, com balaclava preta, camuflagem de neve listrada e
colete verde-claro.

- **Percepção:** campo de visão de cerca de 130° com linha de visada real, e ouve os seus tiros a até 70 m. Fica suprimido quando uma bala passa perto da cabeça.
- **Combate:**
  - Escolhe uma cobertura que realmente o protege de você e vai até ela pelo A* (corre quando não está sendo visto).
  - Fica agachado atrás de cobertura baixa e espia por cima, ou pelo lado na cobertura alta. Atira em rajadas e recarrega protegido.
  - Depois de algumas espiadas, troca de cobertura avançando.
  - Quando fica sem cobertura, ou quando você o flanqueia, anda de lado atirando e mantém distância.
  - Se perde você de vista, investiga a última posição conhecida; senão, patrulha.
- **Pontaria:** os primeiros tiros erram mais, como no MW2. A precisão piora com distância, supressão e com você em movimento, e você agachado fica mais difícil de acertar.
- **Dano por região (hitboxes por osso):**
  - Cabeça mata na hora.
  - Tronco, braço e perna têm danos diferentes.
  - Cada tiro provoca uma reação física no corpo.
- **Tiro na perna:** ele cai, se arrasta de costas para longe de você e atira do chão.
- **Morte:** clipe conforme a direção do tiro (para trás ou de bruços). A arma cai como objeto físico e ele renasce longe de você depois de 4 s.

Você tem vida com regeneração no estilo CoD: a tela fica vermelha ao levar dano e, se morrer, renasce em 4 s. O botão **IMORTAL** desliga o dano.

## Primeira pessoa (estilo CoD)

- **Viewmodel próprio** (`assets/viewmodel.glb`, só braços e arma): é desenhado por uma segunda câmera
  com FOV fixo de 54° na camada de render 1. Por isso a arma nunca atravessa paredes e não muda de
  tamanho quando o FOV do mundo abre no sprint ou fecha no ADS.
- **Animação procedural** (`ViewmodelAnim` em `src/animator.rs`):
  - balanço do passo em "8";
  - atraso da arma ao girar a câmera (sway com mola) e inclinação ao andar de lado;
  - respiração;
  - coice com mola a cada tiro e mergulho ao aterrissar;
  - postura abaixada ao agachar;
  - sprint estilo MW2 (arma baixa, girada e inclinada);
  - recarga usando o mesmo clipe do corpo.
  - As transições usam smoothstep e não dão tranco.
- **Mira sem ser sólida:** no ADS o corpo da luneta fica 82% transparente e a lente sai do modelo.
  O HUD desenha um retículo duplex fino (ponto vermelho, fios finos e postes laterais) sem tapar a
  visão. O centro da luneta fica alinhado ao centro da tela (erro de 2 mm e 0,17°).
- **Corpo visível:**
  - a câmera fica nos olhos do próprio soldado (FK do osso da cabeça);
  - cabeça e braços do modelo de 3ª pessoa são recolhidos;
  - ao olhar para baixo você vê o colete, as pernas e os pés andando;
  - em 1ª pessoa o tronco quase não curva, e o pescoço avança a câmera ao olhar para baixo.
- **Tiros:** em 1ª pessoa o raio sai do olho, então a arma não atira "de dentro" de uma parede colada
  na câmera. O traçante, o flash e as cápsulas saem do cano e da janela do viewmodel.
- **Desempenho:** a luz do viewmodel não gera sombras, então a câmera da arma não cria mapas de sombra
  extras. O FXAA fica só na última câmera.

## Animação (o que mudou)

- **Braço fino corrigido:** o antebraço esquerdo torcia 135° e o skinning "esmagava" a malha. Agora:
  - o IK é anatômico (cotovelo e joelho dobram só no eixo da dobradiça);
  - dois ossos de torção por antebraço distribuem a rotação do pulso;
  - a pegada da mão esquerda na empunhadura AFG é natural (palma para dentro, polegar por cima).
- **Camadas procedurais em tempo real:**
  - as pernas ficam plantadas ao girar parado e dão passos quando o giro passa de 55°;
  - a arma atrasa ao girar a câmera;
  - o tronco inclina ao acelerar, há uma queda de quadril ao aterrissar e o tronco balança com o passo;
  - os pés se ajustam ao terreno (IK em degraus e rampas);
  - reação a tiro com mola, e recuo.
- **Idle mais vivo:** transferência de peso, respiração e oscilação da arma.
- **Transições:** suaves, com molas criticamente amortecidas.

## Verificações feitas

- O runtime de animação em Rust (`src/anim_core.rs`, `src/animator.rs`) foi compilado e comparado com o modelo de referência em Python: diferença máxima de 0,028 mm em todos os ossos (`tools/rust_anim_test`).
- Uma simulação de 15 s (correr, girar, sprint, agachar, pular, recarregar, levar tiro, cair, arrastar, morrer) rodou sem NaN, e a mão ficou na arma com erro de 0,02 mm.
- A navegação foi testada: A* em menos de 1 ms, 154 pontos de cobertura e teste de raio contra cápsula.
- Teste de estresse do viewmodel com 60 s de entradas aleatórias e quadros de 16 a 50 ms: sem NaN,
  sem saltos (o máximo de 42 mm por quadro acontece só na entrada do ADS, que leva 0,18 s) e mãos
  presas à arma com erro de 0,00 mm.
- O jogo inteiro passa na checagem de tipos e de empréstimos contra dublês do Bevy 0.14 e do Rapier 0.27 (`tools/stubcheck`). O APK em si só é compilado de verdade no GitHub Actions.

## Estrutura

```
assets/soldier.glb, spetsnaz.glb   personagens + rig (28 ossos) + Howa Type 20
assets/viewmodel.glb               braços + arma da 1ª pessoa (mesmo rig)
assets/anims.bin                   clipes (locomoção, mira, recarga, queda, arrasto, mortes)
src/anim_core.rs                   IK, torção, camadas procedurais e composição (sem ECS)
src/animator.rs                    máquina de camadas compartilhada por jogador e inimigo (sem ECS)
src/nav.rs, src/map.rs             grade + A*, coberturas, hitboxes e layout do mapa (sem ECS)
src/enemy.rs                       IA do manequim
src/viewmodel.rs                   1ª pessoa: câmera da arma, camadas, luneta fantasma
src/player.rs, weapon.rs, ...      jogador, arma, mundo, controles e HUD
tools/                             pipeline Python que gera os assets e os testes
```

Para regenerar os assets, coloque `Soldier.fbx` e `howa_type_20.glb` em `source_models/` e rode
`python3 tools/bake.py final assets` (requer numpy, scipy e pillow).

## Observações

- No Android o MSAA fica desligado (bug conhecido do Bevy em alguns aparelhos) e o FXAA é usado no lugar.
- Ainda não tem som.
- O APK é só ARM64.
