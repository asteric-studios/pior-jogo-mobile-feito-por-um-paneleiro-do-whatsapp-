//! Chimera Strike — protótipo de tiro em terceira pessoa (estilo CoD) para Android.
//! Bevy 0.14 (render/ECS) + Rapier 3D (física).

use bevy::asset::AssetMetaCheck;
use bevy::prelude::*;
use bevy::window::WindowMode;
use bevy_rapier3d::prelude::*;

pub mod anim;
pub mod anim_core;
pub mod animator;
mod controls;
mod enemy;
mod hud;
pub mod map;
pub mod nav;
mod player;
mod viewmodel;
mod weapon;
mod world;

pub fn run_app() {
    let android = cfg!(target_os = "android");
    let mut app = App::new();
    app.insert_resource(ClearColor(Color::srgb(0.6, 0.67, 0.74)))
        .insert_resource(AmbientLight { color: Color::srgb(0.85, 0.9, 1.0), brightness: 420.0 })
        // MSAA trava alguns aparelhos Android (bevy#8229); lá usamos FXAA na câmera
        .insert_resource(if android { Msaa::Off } else { Msaa::Sample4 })
        .add_plugins(
            DefaultPlugins
                .set(WindowPlugin {
                    primary_window: Some(Window {
                        title: "Chimera Strike".into(),
                        resizable: !android,
                        mode: if android { WindowMode::BorderlessFullscreen } else { WindowMode::Windowed },
                        ..default()
                    }),
                    ..default()
                })
                .set(AssetPlugin { meta_check: AssetMetaCheck::Never, ..default() }),
        )
        .add_plugins(RapierPhysicsPlugin::<NoUserData>::default())
        .add_plugins((
            world::WorldPlugin,
            anim::AnimPlugin,
            controls::ControlsPlugin,
            player::PlayerPlugin,
            weapon::WeaponPlugin,
            enemy::EnemyPlugin,
            hud::HudPlugin,
            viewmodel::ViewmodelPlugin,
        ));
    app.run();
}

// `bevy_main` gera o ponto de entrada `android_main` usado pelo APK.
#[bevy_main]
fn main() {
    run_app();
}
