//! Integração ECS do runtime de animação: acha os ossos por nome e aplica a pose.
use crate::anim_core::*;
use bevy::hierarchy::HierarchyQueryExt;
use bevy::prelude::*;
use std::collections::HashMap;

#[derive(Resource, Deref)]
pub struct Anim(pub AnimData);

/// Entidades dos ossos do soldado (encontradas por nome depois da cena carregar).
#[derive(Component)]
pub struct Rig {
    pub bones: [Entity; NB],
    pub weapon: Entity,
    pub magazine: Entity,
    pub muzzle: Entity,
    /// a arma foi solta (morte) e virou objeto físico: não é mais animada
    pub weapon_free: bool,
}

/// Raiz do modelo (filho do jogador/inimigo).
#[derive(Component)]
pub struct SoldierModel;

/// Pose calculada pela lógica do personagem e aplicada aos ossos.
#[derive(Component, Default)]
pub struct CurrentPose(pub Option<Pose>);

/// Esconde cabeça, braços e arma do modelo de 3ª pessoa (corpo visível em 1ª pessoa).
#[derive(Component)]
pub struct FpHide;

/// Timer do flash do cano (por modelo).
#[derive(Component, Default)]
pub struct FlashTimer(pub f32);

#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub struct ApplyPoseSet;

pub struct AnimPlugin;
impl Plugin for AnimPlugin {
    fn build(&self, app: &mut App) {
        let data = AnimData::parse(include_bytes!("../assets/anims.bin"));
        app.insert_resource(Anim(data))
            .add_systems(Update, resolve_rig)
            .add_systems(PostUpdate, apply_pose.in_set(ApplyPoseSet).before(bevy::transform::TransformSystem::TransformPropagate));
    }
}

fn resolve_rig(
    mut commands: Commands,
    models: Query<Entity, (With<SoldierModel>, Without<Rig>)>,
    children: Query<&Children>,
    names: Query<&Name>,
) {
    for root in models.iter() {
        let mut found: HashMap<&str, Entity> = HashMap::new();
        for e in children.iter_descendants(root) {
            if let Ok(n) = names.get(e) {
                let s = n.as_str();
                if let Some(k) = BONE_NAMES.iter().find(|b| **b == s) {
                    found.insert(*k, e);
                } else {
                    let key: Option<&'static str> = match s {
                        "Weapon" => Some("Weapon"),
                        "Magazine" => Some("Magazine"),
                        "Muzzle" => Some("Muzzle"),
                        _ => None,
                    };
                    if let Some(k) = key {
                        found.insert(k, e);
                    }
                }
            }
        }
        if found.len() < NB + 3 {
            continue; // cena ainda carregando
        }
        let mut bones = [Entity::PLACEHOLDER; NB];
        for (i, n) in BONE_NAMES.iter().enumerate() {
            bones[i] = found[n];
        }
        commands.entity(root).insert((
            Rig {
                bones,
                weapon: found["Weapon"],
                magazine: found["Magazine"],
                muzzle: found["Muzzle"],
                weapon_free: false,
            },
            FlashTimer(0.0),
        ));
    }
}

fn apply_pose(rigs: Query<(&Rig, &CurrentPose, Option<&FpHide>)>, mut tf: Query<&mut Transform>, mut vis: Query<&mut Visibility>) {
    for (rig, pose, hide) in rigs.iter() {
        let Some(p) = pose.0 else { continue };
        let hidden = hide.is_some();
        for i in 0..NB {
            if let Ok(mut t) = tf.get_mut(rig.bones[i]) {
                t.rotation = p.rot[i];
                if i == HIPS {
                    t.translation = p.hips;
                }
                // em 1ª pessoa a cabeça e os braços do corpo são "recolhidos" (escala ~0)
                let collapse = hidden && (i == NECK || i == R_ARM || i == L_ARM);
                t.scale = if collapse { Vec3::splat(1e-4) } else { Vec3::ONE };
            }
        }
        if !rig.weapon_free {
            if let Ok(mut v) = vis.get_mut(rig.weapon) {
                let want = if hidden { Visibility::Hidden } else { Visibility::Inherited };
                if *v != want {
                    *v = want;
                }
            }
        }
        if !rig.weapon_free {
            if let Ok(mut t) = tf.get_mut(rig.weapon) {
                t.translation = p.wpos;
                t.rotation = p.wrot;
            }
            if let Ok(mut t) = tf.get_mut(rig.magazine) {
                t.translation = p.mpos;
                t.rotation = p.mrot;
            }
        }
    }
}
