//! Máquina de camadas de animação (compartilhada por jogador e inimigos). Sem ECS.
//! Inspirada no MW2 (2009): locomoção direcional sem patinar, giro das pernas parado
//! ("turn in place"), atraso da arma ao girar, inclinação ao acelerar, queda ao aterrissar,
//! reação a tiro com mola, IK dos pés no terreno e clipes de corpo inteiro (queda/ferido/morte).
#![allow(dead_code)]
use crate::anim_core::*;
use bevy::math::{Quat, Vec2, Vec3};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum UpperMode {
    Aim,
    Low,
    Sprint,
}

#[derive(Clone, Copy)]
pub struct AnimInput {
    pub dt: f32,
    /// velocidade no espaço do modelo: x = esquerda do personagem, y = frente
    pub vel_local: Vec2,
    pub grounded: bool,
    pub crouch: bool,
    pub sprint: bool,
    pub ads: bool,
    pub upper: UpperMode,
    pub reload_t: Option<f32>,
    pub aim_yaw: f32,
    pub aim_pitch: f32,
    /// quanto a raiz girou neste quadro (rad, + = esquerda)
    pub root_yaw_delta: f32,
    pub pitch_delta: f32,
    pub recoil: f32,
    pub feet: Option<(f32, f32)>,
    /// clipe de corpo inteiro ativo (nome, tempo)
    pub full: Option<(&'static str, f32)>,
}
impl Default for AnimInput {
    fn default() -> Self {
        AnimInput {
            dt: 1.0 / 60.0,
            vel_local: Vec2::ZERO,
            grounded: true,
            crouch: false,
            sprint: false,
            ads: false,
            upper: UpperMode::Low,
            reload_t: None,
            aim_yaw: 0.0,
            aim_pitch: 0.0,
            root_yaw_delta: 0.0,
            pitch_delta: 0.0,
            recoil: 0.0,
            feet: None,
            full: None,
        }
    }
}

// camadas inferiores
const L_IDLE: usize = 0;
const L_WALK: usize = 1;
const L_JOG: usize = 2;
const L_SPRINT: usize = 3;
const L_CIDLE: usize = 4;
const L_CROUCH: usize = 5;
const L_JUMP: usize = 6;
// camadas superiores
pub const U_AIM: usize = 0;
pub const U_LOW: usize = 1;
pub const U_SPRINT: usize = 2;
pub const U_RELOAD: usize = 3;

/// mola criticamente amortecida (escalar)
fn spring(x: &mut f32, v: &mut f32, target: f32, k: f32, zeta: f32, dt: f32) {
    let c = 2.0 * zeta * k.sqrt();
    let a = k * (target - *x) - c * *v;
    *v += a * dt;
    *x += *v * dt;
}
fn spring3(x: &mut Vec3, v: &mut Vec3, k: f32, zeta: f32, dt: f32) {
    let c = 2.0 * zeta * k.sqrt();
    let a = -*x * k - *v * c;
    *v += a * dt;
    *x += *v * dt;
}
fn fade(w: &mut f32, target: f32, rate: f32, dt: f32) {
    *w += (target - *w) * (1.0 - (-rate * dt).exp());
}

pub struct Animator {
    lw: [f32; 7],
    phase: [f32; 4],
    pub uw: [f32; 4],
    t: f32,
    pub legs_yaw: f32,
    turn_t: f32,
    turn_dir: f32,
    sway: Vec2,
    sway_v: Vec2,
    lean: Vec2,
    lean_v: Vec2,
    prev_vel: Vec2,
    acc: Vec2,
    dip: f32,
    dip_v: f32,
    flinch: Vec3,
    flinch_v: Vec3,
    pub full_w: f32,
    last_full: Option<(&'static str, f32)>,
    feet_s: (f32, f32),
    pub last: Pose,
}

impl Default for Animator {
    fn default() -> Self {
        Animator {
            lw: [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            phase: [0.0; 4],
            uw: [0.0, 1.0, 0.0, 0.0],
            t: 0.0,
            legs_yaw: 0.0,
            turn_t: 0.0,
            turn_dir: 0.0,
            sway: Vec2::ZERO,
            sway_v: Vec2::ZERO,
            lean: Vec2::ZERO,
            lean_v: Vec2::ZERO,
            prev_vel: Vec2::ZERO,
            acc: Vec2::ZERO,
            dip: 0.0,
            dip_v: 0.0,
            flinch: Vec3::ZERO,
            flinch_v: Vec3::ZERO,
            full_w: 0.0,
            last_full: None,
            feet_s: (0.0, 0.0),
            last: Pose::default(),
        }
    }
}

impl Animator {
    /// Reação a impacto. `dir` = direção do projétil no espaço do modelo; `part`: 0 cabeça, 1 tronco, 2 braço, 3 perna.
    pub fn hit(&mut self, dir: Vec3, part: u8, strength: f32) {
        let d = Vec3::new(dir.x, dir.y * 0.3, dir.z).normalize_or_zero();
        let axis = Vec3::Y.cross(d);
        let (k, side) = match part {
            0 => (9.0, 0.0),
            1 => (5.5, 1.0),
            2 => (3.0, 1.0),
            _ => (2.0, 0.0),
        };
        // giro lateral aleatório-ish dependendo do lado do impacto
        self.flinch_v += axis * k * strength + Vec3::Y * (d.x * 2.5 * side * strength);
        if part == 3 {
            self.dip_v -= 0.9 * strength;
        }
    }
    /// Aterrissagem (velocidade vertical de impacto, positiva).
    pub fn land(&mut self, speed: f32) {
        self.dip_v -= (speed * 0.12).min(0.9);
    }

    pub fn update(&mut self, d: &AnimData, i: &AnimInput) -> Pose {
        let dt = i.dt.clamp(1e-4, 0.05);
        self.t += dt;
        let speed = i.vel_local.length();
        let moving = speed > 0.25;

        // ---------------- giro das pernas parado (turn in place)
        if moving || !i.grounded || i.full.is_some() || i.sprint {
            self.legs_yaw *= (-dt * 10.0).exp();
            self.turn_t = 0.0;
        } else {
            self.legs_yaw -= i.root_yaw_delta;
            if self.turn_t <= 0.0 && self.legs_yaw.abs() > 55f32.to_radians() {
                self.turn_t = 0.42;
                self.turn_dir = self.legs_yaw.signum();
            }
            if self.turn_t > 0.0 {
                self.turn_t -= dt;
                self.legs_yaw *= (-dt * 9.0).exp();
            }
        }
        self.legs_yaw = self.legs_yaw.clamp(-1.4, 1.4);
        let turning = self.turn_t > 0.0;

        // ---------------- camadas inferiores
        let mut lt = [0.0f32; 7];
        if !i.grounded {
            lt[L_JUMP] = 1.0;
        } else if i.crouch {
            lt[if moving || turning { L_CROUCH } else { L_CIDLE }] = 1.0;
        } else if i.sprint && moving {
            lt[L_SPRINT] = 1.0;
        } else if turning {
            lt[L_WALK] = 0.75;
            lt[L_IDLE] = 0.25;
        } else if !moving {
            lt[L_IDLE] = 1.0;
        } else if i.ads || speed < 2.4 {
            lt[L_WALK] = 1.0;
        } else {
            lt[L_JOG] = 1.0;
        }
        for k in 0..7 {
            fade(&mut self.lw[k], lt[k], 10.0, dt);
        }
        // direção (com passos laterais no giro parado)
        let (dir, gait_speed) = if moving {
            (i.vel_local / speed, speed)
        } else if turning {
            (Vec2::new(-self.turn_dir, 0.0), 1.3)
        } else {
            (Vec2::new(0.0, 1.0), 0.0)
        };
        let gaits = ["walk", "jog", "sprint", "crouch"];
        for (gi, g) in gaits.iter().enumerate() {
            let c = d.clip(&format!("{g}_f"));
            let rate = (gait_speed / c.speed.max(0.1)) / c.dur;
            self.phase[gi] = (self.phase[gi] + dt * rate).fract();
        }
        let wsum = (dir.x.abs() + dir.y.abs()).max(1e-4);
        let dw = [
            ("f", dir.y.max(0.0) / wsum),
            ("b", (-dir.y).max(0.0) / wsum),
            ("l", dir.x.max(0.0) / wsum),
            ("r", (-dir.x).max(0.0) / wsum),
        ];
        let gait_pose = |g: &str, ph: f32| -> Pose {
            let dur = d.clip(&format!("{g}_f")).dur;
            let parts: Vec<(Pose, f32)> = dw
                .iter()
                .filter(|(_, w)| *w > 0.01)
                .map(|(s, w)| (d.sample(&format!("{g}_{s}"), ph * dur), *w))
                .collect();
            blend(&parts)
        };
        let (lw, ph) = (self.lw, self.phase);
        let mut lower = Vec::new();
        if lw[L_IDLE] > 1e-3 {
            lower.push((d.sample("idle", self.t), lw[L_IDLE]));
        }
        if lw[L_WALK] > 1e-3 {
            lower.push((gait_pose("walk", ph[0]), lw[L_WALK]));
        }
        if lw[L_JOG] > 1e-3 {
            lower.push((gait_pose("jog", ph[1]), lw[L_JOG]));
        }
        if lw[L_SPRINT] > 1e-3 {
            let c = d.clip("sprint_f");
            lower.push((d.sample("sprint_f", ph[2] * c.dur), lw[L_SPRINT]));
        }
        if lw[L_CIDLE] > 1e-3 {
            lower.push((d.sample("crouch_idle", self.t), lw[L_CIDLE]));
        }
        if lw[L_CROUCH] > 1e-3 {
            lower.push((gait_pose("crouch", ph[3]), lw[L_CROUCH]));
        }
        if lw[L_JUMP] > 1e-3 {
            lower.push((d.sample("jump", 0.0), lw[L_JUMP]));
        }
        let lower = blend(&lower);

        // ---------------- camadas superiores
        let mut ut = [0.0f32; 4];
        if i.reload_t.is_some() {
            ut[U_RELOAD] = 1.0;
        } else {
            match i.upper {
                UpperMode::Sprint if moving => ut[U_SPRINT] = 1.0,
                UpperMode::Aim => ut[U_AIM] = 1.0,
                _ => ut[U_LOW] = 1.0,
            }
        }
        for k in 0..4 {
            fade(&mut self.uw[k], ut[k], 12.0, dt);
        }
        let uw = self.uw;
        let mut upper = Vec::new();
        if uw[U_AIM] > 1e-3 {
            upper.push((d.sample("up_aim", self.t), uw[U_AIM]));
        }
        if uw[U_LOW] > 1e-3 {
            upper.push((d.sample("up_low", self.t), uw[U_LOW]));
        }
        if uw[U_SPRINT] > 1e-3 {
            let c = d.clip("up_sprint");
            upper.push((d.sample("up_sprint", ph[2] * c.dur), uw[U_SPRINT]));
        }
        if uw[U_RELOAD] > 1e-3 {
            upper.push((d.sample("up_reload", i.reload_t.unwrap_or(2.3)), uw[U_RELOAD]));
        }
        let upper = blend(&upper);

        // ---------------- molas procedurais
        let yaw_rate = i.root_yaw_delta / dt;
        let pitch_rate = i.pitch_delta / dt;
        let st = Vec2::new((-yaw_rate * 0.035).clamp(-0.07, 0.07), (-pitch_rate * 0.025).clamp(-0.05, 0.05));
        spring(&mut self.sway.x, &mut self.sway_v.x, st.x, 90.0, 0.8, dt);
        spring(&mut self.sway.y, &mut self.sway_v.y, st.y, 90.0, 0.8, dt);
        let acc_raw = (i.vel_local - self.prev_vel) / dt;
        self.prev_vel = i.vel_local;
        self.acc = self.acc.lerp(acc_raw, 1.0 - (-dt * 8.0).exp());
        let lt2 = Vec2::new((-self.acc.x * 0.012).clamp(-0.09, 0.09), (self.acc.y * 0.010).clamp(-0.07, 0.07));
        spring(&mut self.lean.x, &mut self.lean_v.x, lt2.x, 60.0, 0.9, dt);
        spring(&mut self.lean.y, &mut self.lean_v.y, lt2.y, 60.0, 0.9, dt);
        spring(&mut self.dip, &mut self.dip_v, 0.0, 120.0, 0.6, dt);
        self.dip = self.dip.clamp(-0.25, 0.08);
        spring3(&mut self.flinch, &mut self.flinch_v, 160.0, 0.5, dt);
        let fl = self.flinch.length();
        if fl > 0.6 {
            self.flinch *= 0.6 / fl;
        }
        if let Some((dl, dr)) = i.feet {
            let k = 1.0 - (-dt * 14.0).exp();
            self.feet_s.0 += (dl - self.feet_s.0) * k;
            self.feet_s.1 += (dr - self.feet_s.1) * k;
        } else {
            self.feet_s = (0.0, 0.0);
        }
        // balanço do passo: fase da passada mais ativa
        let gw = [lw[L_WALK], lw[L_JOG], lw[L_SPRINT], lw[L_CROUCH]];
        let mut best = 0;
        for k in 1..4 {
            if gw[k] > gw[best] {
                best = k;
            }
        }
        let bob_amt = if i.grounded && moving {
            (speed / 3.2).min(1.0) * if i.ads { 0.35 } else { 1.0 } * if i.sprint { 0.5 } else { 1.0 }
        } else {
            0.0
        };

        // ---------------- corpo inteiro (queda / ferido / morte)
        if let Some(f) = i.full {
            self.last_full = Some(f);
        }
        fade(&mut self.full_w, if i.full.is_some() { 1.0 } else { 0.0 }, if i.full.is_some() { 12.0 } else { 6.0 }, dt);
        let pr = Procedural {
            legs_yaw: self.legs_yaw,
            hips_dy: self.dip,
            feet: if i.grounded && i.feet.is_some() && self.full_w < 0.5 { Some(self.feet_s) } else { None },
            bob_phase: self.phase[best],
            bob_amt: bob_amt * (1.0 - self.full_w),
            lean_roll: self.lean.x,
            lean_pitch: self.lean.y,
            sway_yaw: self.sway.x,
            sway_pitch: self.sway.y,
            flinch: self.flinch,
            recoil: i.recoil,
        };
        let pose = if self.full_w > 0.999 {
            self.full_pose(d, i)
        } else {
            let normal = d.compose(&lower, &upper, i.aim_yaw, i.aim_pitch, &pr);
            if self.full_w > 0.001 {
                lerp_pose(&normal, &self.full_pose(d, i), self.full_w)
            } else {
                normal
            }
        };
        self.last = pose;
        pose
    }

    fn full_pose(&self, d: &AnimData, i: &AnimInput) -> Pose {
        let Some((name, t)) = self.last_full else { return self.last };
        let f = d.sample(name, t);
        let pr = Procedural { flinch: self.flinch, recoil: i.recoil, ..Default::default() };
        d.compose(&f, &f, i.aim_yaw, i.aim_pitch, &pr)
    }
}

// ============================================================================ viewmodel (1ª pessoa)
/// Transformação rígida (posição, rotação).
#[derive(Clone, Copy, Debug)]
pub struct Rt {
    pub p: Vec3,
    pub r: Quat,
}
impl Rt {
    pub fn mul(self, o: Rt) -> Rt {
        Rt { p: self.p + self.r * o.p, r: self.r * o.r }
    }
    pub fn inv(self) -> Rt {
        let ri = self.r.inverse();
        Rt { p: -(ri * self.p), r: ri }
    }
    pub fn lerp(self, o: Rt, t: f32) -> Rt {
        Rt { p: self.p.lerp(o.p, t), r: self.r.slerp(o.r, t) }
    }
}

/// Arma no espaço da câmera (câmera olha para −Z). Quadril e mira (ADS: eixo da luneta no centro).
pub fn vm_hip() -> Rt {
    Rt { p: Vec3::new(0.11, -0.125, -0.39), r: Quat::from_rotation_y(std::f32::consts::PI) * ypr(6f32.to_radians(), 3f32.to_radians(), -10f32.to_radians()) }
}
pub const SPRINT_YAW: f32 = 0.5;
pub fn vm_ads() -> Rt {
    Rt { p: Vec3::new(0.0, -0.0975, -0.17), r: Quat::from_rotation_y(std::f32::consts::PI) }
}

#[derive(Clone, Copy, Default)]
pub struct VmInput {
    pub dt: f32,
    pub ads: bool,
    pub sprint: bool,
    pub crouch: bool,
    pub grounded: bool,
    /// x = esquerda, y = frente (m/s)
    pub vel_local: Vec2,
    pub reload_t: Option<f32>,
    pub yaw_delta: f32,
    pub pitch_delta: f32,
    pub shot: bool,
    pub landed: f32,
}

/// Animação procedural do viewmodel estilo CoD: transição suave para ADS, balanço da arma
/// ao girar (atraso), balanço em "8" ao andar, respiração, inclinação lateral, recuo com mola,
/// queda ao aterrissar e clipes de sprint/recarga ancorados no peito.
pub struct ViewmodelAnim {
    pub ads_w: f32,
    pub ads_e: f32,
    sprint_w: f32,
    reload_w: f32,
    t: f32,
    bob: f32,
    sway: Vec2,
    sway_v: Vec2,
    roll: f32,
    roll_v: f32,
    recoil: f32,
    recoil_v: f32,
    recoil_side: f32,
    dip: f32,
    dip_v: f32,
    crouch: f32,
    rng: u64,
    rel: Option<Rt>,
}
impl Default for ViewmodelAnim {
    fn default() -> Self {
        ViewmodelAnim {
            ads_w: 0.0,
            ads_e: 0.0,
            sprint_w: 0.0,
            reload_w: 0.0,
            t: 0.0,
            bob: 0.0,
            sway: Vec2::ZERO,
            sway_v: Vec2::ZERO,
            roll: 0.0,
            roll_v: 0.0,
            recoil: 0.0,
            recoil_v: 0.0,
            recoil_side: 0.0,
            dip: 0.0,
            dip_v: 0.0,
            crouch: 0.0,
            rng: 0x1234_5678_9ABC_DEF1,
            rel: None,
        }
    }
}
fn rnd(s: &mut u64) -> f32 {
    let mut x = *s;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *s = x;
    ((x >> 40) as f32 / (1u64 << 24) as f32) * 2.0 - 1.0
}

impl ViewmodelAnim {
    /// Retorna (raiz do viewmodel no espaço da câmera, pose).
    pub fn update(&mut self, d: &AnimData, i: &VmInput) -> (Rt, Pose) {
        let dt = i.dt.clamp(1e-4, 0.05);
        self.t += dt;
        // relação peito -> arma da pose de mira (constante)
        let rel = *self.rel.get_or_insert_with(|| {
            let p = d.viewmodel_pose(&d.sample("up_aim", 0.0));
            let f = d.fk(&p);
            Rt { p: f.gp[SPINE2], r: f.gr[SPINE2] }.inv().mul(Rt { p: f.wp, r: f.wr })
        });
        let speed = i.vel_local.length();
        // ---- pesos (ADS linear de 0,18 s com suavização)
        let ads_target = if i.ads && i.reload_t.is_none() && !i.sprint { 1.0 } else { 0.0 };
        let step = dt / 0.18;
        self.ads_w = if ads_target > self.ads_w { (self.ads_w + step).min(1.0) } else { (self.ads_w - step).max(0.0) };
        self.ads_e = smoothstep(self.ads_w);
        fade(&mut self.sprint_w, if i.sprint && speed > 0.5 { 1.0 } else { 0.0 }, 7.0, dt);
        fade(&mut self.reload_w, if i.reload_t.is_some() { 1.0 } else { 0.0 }, 12.0, dt);
        fade(&mut self.crouch, if i.crouch { 1.0 } else { 0.0 }, 8.0, dt);
        // ---- pose (mira / sprint / recarga)
        self.bob += dt * speed * 1.75;
        // pesos suavizados (smoothstep sobre o fade exponencial): entrada/saída sem tranco
        let ss = |x: f32| x * x * (3.0 - 2.0 * x);
        let rw = ss(self.reload_w);
        let mut parts = vec![(d.sample("up_aim", self.t), 1.0 - rw)];
        if rw > 1e-3 {
            parts.push((d.sample("up_reload", i.reload_t.unwrap_or(2.3)), rw));
        }
        let pose = d.viewmodel_pose(&blend(&parts));
        let f = d.fk(&pose);
        let chest_m = Rt { p: f.gp[SPINE2], r: f.gr[SPINE2] };
        let weapon_m = Rt { p: f.wp, r: f.wr };

        // ---- molas procedurais
        let e = self.ads_e;
        let still = 1.0 - 0.7 * e;
        let st = Vec2::new((-i.yaw_delta / dt * 0.02).clamp(-0.09, 0.09), (-i.pitch_delta / dt * 0.02).clamp(-0.07, 0.07)) * still;
        spring(&mut self.sway.x, &mut self.sway_v.x, st.x, 110.0, 0.75, dt);
        spring(&mut self.sway.y, &mut self.sway_v.y, st.y, 110.0, 0.75, dt);
        spring(&mut self.roll, &mut self.roll_v, (i.vel_local.x * 0.03).clamp(-0.12, 0.12) * still, 60.0, 0.9, dt);
        if i.shot {
            self.recoil_v += 4.2;
            self.recoil_side = rnd(&mut self.rng);
        }
        spring(&mut self.recoil, &mut self.recoil_v, 0.0, 260.0, 0.6, dt);
        if i.landed > 0.0 {
            self.dip_v -= (i.landed * 0.05).min(0.5);
        }
        spring(&mut self.dip, &mut self.dip_v, 0.0, 140.0, 0.55, dt);

        let amp = if i.grounded { (speed / 3.7).min(1.4) } else { 0.0 } * (1.0 - 0.8 * e);
        let sprint_k = 1.0 + 0.8 * self.sprint_w;
        let (sb, s2) = (self.bob.sin(), (2.0 * self.bob).sin());
        let breath = (self.t * 1.7).sin() * (1.0 - 0.6 * e);
        let rk = self.recoil * if i.ads { 0.6 } else { 1.0 };
        let off_p = Vec3::new(
            0.012 * amp * sb * sprint_k + self.sway.x * 0.12,
            0.008 * amp * s2 * sprint_k - 0.008 * amp + 0.0015 * breath + self.dip - 0.012 * self.crouch * (1.0 - e) + self.sway.y * 0.08,
            0.010 * amp + 0.045 * rk,
        );
        let off_r = ypr(
            self.sway.x + 0.010 * amp * sb + 0.012 * rk * self.recoil_side,
            self.sway.y + 0.004 * breath + 0.05 * rk + 0.006 * amp * s2,
            self.roll + 0.02 * amp * sb + self.sway.x * 0.6,
        );
        let base = vm_hip().lerp(vm_ads(), e);
        // sprint em 1ª pessoa (MW2): arma baixa, inclinada e girada para dentro
        let sw = ss(self.sprint_w);
        let sprint_p = Vec3::new(-0.02, -0.01, 0.03) * sw;
        let sprint_r = ypr(SPRINT_YAW * sw, 0.12 * sw, 0.6 * sw);
        let w_c = Rt { p: base.p + off_p + sprint_p, r: off_r * sprint_r * base.r };
        // desvio da arma em relação à pose de mira (sprint, recarga, respiração), no referencial da arma,
        // aplicado em escala reduzida para a ação continuar visível na tela (como nos viewmodels do CoD)
        let delta = rel.inv().mul(chest_m.inv().mul(weapon_m));
        let ks = 1.0 - e;
        let delta_s = Rt { p: Vec3::new(delta.p.x * 0.4, delta.p.y * 0.3 + 0.02 * rw, delta.p.z * 0.3) * ks, r: Quat::IDENTITY.slerp(delta.r, 0.8 * ks) };
        let w_final = w_c.mul(delta_s);
        (w_final.mul(weapon_m.inv()), pose)
    }
}
fn smoothstep(x: f32) -> f32 {
    let x = x.clamp(0.0, 1.0);
    x * x * (3.0 - 2.0 * x)
}
