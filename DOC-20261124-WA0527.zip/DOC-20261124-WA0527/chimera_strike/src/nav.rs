//! Navegação e utilidades de combate sem ECS: grade + A*, pontos de cobertura,
//! hitboxes por osso e interseção raio-cápsula.
#![allow(dead_code)]
use crate::anim_core::*;
use bevy::math::{Vec2, Vec3};
use std::cmp::Ordering;
use std::collections::BinaryHeap;

#[derive(Clone, Copy, Debug)]
pub struct Aabb {
    pub min: Vec3,
    pub max: Vec3,
}

pub struct NavGrid {
    pub origin: Vec2,
    pub cell: f32,
    pub w: usize,
    pub h: usize,
    pub blocked: Vec<bool>,
}

#[derive(Copy, Clone, PartialEq)]
struct Node(f32, usize);
impl Eq for Node {}
impl Ord for Node {
    fn cmp(&self, o: &Self) -> Ordering {
        o.0.partial_cmp(&self.0).unwrap_or(Ordering::Equal)
    }
}
impl PartialOrd for Node {
    fn partial_cmp(&self, o: &Self) -> Option<Ordering> {
        Some(self.cmp(o))
    }
}

impl NavGrid {
    pub fn build(obstacles: &[Aabb], half: f32, cell: f32, inflate: f32) -> NavGrid {
        let n = (2.0 * half / cell).ceil() as usize;
        let mut g = NavGrid { origin: Vec2::splat(-half), cell, w: n, h: n, blocked: vec![false; n * n] };
        for y in 0..n {
            for x in 0..n {
                let c = g.center(x, y);
                let mut b = false;
                for o in obstacles {
                    if o.max.y < 0.4 {
                        continue; // degrau baixo: dá para passar
                    }
                    if c.x > o.min.x - inflate && c.x < o.max.x + inflate && c.y > o.min.z - inflate && c.y < o.max.z + inflate {
                        b = true;
                        break;
                    }
                }
                g.blocked[y * n + x] = b;
            }
        }
        g
    }
    fn center(&self, x: usize, y: usize) -> Vec2 {
        self.origin + Vec2::new((x as f32 + 0.5) * self.cell, (y as f32 + 0.5) * self.cell)
    }
    fn cell_of(&self, p: Vec3) -> Option<(usize, usize)> {
        let q = (Vec2::new(p.x, p.z) - self.origin) / self.cell;
        if q.x < 0.0 || q.y < 0.0 {
            return None;
        }
        let (x, y) = (q.x as usize, q.y as usize);
        if x >= self.w || y >= self.h {
            None
        } else {
            Some((x, y))
        }
    }
    pub fn walkable(&self, p: Vec3) -> bool {
        self.cell_of(p).map(|(x, y)| !self.blocked[y * self.w + x]).unwrap_or(false)
    }
    /// linha livre entre dois pontos (amostrando a grade)
    pub fn clear_line(&self, a: Vec3, b: Vec3) -> bool {
        let d = Vec2::new(b.x - a.x, b.z - a.z);
        let n = (d.length() / (self.cell * 0.5)).ceil().max(1.0) as usize;
        (0..=n).all(|k| self.walkable(a + (b - a) * (k as f32 / n as f32)))
    }
    fn nearest_free(&self, p: Vec3) -> Option<(usize, usize)> {
        let (cx, cy) = self.cell_of(p)?;
        for r in 0..6i32 {
            for dy in -r..=r {
                for dx in -r..=r {
                    let (x, y) = (cx as i32 + dx, cy as i32 + dy);
                    if x >= 0 && y >= 0 && (x as usize) < self.w && (y as usize) < self.h && !self.blocked[y as usize * self.w + x as usize] {
                        return Some((x as usize, y as usize));
                    }
                }
            }
        }
        None
    }
    /// A* com 8 vizinhos (sem cortar quinas) + suavização por linha de visada.
    pub fn path(&self, from: Vec3, to: Vec3) -> Option<Vec<Vec3>> {
        let s = self.nearest_free(from)?;
        let g = self.nearest_free(to)?;
        let (w, h) = (self.w, self.h);
        let si = s.1 * w + s.0;
        let gi = g.1 * w + g.0;
        let mut cost = vec![f32::INFINITY; w * h];
        let mut prev = vec![usize::MAX; w * h];
        let mut open = BinaryHeap::new();
        cost[si] = 0.0;
        let hfn = |i: usize| {
            let (x, y) = ((i % w) as f32, (i / w) as f32);
            let (gx, gy) = (g.0 as f32, g.1 as f32);
            ((x - gx).powi(2) + (y - gy).powi(2)).sqrt()
        };
        open.push(Node(hfn(si), si));
        let mut iters = 0;
        while let Some(Node(_, i)) = open.pop() {
            iters += 1;
            if i == gi || iters > 40_000 {
                break;
            }
            let (x, y) = ((i % w) as i32, (i / w) as i32);
            for (dx, dy) in [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)] {
                let (nx, ny) = (x + dx, y + dy);
                if nx < 0 || ny < 0 || nx >= w as i32 || ny >= h as i32 {
                    continue;
                }
                let ni = ny as usize * w + nx as usize;
                if self.blocked[ni] {
                    continue;
                }
                if dx != 0 && dy != 0 && (self.blocked[y as usize * w + nx as usize] || self.blocked[ny as usize * w + x as usize]) {
                    continue;
                }
                let nc = cost[i] + if dx != 0 && dy != 0 { 1.4142 } else { 1.0 };
                if nc < cost[ni] {
                    cost[ni] = nc;
                    prev[ni] = i;
                    open.push(Node(nc + hfn(ni), ni));
                }
            }
        }
        if prev[gi] == usize::MAX && gi != si {
            return None;
        }
        let mut cells = vec![gi];
        let mut c = gi;
        while c != si {
            c = prev[c];
            if c == usize::MAX {
                return None;
            }
            cells.push(c);
        }
        cells.reverse();
        let pts: Vec<Vec3> = cells
            .iter()
            .map(|&i| {
                let c = self.center(i % w, i / w);
                Vec3::new(c.x, 0.0, c.y)
            })
            .collect();
        // suavização: pula pontos enquanto a linha estiver livre
        let mut out = vec![Vec3::new(from.x, 0.0, from.z)];
        let mut k = 0;
        while k < pts.len() - 1 {
            let mut j = pts.len() - 1;
            while j > k + 1 && !self.clear_line(pts[k], pts[j]) {
                j -= 1;
            }
            out.push(pts[j]);
            k = j;
        }
        if let Some(last) = out.last_mut() {
            if self.walkable(to) {
                *last = Vec3::new(to.x, 0.0, to.z);
            }
        }
        Some(out)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct CoverPoint {
    pub pos: Vec3,
    /// aponta para fora da cobertura (lado onde o soldado fica)
    pub normal: Vec3,
    pub tangent: Vec3,
    pub low: bool,
    /// meia largura da face (para espiar pelo lado)
    pub half_len: f32,
}

pub fn gen_covers(obstacles: &[Aabb], grid: &NavGrid) -> Vec<CoverPoint> {
    let mut out = Vec::new();
    for o in obstacles {
        let hgt = o.max.y;
        if !(0.95..=6.0).contains(&hgt) || o.min.y > 0.3 {
            continue;
        }
        let low = hgt < 1.45;
        let c = (o.min + o.max) * 0.5;
        let half = (o.max - o.min) * 0.5;
        if half.x > 20.0 || half.z > 20.0 {
            continue; // paredes externas
        }
        for (n, t, hn, ht) in [
            (Vec3::X, Vec3::Z, half.x, half.z),
            (Vec3::NEG_X, Vec3::Z, half.x, half.z),
            (Vec3::Z, Vec3::X, half.z, half.x),
            (Vec3::NEG_Z, Vec3::X, half.z, half.x),
        ] {
            let count = ((2.0 * ht) / 0.9).floor().max(1.0) as i32;
            for k in 0..count {
                let off = if count == 1 { 0.0 } else { -ht + 0.45 + (2.0 * ht - 0.9) * k as f32 / (count - 1) as f32 };
                let p = Vec3::new(c.x, 0.0, c.z) + n * (hn + 0.6) + t * off;
                if grid.walkable(p) {
                    out.push(CoverPoint { pos: p, normal: n, tangent: t, low, half_len: ht });
                }
            }
        }
    }
    out
}

/// Interseção raio (origem, direção unitária) com cápsula (segmento a-b, raio r).
/// A cápsula é tratada como união de esferas ao longo do segmento (passo <= r/2).
pub fn ray_capsule(o: Vec3, d: Vec3, a: Vec3, b: Vec3, r: f32) -> Option<f32> {
    let ab = b - a;
    let steps = ((ab.length() / (r * 0.5).max(0.01)).ceil() as usize).clamp(1, 24);
    let mut best = f32::INFINITY;
    for k in 0..=steps {
        if let Some(t) = ray_sphere(o, d, a + ab * (k as f32 / steps as f32), r) {
            best = best.min(t);
        }
    }
    if best.is_finite() {
        Some(best)
    } else {
        None
    }
}
fn ray_sphere(o: Vec3, d: Vec3, c: Vec3, r: f32) -> Option<f32> {
    let oc = o - c;
    let b = oc.dot(d);
    let cc = oc.dot(oc) - r * r;
    let disc = b * b - cc;
    if disc < 0.0 {
        return None;
    }
    let t = -b - disc.sqrt();
    if t >= 0.0 {
        Some(t)
    } else if cc < 0.0 {
        Some(0.0)
    } else {
        None
    }
}
/// distância de um ponto a um segmento
pub fn point_segment_dist(p: Vec3, a: Vec3, b: Vec3) -> f32 {
    let ab = b - a;
    let t = ((p - a).dot(ab) / ab.dot(ab).max(1e-9)).clamp(0.0, 1.0);
    (a + ab * t - p).length()
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Part {
    Head,
    Torso,
    Arm,
    Leg,
}
pub const HITBOX_COUNT: usize = 12;
/// Cápsulas de acerto por osso, no espaço do modelo.
pub fn hitboxes(fk: &Fk) -> [(Vec3, Vec3, f32, Part); HITBOX_COUNT] {
    let g = &fk.gp;
    let head_top = g[HEAD] + fk.gr[HEAD] * Vec3::new(0.0, 0.17, 0.02);
    [
        (g[HEAD] + fk.gr[HEAD] * Vec3::new(0.0, 0.03, 0.02), head_top, 0.105, Part::Head),
        (g[NECK], g[HEAD], 0.075, Part::Torso),
        (g[SPINE1], g[NECK], 0.17, Part::Torso),
        (g[HIPS], g[SPINE1], 0.16, Part::Torso),
        (g[R_ARM], g[R_FORE], 0.065, Part::Arm),
        (g[R_FORE], g[R_HAND], 0.055, Part::Arm),
        (g[L_ARM], g[L_FORE], 0.065, Part::Arm),
        (g[L_FORE], g[L_HAND], 0.055, Part::Arm),
        (g[R_UPLEG], g[R_LEG], 0.09, Part::Leg),
        (g[R_LEG], g[R_FOOT], 0.07, Part::Leg),
        (g[L_UPLEG], g[L_LEG], 0.09, Part::Leg),
        (g[L_LEG], g[L_FOOT], 0.07, Part::Leg),
    ]
}
