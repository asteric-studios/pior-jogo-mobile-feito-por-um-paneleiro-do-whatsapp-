//! Layout do mapa de teste como dados puros (usado pelo mundo e pela navegação da IA).
#![allow(dead_code)]
use crate::nav::Aabb;
use bevy::math::Vec3;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Mat {
    Floor,
    Wall,
    Orange,
    Dark,
    Crate,
}

#[derive(Clone, Copy, Debug)]
pub struct Block {
    pub pos: Vec3,
    pub size: Vec3,
    /// rotação em Z (rampa); 0 para caixas alinhadas
    pub rot_z: f32,
    pub mat: Mat,
}

pub const HALF: f32 = 40.0;
pub const PLAYER_SPAWN: Vec3 = Vec3::new(0.0, 0.0, 8.0);
/// pontos de nascimento do manequim (o mais distante do jogador é escolhido)
pub const ENEMY_SPAWNS: [Vec3; 5] = [
    Vec3::new(0.0, 0.0, -24.0),
    Vec3::new(-18.0, 0.0, -14.0),
    Vec3::new(20.0, 0.0, -18.0),
    Vec3::new(-24.0, 0.0, 20.0),
    Vec3::new(24.0, 0.0, 24.0),
];
pub const PATROL: [Vec3; 5] = [
    Vec3::new(-8.0, 0.0, -16.0),
    Vec3::new(8.0, 0.0, -20.0),
    Vec3::new(14.0, 0.0, -6.0),
    Vec3::new(-12.0, 0.0, -4.0),
    Vec3::new(0.0, 0.0, -28.0),
];

fn b(pos: Vec3, size: Vec3, mat: Mat) -> Block {
    Block { pos, size, rot_z: 0.0, mat }
}

pub fn blocks() -> Vec<Block> {
    let mut v = vec![
        b(Vec3::new(0.0, -0.5, 0.0), Vec3::new(80.0, 1.0, 80.0), Mat::Floor),
        b(Vec3::new(0.0, 2.5, -40.5), Vec3::new(82.0, 5.0, 1.0), Mat::Wall),
        b(Vec3::new(0.0, 2.5, 40.5), Vec3::new(82.0, 5.0, 1.0), Mat::Wall),
        b(Vec3::new(-40.5, 2.5, 0.0), Vec3::new(1.0, 5.0, 80.0), Mat::Wall),
        b(Vec3::new(40.5, 2.5, 0.0), Vec3::new(1.0, 5.0, 80.0), Mat::Wall),
        // coberturas perto do jogador
        b(Vec3::new(-4.0, 0.6, 2.0), Vec3::splat(1.2), Mat::Crate),
        b(Vec3::new(-5.2, 0.6, 2.3), Vec3::splat(1.2), Mat::Crate),
        b(Vec3::new(-4.6, 1.8, 2.15), Vec3::splat(1.2), Mat::Crate),
        b(Vec3::new(4.5, 0.55, 0.0), Vec3::new(2.6, 1.1, 0.5), Mat::Dark),
        b(Vec3::new(1.0, 0.55, -6.0), Vec3::new(2.6, 1.1, 0.5), Mat::Dark),
        b(Vec3::new(-2.5, 0.55, -7.5), Vec3::new(2.6, 1.1, 0.5), Mat::Dark),
        b(Vec3::new(8.0, 2.0, 6.0), Vec3::new(1.0, 4.0, 1.0), Mat::Wall),
        b(Vec3::new(-9.0, 2.0, -2.0), Vec3::new(1.0, 4.0, 1.0), Mat::Wall),
        b(Vec3::new(10.0, 0.4, -3.0), Vec3::new(1.6, 0.8, 1.6), Mat::Crate),
        // campo de combate do manequim (zona norte / laterais)
        b(Vec3::new(-10.0, 0.55, -12.0), Vec3::new(3.0, 1.1, 0.5), Mat::Dark),
        b(Vec3::new(9.0, 0.55, -13.0), Vec3::new(3.0, 1.1, 0.5), Mat::Dark),
        b(Vec3::new(-6.0, 0.6, -19.0), Vec3::new(1.2, 1.2, 1.2), Mat::Crate),
        b(Vec3::new(6.0, 1.2, -22.0), Vec3::new(1.2, 2.4, 2.4), Mat::Crate),
        b(Vec3::new(-14.0, 1.5, -24.0), Vec3::new(4.0, 3.0, 1.0), Mat::Wall),
        b(Vec3::new(15.0, 1.5, -26.0), Vec3::new(1.0, 3.0, 4.0), Mat::Wall),
        b(Vec3::new(-3.0, 0.55, -28.0), Vec3::new(3.0, 1.1, 0.5), Mat::Dark),
        b(Vec3::new(18.0, 0.55, -8.0), Vec3::new(0.5, 1.1, 3.0), Mat::Dark),
        b(Vec3::new(-18.0, 0.55, -6.0), Vec3::new(0.5, 1.1, 3.0), Mat::Dark),
        b(Vec3::new(-20.0, 1.2, 14.0), Vec3::new(2.4, 2.4, 1.2), Mat::Crate),
        b(Vec3::new(20.0, 0.55, 16.0), Vec3::new(3.0, 1.1, 0.5), Mat::Dark),
        // contêiner (com rampa) e plataforma (com escada)
        b(Vec3::new(-14.0, 1.3, 8.0), Vec3::new(6.0, 2.6, 2.6), Mat::Orange),
        b(Vec3::new(14.0, 0.8, 10.0), Vec3::new(5.0, 1.6, 5.0), Mat::Wall),
    ];
    let ramp_len = 6.0f32;
    let ang = (2.6f32 / ramp_len).asin();
    v.push(Block {
        pos: Vec3::new(-11.0 + ramp_len * ang.cos() * 0.5 - 0.05, 1.3 - 0.12, 8.0),
        size: Vec3::new(ramp_len, 0.25, 2.4),
        rot_z: -ang,
        mat: Mat::Dark,
    });
    let plat_h = 1.6f32;
    let steps = 8;
    for i in 0..steps {
        let h = plat_h * (i as f32 + 1.0) / steps as f32;
        v.push(b(
            Vec3::new(14.0, h * 0.5, 12.5 + 0.35 * (steps - i) as f32 - 0.175),
            Vec3::new(2.0, h, 0.35),
            Mat::Dark,
        ));
    }
    v
}

/// Caixas de colisão estáticas para a navegação (sem piso e sem a rampa).
pub fn obstacles() -> Vec<Aabb> {
    blocks()
        .iter()
        .filter(|b| b.rot_z == 0.0 && b.mat != Mat::Floor)
        .map(|b| Aabb { min: b.pos - b.size * 0.5, max: b.pos + b.size * 0.5 })
        .collect()
}
