//! HUD: mira dinâmica, munição, acertos, FPS e aviso de carregamento.

use crate::player::{GodMode, Player};
use crate::viewmodel::ViewMode;
use crate::weapon::WeaponState;
use bevy::prelude::*;

#[derive(Component)]
struct CrossBar(u8);
/// Retículo da luneta em 1ª pessoa: 0 = ponto vermelho, 1..=4 fios finos, 5..=8 postes grossos.
#[derive(Component)]
struct ScopeRet(u8);
#[derive(Component)]
struct AmmoText;
#[derive(Component)]
struct InfoText;
#[derive(Component)]
pub struct LoadingText;
#[derive(Component)]
struct DamageOverlay;
#[derive(Component)]
struct StatusText;

pub struct HudPlugin;
impl Plugin for HudPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, spawn_hud).add_systems(Update, update_hud);
    }
}

fn spawn_hud(mut c: Commands) {
    // tela vermelha de dano (estilo MW2: sem barra de vida)
    c.spawn((
        NodeBundle {
            style: Style { position_type: PositionType::Absolute, width: Val::Percent(100.0), height: Val::Percent(100.0), ..default() },
            background_color: BackgroundColor(Color::srgba(0.6, 0.0, 0.0, 0.0)),
            ..default()
        },
        DamageOverlay,
    ));
    c.spawn((
        TextBundle::from_section("", TextStyle { font_size: 34.0, color: Color::srgb(1.0, 0.85, 0.3), ..default() }).with_style(Style {
            position_type: PositionType::Absolute,
            left: Val::Percent(36.0),
            top: Val::Percent(30.0),
            ..default()
        }),
        StatusText,
    ));
    // contêiner centralizado de tamanho zero: as barras da mira são posicionadas relativas a ele
    c.spawn(NodeBundle {
        style: Style {
            position_type: PositionType::Absolute,
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            justify_content: JustifyContent::Center,
            align_items: AlignItems::Center,
            ..default()
        },
        ..default()
    })
    .with_children(|p| {
        p.spawn(NodeBundle {
            style: Style { width: Val::Px(0.0), height: Val::Px(0.0), ..default() },
            ..default()
        })
        .with_children(|p| {
            for i in 0..5u8 {
                p.spawn((
                    NodeBundle {
                        style: Style { position_type: PositionType::Absolute, ..default() },
                        background_color: BackgroundColor(Color::srgba(1.0, 1.0, 1.0, 0.9)),
                        ..default()
                    },
                    CrossBar(i),
                ));
            }
            // retículo duplex da luneta (fino, sem tapar a visão)
            let (g, thin_l, post_l) = (9.0, 72.0, 170.0);
            let rects: [(f32, f32, f32, f32); 9] = [
                (-2.5, -2.5, 5.0, 5.0),
                (g, -0.5, thin_l, 1.0),
                (-g - thin_l, -0.5, thin_l, 1.0),
                (-0.5, g, 1.0, thin_l),
                (-0.5, -g - thin_l, 1.0, thin_l),
                (g + thin_l, -1.5, post_l, 3.0),
                (-g - thin_l - post_l, -1.5, post_l, 3.0),
                (-1.5, g + thin_l, 3.0, post_l),
                (-1.5, -g - thin_l - post_l, 3.0, post_l),
            ];
            for (i, (l, t, w, h)) in rects.iter().enumerate() {
                p.spawn((
                    NodeBundle {
                        style: Style {
                            position_type: PositionType::Absolute,
                            left: Val::Px(*l),
                            top: Val::Px(*t),
                            width: Val::Px(*w),
                            height: Val::Px(*h),
                            display: Display::None,
                            ..default()
                        },
                        border_radius: if i == 0 { BorderRadius::all(Val::Px(2.5)) } else { BorderRadius::ZERO },
                        background_color: BackgroundColor(Color::NONE),
                        ..default()
                    },
                    ScopeRet(i as u8),
                ));
            }
        });
    });
    c.spawn((
        TextBundle::from_section("30 / 210", TextStyle { font_size: 30.0, color: Color::WHITE, ..default() }).with_style(Style {
            position_type: PositionType::Absolute,
            right: Val::Px(40.0),
            top: Val::Px(18.0),
            ..default()
        }),
        AmmoText,
    ));
    c.spawn((
        TextBundle::from_section("", TextStyle { font_size: 16.0, color: Color::srgba(1.0, 1.0, 1.0, 0.8), ..default() }).with_style(Style {
            position_type: PositionType::Absolute,
            left: Val::Px(18.0),
            top: Val::Px(14.0),
            ..default()
        }),
        InfoText,
    ));
    c.spawn((
        TextBundle::from_section("Carregando soldado...", TextStyle { font_size: 28.0, color: Color::WHITE, ..default() }).with_style(Style {
            position_type: PositionType::Absolute,
            left: Val::Percent(38.0),
            top: Val::Percent(45.0),
            ..default()
        }),
        LoadingText,
    ));
}

#[allow(clippy::too_many_arguments, clippy::type_complexity)]
fn update_hud(
    time: Res<Time>,
    ws: Res<WeaponState>,
    god: Res<GodMode>,
    vm: Res<ViewMode>,
    players: Query<&Player>,
    mut bars: Query<(&CrossBar, &mut Style, &mut BackgroundColor), Without<ScopeRet>>,
    mut rets: Query<(&ScopeRet, &mut Style, &mut BackgroundColor), Without<CrossBar>>,
    mut overlay: Query<&mut BackgroundColor, (With<DamageOverlay>, Without<CrossBar>, Without<ScopeRet>)>,
    mut ammo: Query<&mut Text, (With<AmmoText>, Without<InfoText>, Without<StatusText>)>,
    mut info: Query<&mut Text, (With<InfoText>, Without<AmmoText>, Without<StatusText>)>,
    mut status: Query<&mut Text, (With<StatusText>, Without<AmmoText>, Without<InfoText>)>,
    mut fps: Local<(f32, u32, f32)>,
) {
    let (health, hurt, dead, deaths) = players
        .get_single()
        .map(|p| (p.health, p.hurt_flash, p.dead, p.deaths))
        .unwrap_or((100.0, 0.0, false, 0));
    if let Ok(mut bg) = overlay.get_single_mut() {
        let a = ((1.0 - health / 100.0) * 0.5 + hurt * 0.22 + if dead { 0.35 } else { 0.0 }).clamp(0.0, 0.75);
        bg.0 = Color::srgba(0.55, 0.0, 0.0, a);
    }
    if let Ok(mut t) = status.get_single_mut() {
        t.sections[0].value = if dead {
            "VOCE MORREU".to_string()
        } else if god.0 {
            "IMORTAL".to_string()
        } else {
            String::new()
        };
        t.sections[0].style.font_size = if dead { 40.0 } else { 18.0 };
    }
    // mira: abre com o spread e fica vermelha ao acertar
    let gap = 6.0 + ws.spread_deg * 9.0;
    let hit = ws.hitmarker > 0.0;
    let col = if hit && ws.hit_enemy {
        Color::srgb(1.0, 0.2, 0.15)
    } else if hit {
        Color::srgb(1.0, 0.8, 0.3)
    } else {
        Color::srgba(1.0, 1.0, 1.0, 0.9)
    };
    let (len, th) = (10.0, 2.0);
    for (b, mut s, mut bg) in bars.iter_mut() {
        bg.0 = col;
        let (l, t, w, h) = match b.0 {
            0 => (gap, -th * 0.5, len, th),
            1 => (-gap - len, -th * 0.5, len, th),
            2 => (-th * 0.5, gap, th, len),
            3 => (-th * 0.5, -gap - len, th, len),
            _ => (-1.5, -1.5, 3.0, 3.0),
        };
        s.left = Val::Px(l);
        s.top = Val::Px(t);
        s.width = Val::Px(w);
        s.height = Val::Px(h);
        let fp_ads = vm.first && vm.ads_e > 0.35;
        s.display = if (ws.ads && b.0 < 4) || fp_ads || dead { Display::None } else { Display::Flex };
    }
    // retículo aparece conforme a luneta encosta no olho
    let k = if vm.first && !dead { ((vm.ads_e - 0.55) / 0.4).clamp(0.0, 1.0) } else { 0.0 };
    for (r, mut s, mut bg) in rets.iter_mut() {
        s.display = if k > 0.01 { Display::Flex } else { Display::None };
        bg.0 = match r.0 {
            0 => if hit && ws.hit_enemy { Color::srgba(1.0, 0.85, 0.2, k) } else { Color::srgba(1.0, 0.08, 0.05, k) },
            1..=4 => Color::srgba(0.02, 0.02, 0.02, 0.85 * k),
            _ => Color::srgba(0.02, 0.02, 0.02, 0.9 * k),
        };
    }
    if let Ok(mut t) = ammo.get_single_mut() {
        t.sections[0].value = if ws.reloading.is_some() {
            "RECARREGANDO".to_string()
        } else {
            format!("{} / {}", ws.mag, ws.reserve)
        };
        t.sections[0].style.color = if ws.mag == 0 { Color::srgb(1.0, 0.3, 0.25) } else { Color::WHITE };
    }
    fps.0 += time.delta_seconds();
    fps.1 += 1;
    if fps.0 >= 0.5 {
        fps.2 = fps.1 as f32 / fps.0;
        fps.0 = 0.0;
        fps.1 = 0;
    }
    if let Ok(mut t) = info.get_single_mut() {
        t.sections[0].value = format!(
            "CHIMERA STRIKE  |  mapa de teste\nAbates: {}   Mortes: {}   Aco: {}\nVida: {:.0}   FPS {:.0}",
            ws.kills, deaths, ws.hits, health, fps.2
        );
    }
}
