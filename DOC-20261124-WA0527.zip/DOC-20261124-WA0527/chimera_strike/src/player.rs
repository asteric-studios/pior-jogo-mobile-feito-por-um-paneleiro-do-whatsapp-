//! Jogador: controlador cinemático do Rapier, estados (agachar, mirar, correr, pular),
//! vida com regeneração (estilo CoD), morte/renascimento, modo imortal, câmera sobre o ombro
//! com colisão e animação pelo `Animator` (IK dos pés no terreno, giro das pernas, etc.).

use crate::anim::{Anim, CurrentPose, Rig, SoldierModel};
use crate::anim_core::{HEAD, L_FOOT, R_FOOT};
use crate::animator::{AnimInput, Animator, UpperMode};
use crate::controls::PlayerInput;
use crate::hud::LoadingText;
use crate::weapon::WeaponState;
use crate::world::WORLD_GROUP;
use bevy::core_pipeline::fxaa::Fxaa;
use bevy::pbr::{FogFalloff, FogSettings};
use bevy::prelude::*;
use bevy::transform::TransformSystem;
use bevy_rapier3d::prelude::*;
use std::f32::consts::PI;

const RADIUS: f32 = 0.3;
const STAND_HALF: f32 = 0.55; // cápsula de 1,70 m
const CROUCH_HALF: f32 = 0.3; // cápsula de 1,20 m
const GRAVITY: f32 = 17.0;
const JUMP_V: f32 = 5.4;
const SPEED_JOG: f32 = 3.7;
const SPEED_ADS: f32 = 1.9;
const SPEED_CROUCH: f32 = 1.8;
const SPEED_SPRINT: f32 = 6.0;
pub const MAX_HEALTH: f32 = 100.0;
/// grupo de colisão dos inimigos (cápsula de movimento)
pub const ENEMY_GROUP: Group = Group::GROUP_4;

pub fn center_h(crouch: bool) -> f32 {
    (if crouch { CROUCH_HALF } else { STAND_HALF }) + RADIUS
}

#[derive(Resource, Default)]
pub struct GodMode(pub bool);

/// Dano recebido pelo jogador (direção do projétil no mundo).
#[derive(Event)]
pub struct PlayerHit {
    pub dir: Vec3,
    pub dmg: f32,
}

#[derive(Component)]
pub struct Player {
    pub model: Entity,
    pub yaw: f32,
    pub pitch: f32,
    prev_yaw: f32,
    prev_pitch: f32,
    pub vel: Vec3,
    pub grounded: bool,
    was_grounded: bool,
    fall_speed: f32,
    pub crouch: bool,
    ads_toggled: bool,
    pub ads_effective: bool,
    pub sprint: bool,
    pub recoil_pending: f32,
    pub health: f32,
    pub since_hurt: f32,
    pub hurt_flash: f32,
    pub hurt_dir: Vec3,
    pub dead: bool,
    pub dead_t: f32,
    pub deaths: u32,
}

#[derive(Component, Default)]
pub struct PlayerAnim(pub Animator);

#[derive(Component)]
pub struct PlayerCamera;

pub struct PlayerPlugin;
impl Plugin for PlayerPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<GodMode>()
            .add_event::<PlayerHit>()
            .add_systems(Startup, spawn_player)
            .add_systems(Update, (player_control, player_damage.after(player_control), player_animate.after(player_damage), hide_loading))
            .add_systems(
                PostUpdate,
                camera_follow.after(PhysicsSet::Writeback).before(TransformSystem::TransformPropagate),
            );
    }
}

fn spawn_player(mut c: Commands, assets: Res<AssetServer>) {
    let model = c
        .spawn((
            SceneBundle {
                scene: assets.load("soldier.glb#Scene0"),
                // o modelo olha para +Z; o "frente" do Bevy é −Z, por isso gira 180°
                transform: Transform::from_xyz(0.0, -center_h(false), 0.0).with_rotation(Quat::from_rotation_y(PI)),
                ..default()
            },
            SoldierModel,
            CurrentPose::default(),
        ))
        .id();
    let spawn = crate::map::PLAYER_SPAWN;
    c.spawn((
        SpatialBundle::from_transform(Transform::from_xyz(spawn.x, center_h(false) + 0.02, spawn.z)),
        RigidBody::KinematicPositionBased,
        Collider::capsule_y(STAND_HALF, RADIUS),
        KinematicCharacterController {
            offset: CharacterLength::Absolute(0.02),
            up: Vec3::Y,
            max_slope_climb_angle: 50f32.to_radians(),
            min_slope_slide_angle: 40f32.to_radians(),
            autostep: Some(CharacterAutostep {
                max_height: CharacterLength::Absolute(0.4),
                min_width: CharacterLength::Absolute(0.15),
                include_dynamic_bodies: false,
            }),
            snap_to_ground: Some(CharacterLength::Absolute(0.3)),
            apply_impulse_to_dynamic_bodies: true,
            filter_groups: Some(CollisionGroups::new(Group::GROUP_2, WORLD_GROUP | ENEMY_GROUP)),
            ..default()
        },
        CollisionGroups::new(Group::GROUP_2, WORLD_GROUP | Group::GROUP_2 | ENEMY_GROUP),
        Player {
            model,
            yaw: 0.0,
            pitch: 0.0,
            prev_yaw: 0.0,
            prev_pitch: 0.0,
            vel: Vec3::ZERO,
            grounded: false,
            was_grounded: false,
            fall_speed: 0.0,
            crouch: false,
            ads_toggled: false,
            ads_effective: false,
            sprint: false,
            recoil_pending: 0.0,
            health: MAX_HEALTH,
            since_hurt: 99.0,
            hurt_flash: 0.0,
            hurt_dir: Vec3::ZERO,
            dead: false,
            dead_t: 0.0,
            deaths: 0,
        },
        PlayerAnim::default(),
    ))
    .add_child(model);

    let mut cam = c.spawn((
        Camera3dBundle {
            transform: Transform::from_xyz(0.6, 1.8, 11.0).looking_at(Vec3::new(0.0, 1.4, 0.0), Vec3::Y),
            projection: Projection::Perspective(PerspectiveProjection {
                fov: 68f32.to_radians(),
                near: 0.05,
                far: 400.0,
                ..default()
            }),
            ..default()
        },
        FogSettings {
            color: Color::srgba(0.6, 0.67, 0.74, 1.0),
            falloff: FogFalloff::Linear { start: 50.0, end: 160.0 },
            ..default()
        },
        PlayerCamera,
    ));
    if cfg!(target_os = "android") {
        // MSAA fica desligado no Android (alguns aparelhos travam); FXAA no lugar
        cam.insert(Fxaa::default());
    }
}

fn headroom_ok(rapier: &RapierContext, pos: Vec3, me: Entity) -> bool {
    let filter = QueryFilter::default().groups(CollisionGroups::new(Group::GROUP_2, WORLD_GROUP)).exclude_collider(me);
    let from = pos + Vec3::Y * (CROUCH_HALF + RADIUS - 0.05);
    rapier.cast_ray(from, Vec3::Y, 2.0 * (STAND_HALF - CROUCH_HALF) + 0.1, true, filter).is_none()
}

#[allow(clippy::type_complexity, clippy::too_many_arguments)]
pub fn player_control(
    time: Res<Time>,
    inp: Res<PlayerInput>,
    ws: Res<WeaponState>,
    mut god: ResMut<GodMode>,
    rapier: Res<RapierContext>,
    mut q: Query<(
        Entity,
        &mut Player,
        &mut KinematicCharacterController,
        Option<&KinematicCharacterControllerOutput>,
        &mut Transform,
        &mut Collider,
    )>,
    mut model: Query<&mut Transform, (With<SoldierModel>, Without<Player>)>,
    vm: Res<crate::viewmodel::ViewMode>,
) {
    let dt = time.delta_seconds().min(0.05);
    let Ok((me, mut pl, mut kcc, out, mut tf, mut col)) = q.get_single_mut() else { return };
    if inp.god_toggle {
        god.0 = !god.0;
        if god.0 {
            pl.health = MAX_HEALTH;
        }
    }
    pl.grounded = out.map(|o| o.grounded).unwrap_or(false);

    // ---- morto: espera e renasce
    if pl.dead {
        pl.dead_t += dt;
        pl.vel = Vec3::new(0.0, pl.vel.y - GRAVITY * dt, 0.0);
        if pl.grounded {
            pl.vel.y = -2.0;
        }
        kcc.translation = Some(pl.vel * dt);
        if pl.dead_t > 4.0 {
            let s = crate::map::PLAYER_SPAWN;
            tf.translation = Vec3::new(s.x, center_h(false) + 0.05, s.z);
            *col = Collider::capsule_y(STAND_HALF, RADIUS);
            pl.crouch = false;
            pl.dead = false;
            pl.health = MAX_HEALTH;
            pl.vel = Vec3::ZERO;
            pl.yaw = 0.0;
            pl.pitch = 0.0;
        }
        return;
    }

    // ---- olhar
    let sens = if pl.ads_effective { 0.55 } else { 1.0 };
    pl.yaw -= (inp.look.x * sens).to_radians();
    pl.pitch = (pl.pitch + (inp.look.y * sens).to_radians()).clamp(if vm.first { -1.38 } else { -1.05 }, 1.1);
    let rec = pl.recoil_pending * (dt * 7.0).min(1.0);
    pl.pitch -= rec;
    pl.recoil_pending -= rec;

    let reloading = ws.reloading.is_some();

    // ---- agachar / levantar
    let mut want_crouch = pl.crouch;
    if inp.crouch_toggle {
        want_crouch = !pl.crouch;
    }
    if inp.jump && pl.crouch {
        want_crouch = false;
    }
    if want_crouch != pl.crouch && (want_crouch || headroom_ok(&rapier, tf.translation, me)) {
        let dy = center_h(want_crouch) - center_h(pl.crouch);
        tf.translation.y += dy;
        *col = Collider::capsule_y(if want_crouch { CROUCH_HALF } else { STAND_HALF }, RADIUS);
        pl.crouch = want_crouch;
        if want_crouch {
            pl.sprint = false;
        }
    }
    if let Ok(mut mt) = model.get_mut(pl.model) {
        mt.translation.y = -center_h(pl.crouch);
    }

    // ---- mira (ADS) e corrida
    if inp.ads_toggle {
        pl.ads_toggled = !pl.ads_toggled;
    }
    let mv = inp.move_axis.clamp_length_max(1.0);
    if pl.sprint {
        if mv.y < 0.45 || inp.fire || inp.ads_toggle || inp.ads_hold || reloading || pl.crouch {
            pl.sprint = false;
        }
    } else if inp.sprint && mv.y > 0.6 && !pl.crouch && !reloading && !inp.fire {
        pl.sprint = true;
        pl.ads_toggled = false;
    }
    pl.ads_effective = (pl.ads_toggled || inp.ads_hold) && !pl.sprint && !reloading;

    // ---- pulo
    if inp.jump && pl.grounded && !pl.crouch {
        pl.vel.y = JUMP_V;
        pl.grounded = false;
    }

    // ---- movimento
    let rot = Quat::from_rotation_y(pl.yaw);
    let fwd = rot * Vec3::NEG_Z;
    let right = rot * Vec3::X;
    let speed = if pl.sprint {
        SPEED_SPRINT
    } else if pl.crouch {
        SPEED_CROUCH
    } else if pl.ads_effective {
        SPEED_ADS
    } else {
        SPEED_JOG
    };
    let wish = if pl.sprint { fwd * mv.length().max(0.85) } else { right * mv.x + fwd * mv.y } * speed;
    let accel = if pl.grounded { 14.0 } else { 3.0 };
    let h = Vec3::new(pl.vel.x, 0.0, pl.vel.z);
    let nh = h + (wish - h) * (accel * dt).min(1.0);
    pl.vel.x = nh.x;
    pl.vel.z = nh.z;
    if pl.grounded && pl.vel.y <= 0.0 {
        pl.vel.y = -2.0;
    } else {
        pl.vel.y -= GRAVITY * dt;
        pl.fall_speed = pl.fall_speed.max(-pl.vel.y);
    }
    if let Some(o) = out {
        if pl.vel.y > 0.0 && o.desired_translation.y > 1e-4 && o.effective_translation.y < o.desired_translation.y * 0.3 {
            pl.vel.y = 0.0;
        }
    }
    kcc.translation = Some(pl.vel * dt);
    tf.rotation = rot;
}

fn player_damage(
    time: Res<Time>,
    god: Res<GodMode>,
    mut ev: EventReader<PlayerHit>,
    mut q: Query<(&mut Player, &Transform, &mut PlayerAnim)>,
) {
    let dt = time.delta_seconds();
    let Ok((mut pl, tf, mut an)) = q.get_single_mut() else {
        ev.clear();
        return;
    };
    pl.since_hurt += dt;
    pl.hurt_flash = (pl.hurt_flash - dt * 1.5).max(0.0);
    for h in ev.read() {
        if pl.dead {
            continue;
        }
        pl.since_hurt = 0.0;
        pl.hurt_flash = (pl.hurt_flash + 0.45).min(1.0);
        pl.hurt_dir = h.dir;
        // reação no corpo (direção no espaço do modelo: o modelo está girado 180°)
        let local = tf.rotation.inverse() * h.dir;
        an.0.hit(Vec3::new(-local.x, local.y, -local.z), 1, 0.6);
        if !god.0 {
            pl.health -= h.dmg;
            if pl.health <= 0.0 {
                pl.health = 0.0;
                pl.dead = true;
                pl.dead_t = 0.0;
                pl.sprint = false;
                pl.ads_toggled = false;
                pl.deaths += 1;
            }
        }
    }
    // regeneração (CoD): depois de 4 s sem levar dano
    if !pl.dead && pl.since_hurt > 4.0 {
        pl.health = (pl.health + 30.0 * dt).min(MAX_HEALTH);
    }
}

#[allow(clippy::too_many_arguments)]
pub fn player_animate(
    time: Res<Time>,
    anim: Res<Anim>,
    ws: Res<WeaponState>,
    inp: Res<PlayerInput>,
    rapier: Res<RapierContext>,
    mut q: Query<(&mut Player, &Transform, &mut PlayerAnim)>,
    mut models: Query<(&mut CurrentPose, &Transform), Without<Player>>,
    vm: Res<crate::viewmodel::ViewMode>,
) {
    let dt = time.delta_seconds().min(0.05);
    let Ok((mut pl, tf, mut an)) = q.get_single_mut() else { return };
    let Ok((mut cur, mtf)) = models.get_mut(pl.model) else { return };

    // velocidade no espaço do modelo (+Z = frente, +X = esquerda do personagem)
    let fwd = tf.rotation * Vec3::NEG_Z;
    let right = tf.rotation * Vec3::X;
    let hv = Vec3::new(pl.vel.x, 0.0, pl.vel.z);
    let vel_local = Vec2::new(-hv.dot(right), hv.dot(fwd));
    let moving = vel_local.length() > 0.25;

    // aterrissagem
    if pl.grounded && !pl.was_grounded && pl.fall_speed > 2.0 {
        let fs = pl.fall_speed;
        an.0.land(fs);
    }
    if pl.grounded {
        pl.fall_speed = 0.0;
    }
    pl.was_grounded = pl.grounded;

    // IK dos pés: altura do chão sob cada pé (raio para baixo)
    let feet = if pl.grounded && !pl.dead {
        let model_w = tf.compute_matrix() * mtf.compute_matrix();
        let fk = anim.fk(&an.0.last);
        let base_y = tf.translation.y - center_h(pl.crouch);
        let filter = QueryFilter::default().groups(CollisionGroups::new(WORLD_GROUP, WORLD_GROUP));
        let mut off = [0.0f32; 2];
        for (k, b) in [L_FOOT, R_FOOT].iter().enumerate() {
            let wp = model_w.transform_point3(fk.gp[*b]);
            let from = Vec3::new(wp.x, base_y + 0.55, wp.z);
            if let Some((_, toi)) = rapier.cast_ray(from, Vec3::NEG_Y, 1.0, true, filter) {
                off[k] = ((from.y - toi) - base_y).clamp(-0.3, 0.45);
            }
        }
        Some((off[0], off[1]))
    } else {
        None
    };

    let mut dyaw = pl.yaw - pl.prev_yaw;
    if dyaw > PI {
        dyaw -= 2.0 * PI;
    } else if dyaw < -PI {
        dyaw += 2.0 * PI;
    }
    let dpitch = pl.pitch - pl.prev_pitch;
    pl.prev_yaw = pl.yaw;
    pl.prev_pitch = pl.pitch;

    let upper = if pl.sprint && moving {
        UpperMode::Sprint
    } else if pl.ads_effective || inp.fire || ws.since_shot < 1.4 {
        UpperMode::Aim
    } else {
        UpperMode::Low
    };
    let input = AnimInput {
        dt,
        vel_local,
        grounded: pl.grounded,
        crouch: pl.crouch,
        sprint: pl.sprint,
        ads: pl.ads_effective,
        upper,
        reload_t: ws.reloading,
        aim_yaw: 0.0,
        // em 1ª pessoa o tronco quase não curva (senão a câmera, presa à cabeça, passa à frente do corpo)
        aim_pitch: if vm.first && !pl.dead { pl.pitch.clamp(-0.25, 0.35) } else { pl.pitch },
        root_yaw_delta: dyaw,
        pitch_delta: dpitch,
        recoil: ws.recoil_anim,
        feet,
        full: if pl.dead { Some(("death_back", pl.dead_t)) } else { None },
    };
    cur.0 = Some(an.0.update(&anim, &input));
}

fn hide_loading(mut c: Commands, rigs: Query<(), Added<Rig>>, txt: Query<Entity, With<LoadingText>>) {
    if !rigs.is_empty() {
        for e in txt.iter() {
            c.entity(e).despawn_recursive();
        }
    }
}

#[derive(Default)]
struct CamSmooth {
    fp: bool,
    fp_y: f32,
    offset: Vec3,
    pivot_y: f32,
    init: bool,
}

#[allow(clippy::type_complexity)]
fn camera_follow(
    time: Res<Time>,
    rapier: Res<RapierContext>,
    players: Query<(&Player, &Transform)>,
    mut cams: Query<(&mut Transform, &mut Projection), (With<PlayerCamera>, Without<Player>)>,
    models: Query<(&CurrentPose, &Transform), (Without<PlayerCamera>, Without<Player>)>,
    anim: Res<Anim>,
    vm: Res<crate::viewmodel::ViewMode>,
    mut sm: Local<CamSmooth>,
) {
    let dt = time.delta_seconds().min(0.05);
    let (Ok((pl, ptf)), Ok((mut ctf, mut proj))) = (players.get_single(), cams.get_single_mut()) else { return };
    // ---- 1ª pessoa: câmera nos olhos do próprio corpo (o corpo aparece ao olhar para baixo)
    if vm.first && !pl.dead {
        if let Ok((cur, mtf)) = models.get(pl.model) {
            if let Some(pose) = cur.0 {
                let fk = anim.fk(&pose);
                let model_w = ptf.compute_matrix() * mtf.compute_matrix();
                let head = model_w.transform_point3(fk.gp[HEAD]);
                // olhos 7 cm acima e 9 cm à frente da junta da cabeça (no plano horizontal), mais um
                // pivô de pescoço leve ao olhar para cima/baixo
                let flat = Quat::from_rotation_y(pl.yaw) * Vec3::NEG_Z;
                let eye = head + Vec3::Y * (0.07 + 0.04 * pl.pitch.sin()) + flat * (0.09 + 0.03 * pl.pitch.cos() + 0.10 * (-pl.pitch.sin()).max(0.0));
                // filtra só o balanço vertical do passo (horizontal fica preso ao corpo)
                if !sm.fp {
                    sm.fp_y = eye.y;
                    sm.fp = true;
                }
                sm.fp_y += (eye.y - sm.fp_y) * (dt * 18.0).min(1.0);
                let shake = pl.hurt_flash * 0.01 * ((time.elapsed_seconds() * 53.0).sin());
                ctf.translation = Vec3::new(eye.x, sm.fp_y, eye.z);
                ctf.rotation = Quat::from_euler(EulerRot::YXZ, pl.yaw + shake, pl.pitch + shake * 0.7, 0.0);
                if let Projection::Perspective(p) = &mut *proj {
                    let ads = vm.ads_e;
                    let base = if pl.sprint { 78f32 } else { 72.0 };
                    let target = (base + (40.0 - base) * ads).to_radians();
                    p.fov += (target - p.fov) * (dt * 14.0).min(1.0);
                    p.near = 0.06;
                }
                sm.init = false;
                return;
            }
        }
    }
    sm.fp = false;
    if let Projection::Perspective(p) = &mut *proj {
        p.near = 0.05;
    }
    let feet = ptf.translation.y - center_h(pl.crouch);
    let eye = feet + if pl.dead { 0.6 } else if pl.crouch { 1.12 } else { 1.58 };
    let target_off = if pl.dead {
        Vec3::new(0.0, 0.8, 3.2)
    } else if pl.ads_effective {
        Vec3::new(0.42, 0.04, 1.15)
    } else if pl.sprint {
        Vec3::new(0.5, 0.12, 2.8)
    } else {
        Vec3::new(0.55, 0.12, 2.35)
    };
    if !sm.init {
        sm.offset = target_off;
        sm.pivot_y = eye;
        sm.init = true;
    }
    let k = (dt * 10.0).min(1.0);
    sm.offset = sm.offset.lerp(target_off, k);
    sm.pivot_y += (eye - sm.pivot_y) * (dt * 12.0).min(1.0);
    let pivot = Vec3::new(ptf.translation.x, sm.pivot_y, ptf.translation.z);
    // tremida de câmera ao levar dano
    let shake = pl.hurt_flash * 0.012 * ((time.elapsed_seconds() * 53.0).sin());
    let rot = Quat::from_euler(EulerRot::YXZ, pl.yaw + shake, pl.pitch + shake * 0.7, 0.0);
    let want = pivot + rot * sm.offset;
    let d = want - pivot;
    let len = d.length();
    let mut pos = want;
    if len > 1e-3 {
        let n = d / len;
        let filter = QueryFilter::default().groups(CollisionGroups::new(WORLD_GROUP, WORLD_GROUP));
        if let Some((_, toi)) = rapier.cast_ray(pivot, n, len + 0.2, true, filter) {
            pos = pivot + n * (toi - 0.2).max(0.05);
        }
    }
    ctf.translation = pos;
    ctf.rotation = rot;
    if let Projection::Perspective(p) = &mut *proj {
        let target = if pl.ads_effective { 45f32 } else if pl.sprint { 74.0 } else { 68.0 }.to_radians();
        p.fov += (target - p.fov) * (dt * 10.0).min(1.0);
    }
}
