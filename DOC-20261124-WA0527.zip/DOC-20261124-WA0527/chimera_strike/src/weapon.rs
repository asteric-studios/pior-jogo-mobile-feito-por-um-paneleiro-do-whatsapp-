//! Arma: tiro por raycast (Rapier + hitboxes por osso), recarga sincronizada com a animação,
//! recuo, dispersão, flash do cano, traçantes, faíscas/sangue, marcas de impacto,
//! cápsulas ejetadas com física, impulso nos objetos dinâmicos e eventos para a IA.

use crate::anim::{FlashTimer, Rig};
use crate::animator::U_AIM;
use crate::controls::PlayerInput;
use crate::nav::{ray_capsule, Part};
use crate::player::{Player, PlayerAnim, PlayerCamera};
use crate::world::{Prop, SteelTarget, WORLD_GROUP};
use bevy::pbr::NotShadowCaster;
use bevy::prelude::*;
use bevy::render::render_asset::RenderAssetUsages;
use bevy::render::render_resource::{Extent3d, Face, TextureDimension, TextureFormat};
use bevy_rapier3d::prelude::*;
use std::collections::VecDeque;

pub const MAG_SIZE: u32 = 30;
pub const RELOAD_TIME: f32 = 2.3;
/// instante (s) da recarga em que o carregador novo entra (igual ao clipe `up_reload`)
pub const MAG_IN_TIME: f32 = 1.47;
const FIRE_INTERVAL: f32 = 0.08; // 750 tiros/min
pub const SHELL_GROUP: Group = Group::GROUP_3;

/// Hitboxes (cápsulas no mundo) de um personagem atingível.
#[derive(Component, Default)]
pub struct Hitboxes(pub Vec<(Vec3, Vec3, f32, Part)>);

/// Um inimigo foi atingido pelo jogador.
#[derive(Event)]
pub struct EnemyHit {
    pub enemy: Entity,
    pub part: Part,
    pub dir: Vec3,
    pub point: Vec3,
}

/// Tiro do jogador (para a IA ouvir e sentir a supressão).
#[derive(Event)]
pub struct PlayerShot {
    pub from: Vec3,
    pub to: Vec3,
}

#[derive(Resource)]
pub struct WeaponState {
    pub mag: u32,
    pub reserve: u32,
    pub reloading: Option<f32>,
    refilled: bool,
    cooldown: f32,
    pub spread_deg: f32,
    bloom: f32,
    pub ads: bool,
    pub hits: u32,
    pub shots: u32,
    pub kills: u32,
    pub hitmarker: f32,
    pub hit_enemy: bool,
    pub recoil_anim: f32,
    pub since_shot: f32,
    /// Rig do viewmodel quando em 1ª pessoa (cano/cápsula/flash saem dele).
    pub fp_rig: Option<Entity>,
    rng: u64,
}
impl Default for WeaponState {
    fn default() -> Self {
        WeaponState {
            mag: MAG_SIZE,
            reserve: 210,
            reloading: None,
            refilled: false,
            cooldown: 0.0,
            spread_deg: 1.5,
            bloom: 0.0,
            ads: false,
            hits: 0,
            shots: 0,
            fp_rig: None,
            kills: 0,
            hitmarker: 0.0,
            hit_enemy: false,
            recoil_anim: 0.0,
            since_shot: 99.0,
            rng: 0x9E37_79B9_7F4A_7C15,
        }
    }
}
impl WeaponState {
    fn rand(&mut self) -> f32 {
        xorshift(&mut self.rng)
    }
}
/// número aleatório em [-1, 1] (xorshift; evita depender de outra crate)
pub fn xorshift(s: &mut u64) -> f32 {
    let mut x = *s;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *s = x;
    ((x >> 40) as f32 / (1u64 << 24) as f32) * 2.0 - 1.0
}

#[derive(Resource)]
pub struct Fx {
    tracer_mesh: Handle<Mesh>,
    tracer_mat: Handle<StandardMaterial>,
    decal_mesh: Handle<Mesh>,
    decal_mat: Handle<StandardMaterial>,
    spark_mesh: Handle<Mesh>,
    spark_mat: Handle<StandardMaterial>,
    blood_mat: Handle<StandardMaterial>,
    shell_mesh: Handle<Mesh>,
    shell_mat: Handle<StandardMaterial>,
    flash_mesh: Handle<Mesh>,
    flash_mat: Handle<StandardMaterial>,
}

#[derive(Resource, Default)]
struct FxQueues {
    decals: VecDeque<Entity>,
    shells: VecDeque<Entity>,
}

#[derive(Component)]
struct Tracer {
    pos: Vec3,
    dir: Vec3,
    remaining: f32,
}
#[derive(Component)]
struct Spark {
    vel: Vec3,
    life: f32,
    max: f32,
}
#[derive(Component)]
struct Shell {
    life: f32,
}
#[derive(Component)]
struct MuzzleFlash {
    owner: Entity,
}
#[derive(Component)]
struct MuzzleLight {
    owner: Entity,
}

pub struct WeaponPlugin;
impl Plugin for WeaponPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<WeaponState>()
            .init_resource::<FxQueues>()
            .add_event::<EnemyHit>()
            .add_event::<PlayerShot>()
            .add_systems(Startup, setup_fx)
            .add_systems(
                Update,
                (
                    attach_muzzle_flash,
                    weapon_fire.after(crate::player::player_control).before(crate::player::player_animate),
                    update_tracers,
                    update_sparks,
                    update_shells,
                    update_flash,
                ),
            );
    }
}

fn radial_image(spikes: bool) -> Image {
    const S: usize = 64;
    let mut d = vec![0u8; S * S * 4];
    for y in 0..S {
        for x in 0..S {
            let u = (x as f32 + 0.5) / S as f32 * 2.0 - 1.0;
            let v = (y as f32 + 0.5) / S as f32 * 2.0 - 1.0;
            let r = (u * u + v * v).sqrt();
            let mut a = (1.0 - r).max(0.0).powf(1.6);
            if spikes {
                let ang = v.atan2(u);
                a = (a + (1.0 - r).max(0.0) * 0.6 * (ang * 5.0).cos().max(0.0).powf(6.0)).min(1.0);
            }
            let i = (y * S + x) * 4;
            d[i] = 255;
            d[i + 1] = 255;
            d[i + 2] = 255;
            d[i + 3] = (a * 255.0) as u8;
        }
    }
    Image::new(
        Extent3d { width: S as u32, height: S as u32, depth_or_array_layers: 1 },
        TextureDimension::D2,
        d,
        TextureFormat::Rgba8UnormSrgb,
        RenderAssetUsages::RENDER_WORLD,
    )
}

fn setup_fx(mut c: Commands, mut meshes: ResMut<Assets<Mesh>>, mut mats: ResMut<Assets<StandardMaterial>>, mut images: ResMut<Assets<Image>>) {
    let star = images.add(radial_image(true));
    let soft = images.add(radial_image(false));
    let fx = Fx {
        tracer_mesh: meshes.add(Cuboid::new(0.012, 0.012, 1.0)),
        tracer_mat: mats.add(StandardMaterial {
            base_color: Color::srgba(1.0, 0.85, 0.45, 0.9),
            unlit: true,
            alpha_mode: AlphaMode::Add,
            ..default()
        }),
        decal_mesh: meshes.add(Circle::new(0.035)),
        decal_mat: mats.add(StandardMaterial {
            base_color: Color::srgba(0.04, 0.04, 0.04, 0.9),
            base_color_texture: Some(soft.clone()),
            alpha_mode: AlphaMode::Blend,
            perceptual_roughness: 1.0,
            ..default()
        }),
        spark_mesh: meshes.add(Cuboid::new(0.012, 0.012, 0.03)),
        spark_mat: mats.add(StandardMaterial { base_color: Color::srgb(1.0, 0.7, 0.3), unlit: true, ..default() }),
        blood_mat: mats.add(StandardMaterial { base_color: Color::srgb(0.45, 0.02, 0.02), perceptual_roughness: 0.4, ..default() }),
        shell_mesh: meshes.add(Cylinder::new(0.0045, 0.022)),
        shell_mat: mats.add(StandardMaterial {
            base_color: Color::srgb(0.78, 0.6, 0.25),
            metallic: 0.9,
            perceptual_roughness: 0.3,
            ..default()
        }),
        flash_mesh: meshes.add(Rectangle::new(0.34, 0.16)),
        flash_mat: mats.add(StandardMaterial {
            base_color: Color::srgb(1.0, 0.72, 0.35),
            base_color_texture: Some(star),
            unlit: true,
            alpha_mode: AlphaMode::Add,
            double_sided: true,
            cull_mode: None::<Face>,
            ..default()
        }),
    };
    c.insert_resource(fx);
}

/// Traçante que viaja do cano até o ponto de impacto.
pub fn spawn_tracer(c: &mut Commands, fx: &Fx, from: Vec3, dir: Vec3, dist: f32) {
    c.spawn((
        PbrBundle {
            mesh: fx.tracer_mesh.clone(),
            material: fx.tracer_mat.clone(),
            transform: Transform::from_translation(from).with_rotation(Quat::from_rotation_arc(Vec3::Z, dir)),
            ..default()
        },
        NotShadowCaster,
        Tracer { pos: from, dir, remaining: dist },
    ));
}

/// Faíscas (superfícies) ou respingos de sangue (personagens).
pub fn spawn_sparks(c: &mut Commands, fx: &Fx, rng: &mut u64, point: Vec3, n: Vec3, blood: bool) {
    let count = if blood { 9 } else { 6 };
    for _ in 0..count {
        let rv = Vec3::new(xorshift(rng), xorshift(rng), xorshift(rng));
        let sp = if blood { 1.2 + xorshift(rng).abs() * 1.8 } else { 2.0 + xorshift(rng).abs() * 3.0 };
        let v = (n * 1.2 + rv * 0.8).normalize_or_zero() * sp;
        let life = if blood { 0.45 } else { 0.25 };
        c.spawn((
            PbrBundle {
                mesh: fx.spark_mesh.clone(),
                material: if blood { fx.blood_mat.clone() } else { fx.spark_mat.clone() },
                transform: Transform::from_translation(point + n * 0.01).with_scale(Vec3::splat(if blood { 1.6 } else { 1.0 })),
                ..default()
            },
            NotShadowCaster,
            Spark { vel: v, life, max: life },
        ));
    }
}

/// Cria o flash (dois planos cruzados + luz) como filho do nó "Muzzle" de cada arma.
fn attach_muzzle_flash(mut c: Commands, rigs: Query<(Entity, &Rig), Added<Rig>>, fx: Res<Fx>) {
    for (owner, rig) in rigs.iter() {
        c.entity(rig.muzzle).with_children(|p| {
            let half_pi = std::f32::consts::FRAC_PI_2;
            for rot in [Quat::from_rotation_y(half_pi), Quat::from_rotation_y(half_pi) * Quat::from_rotation_x(half_pi)] {
                p.spawn((
                    PbrBundle {
                        mesh: fx.flash_mesh.clone(),
                        material: fx.flash_mat.clone(),
                        transform: Transform::from_xyz(0.0, 0.0, 0.15).with_rotation(rot),
                        visibility: Visibility::Hidden,
                        ..default()
                    },
                    NotShadowCaster,
                    MuzzleFlash { owner },
                ));
            }
            p.spawn((
                PointLightBundle {
                    point_light: PointLight {
                        color: Color::srgb(1.0, 0.7, 0.35),
                        intensity: 0.0,
                        range: 7.0,
                        shadows_enabled: false,
                        ..default()
                    },
                    transform: Transform::from_xyz(0.0, 0.0, 0.1),
                    ..default()
                },
                MuzzleLight { owner },
            ));
        });
    }
}

/// Primeiro acerto em hitboxes de inimigos ao longo de um raio.
pub fn ray_enemies(o: Vec3, d: Vec3, max: f32, enemies: &Query<(Entity, &Hitboxes)>) -> Option<(f32, Entity, Part)> {
    let mut best: Option<(f32, Entity, Part)> = None;
    for (e, hb) in enemies.iter() {
        for (a, b, r, part) in hb.0.iter() {
            if let Some(t) = ray_capsule(o, d, *a, *b, *r) {
                if t <= max && best.map(|x| t < x.0).unwrap_or(true) {
                    best = Some((t, e, *part));
                }
            }
        }
    }
    best
}

#[allow(clippy::too_many_arguments, clippy::type_complexity)]
fn weapon_fire(
    mut c: Commands,
    time: Res<Time>,
    inp: Res<PlayerInput>,
    mut ws: ResMut<WeaponState>,
    mut players: Query<(&Transform, &mut Player, &PlayerAnim)>,
    cams: Query<&GlobalTransform, With<PlayerCamera>>,
    mut rigs: Query<(&Rig, &mut FlashTimer)>,
    gts: Query<&GlobalTransform>,
    rapier: Res<RapierContext>,
    fx: Res<Fx>,
    mut queues: ResMut<FxQueues>,
    mut props: Query<(&mut ExternalImpulse, &GlobalTransform), With<Prop>>,
    mut steel: Query<&mut SteelTarget>,
    enemies: Query<(Entity, &Hitboxes)>,
    mut hits: EventWriter<EnemyHit>,
    mut shots: EventWriter<PlayerShot>,
) {
    let dt = time.delta_seconds();
    let Ok((ptf, mut pl, an)) = players.get_single_mut() else { return };
    ws.cooldown -= dt;
    ws.hitmarker = (ws.hitmarker - dt).max(0.0);
    ws.recoil_anim *= (-dt * 14.0).exp();
    ws.since_shot += dt;
    ws.bloom *= (-dt * 5.0).exp();
    ws.ads = pl.ads_effective;

    let hspeed = Vec2::new(pl.vel.x, pl.vel.z).length();
    let mut base = if pl.ads_effective { 0.25 } else { 1.6 };
    base += (hspeed / 4.0).min(1.0) * if pl.ads_effective { 0.4 } else { 1.4 };
    if pl.crouch {
        base *= 0.7;
    }
    if !pl.grounded {
        base += 3.0;
    }
    ws.spread_deg = base + ws.bloom;

    // ---- recarga (tempo igual ao da animação)
    if pl.dead {
        ws.reloading = None;
        ws.mag = MAG_SIZE;
        return;
    }
    if let Some(t) = ws.reloading {
        let t = t + dt;
        if t >= MAG_IN_TIME && !ws.refilled {
            let need = MAG_SIZE - ws.mag;
            let take = need.min(ws.reserve);
            ws.mag += take;
            ws.reserve -= take;
            ws.refilled = true;
        }
        ws.reloading = if t >= RELOAD_TIME { None } else { Some(t) };
    } else if (inp.reload || (inp.fire && ws.mag == 0)) && ws.mag < MAG_SIZE && ws.reserve > 0 {
        ws.reloading = Some(0.0);
        ws.refilled = false;
        pl.sprint = false;
    }
    if ws.reserve == 0 && ws.mag == 0 {
        ws.reserve = 210; // estande de teste: munição infinita
    }

    // ---- disparo
    let can_fire = inp.fire && ws.reloading.is_none() && ws.mag > 0 && ws.cooldown <= 0.0 && !pl.sprint && an.0.uw[U_AIM] > 0.55;
    if !can_fire {
        if ws.cooldown < 0.0 {
            ws.cooldown = 0.0;
        }
        return;
    }
    let Ok(cam) = cams.get_single() else { return };
    let fp = ws.fp_rig.filter(|e| rigs.get(*e).is_ok());
    let Ok((rig, mut flash)) = rigs.get_mut(fp.unwrap_or(pl.model)) else { return };
    let (Ok(muzzle_gt), Ok(weapon_gt)) = (gts.get(rig.muzzle), gts.get(rig.weapon)) else { return };
    ws.cooldown += FIRE_INTERVAL;
    ws.mag -= 1;
    ws.shots += 1;
    ws.since_shot = 0.0;
    ws.recoil_anim = 1.0;
    flash.0 = 0.05;

    let filter = QueryFilter::default().groups(CollisionGroups::new(WORLD_GROUP, WORLD_GROUP));
    // raio da câmera pela mira (com dispersão)
    let fwd = *cam.forward();
    let spread = ws.spread_deg.to_radians() * 0.5;
    let (ry, rp) = (ws.rand(), ws.rand());
    let dir = (fwd + *cam.right() * (ry * spread) + *cam.up() * (rp * spread)).normalize();
    let cam_pos = cam.translation();
    let skip = (ptf.translation - cam_pos).dot(dir).max(0.0);
    let origin = cam_pos + dir * skip;
    let mut aim_t = rapier.cast_ray(origin, dir, 300.0, true, filter).map(|(_, t)| t).unwrap_or(300.0);
    if let Some((t, _, _)) = ray_enemies(origin, dir, aim_t, &enemies) {
        aim_t = t;
    }
    let aim_point = origin + dir * aim_t;
    // raio real saindo do cano até o ponto mirado
    // em 1ª pessoa o raio sai do olho (o cano do viewmodel pode estar "dentro" de uma parede
    // colada na câmera); o traçante continua saindo do cano visível
    let vis_muzzle = muzzle_gt.translation();
    let muzzle = if fp.is_some() { origin } else { vis_muzzle };
    let to = aim_point - muzzle;
    let dist = to.length().max(0.05);
    let mdir = to / dist;
    let world_hit = rapier.cast_ray_and_get_normal(muzzle, mdir, dist + 0.05, true, filter);
    let world_t = world_hit.map(|(_, h)| h.time_of_impact).unwrap_or(dist + 0.05);
    let enemy_hit = ray_enemies(muzzle, mdir, world_t, &enemies);
    let end_t = enemy_hit.map(|(t, _, _)| t).unwrap_or(world_t.min(dist));
    let end_p = muzzle + mdir * end_t;
    let tr = end_p - vis_muzzle;
    let tr_len = tr.length();
    if tr_len > 0.3 {
        spawn_tracer(&mut c, &fx, vis_muzzle, tr / tr_len, tr_len);
    }
    shots.send(PlayerShot { from: muzzle, to: muzzle + mdir * end_t.max(40.0) });

    if let Some((t, e, part)) = enemy_hit {
        let p = muzzle + mdir * t;
        hits.send(EnemyHit { enemy: e, part, dir: mdir, point: p });
        spawn_sparks(&mut c, &fx, &mut ws.rng, p, -mdir, true);
        ws.hitmarker = 0.2;
        ws.hit_enemy = true;
    } else if let Some((e, h)) = world_hit {
        let n = if h.normal.length_squared() > 0.5 { h.normal.normalize() } else { -mdir };
        let world = Transform::from_translation(h.point + n * 0.004).with_rotation(Quat::from_rotation_arc(Vec3::Z, n));
        let mut decal_tf = world;
        let mut parent = None;
        if let Ok((mut imp, gt)) = props.get_mut(e) {
            let j = mdir * 3.5;
            imp.impulse += j;
            imp.torque_impulse += (h.point - gt.translation()).cross(j);
            decal_tf = Transform::from_matrix(gt.compute_matrix().inverse() * world.compute_matrix());
            parent = Some(e);
        }
        if let Ok(mut s) = steel.get_mut(e) {
            s.flash = 1.0;
            ws.hits += 1;
            ws.hitmarker = 0.18;
            ws.hit_enemy = false;
        }
        let d = c
            .spawn((
                PbrBundle { mesh: fx.decal_mesh.clone(), material: fx.decal_mat.clone(), transform: decal_tf, ..default() },
                NotShadowCaster,
            ))
            .id();
        if let Some(p) = parent {
            c.entity(d).set_parent(p);
        }
        queues.decals.push_back(d);
        while queues.decals.len() > 80 {
            if let Some(old) = queues.decals.pop_front() {
                if let Some(ec) = c.get_entity(old) {
                    ec.despawn_recursive();
                }
            }
        }
        spawn_sparks(&mut c, &fx, &mut ws.rng, h.point, n, false);
    }

    // cápsula ejetada pela janela do lado direito (−X no espaço da arma)
    let port = weapon_gt.transform_point(Vec3::new(-0.03, 0.0, -0.01));
    let wr = weapon_gt.affine().transform_vector3(Vec3::NEG_X).normalize_or_zero();
    let wu = weapon_gt.affine().transform_vector3(Vec3::Y).normalize_or_zero();
    let wf = weapon_gt.affine().transform_vector3(Vec3::Z).normalize_or_zero();
    let lin = pl.vel + wr * (2.4 + ws.rand() * 0.4) + wu * (1.4 + ws.rand() * 0.3) - wf * 0.4;
    let s = c
        .spawn((
            PbrBundle {
                mesh: fx.shell_mesh.clone(),
                material: fx.shell_mat.clone(),
                transform: Transform::from_translation(port).with_rotation(Quat::from_rotation_arc(Vec3::Y, wr)),
                ..default()
            },
            RigidBody::Dynamic,
            Collider::cylinder(0.011, 0.0045),
            ColliderMassProperties::Mass(0.012),
            Restitution::coefficient(0.35),
            Velocity { linvel: lin, angvel: Vec3::new(ws.rand() * 20.0, ws.rand() * 20.0, 15.0) },
            CollisionGroups::new(SHELL_GROUP, WORLD_GROUP),
            NotShadowCaster,
            Shell { life: 3.0 },
        ))
        .id();
    queues.shells.push_back(s);
    while queues.shells.len() > 30 {
        if let Some(old) = queues.shells.pop_front() {
            if let Some(ec) = c.get_entity(old) {
                ec.despawn_recursive();
            }
        }
    }

    // recuo da câmera (parte é recuperada depois) + abertura da mira
    let kick = if pl.ads_effective { 0.45f32 } else { 0.7 }.to_radians();
    pl.pitch += kick;
    pl.yaw += ws.rand() * 0.12f32.to_radians();
    pl.recoil_pending += kick * 0.6;
    ws.bloom = (ws.bloom + if pl.ads_effective { 0.12 } else { 0.4 }).min(4.0);
}

fn update_tracers(mut c: Commands, time: Res<Time>, mut q: Query<(Entity, &mut Tracer, &mut Transform)>) {
    let dt = time.delta_seconds();
    for (e, mut t, mut tf) in q.iter_mut() {
        let step = 420.0 * dt;
        let seg = 2.2f32.min(t.remaining);
        tf.translation = t.pos + t.dir * (seg * 0.5);
        tf.scale = Vec3::new(1.0, 1.0, seg.max(0.01));
        let (dir, pos) = (t.dir, t.pos);
        t.pos = pos + dir * step;
        t.remaining -= step;
        if t.remaining <= 0.0 {
            c.entity(e).despawn_recursive();
        }
    }
}

fn update_sparks(mut c: Commands, time: Res<Time>, mut q: Query<(Entity, &mut Spark, &mut Transform)>) {
    let dt = time.delta_seconds();
    for (e, mut s, mut tf) in q.iter_mut() {
        s.vel.y -= 9.8 * dt;
        tf.translation += s.vel * dt;
        if s.vel.length_squared() > 1e-4 {
            tf.rotation = Quat::from_rotation_arc(Vec3::Z, s.vel.normalize());
        }
        s.life -= dt;
        let k = (s.life / s.max).clamp(0.05, 1.0);
        tf.scale = Vec3::splat(k);
        if s.life <= 0.0 {
            c.entity(e).despawn_recursive();
        }
    }
}

fn update_shells(mut c: Commands, time: Res<Time>, mut q: Query<(Entity, &mut Shell)>, mut queues: ResMut<FxQueues>) {
    for (e, mut s) in q.iter_mut() {
        s.life -= time.delta_seconds();
        if s.life <= 0.0 {
            queues.shells.retain(|x| *x != e);
            c.entity(e).despawn_recursive();
        }
    }
}

fn update_flash(
    time: Res<Time>,
    mut timers: Query<&mut FlashTimer>,
    mut flashes: Query<(&MuzzleFlash, &mut Visibility, &mut Transform)>,
    mut lights: Query<(&MuzzleLight, &mut PointLight)>,
    mut rng: Local<u64>,
) {
    if *rng == 0 {
        *rng = 0x2545_F491_4F6C_DD1D;
    }
    let roll = xorshift(&mut rng) * 3.14;
    let sc = 0.8 + 0.4 * xorshift(&mut rng).abs();
    for (f, mut v, mut tf) in flashes.iter_mut() {
        let on = timers.get(f.owner).map(|t| t.0 > 0.0).unwrap_or(false);
        *v = if on { Visibility::Inherited } else { Visibility::Hidden };
        if on {
            tf.scale = Vec3::new(sc, 1.0, 1.0);
            let base = tf.rotation;
            tf.rotation = Quat::from_rotation_z(roll * 0.05) * base;
        }
    }
    for (l, mut pl) in lights.iter_mut() {
        let on = timers.get(l.owner).map(|t| t.0 > 0.0).unwrap_or(false);
        pl.intensity = if on { 60_000.0 } else { 0.0 };
    }
    let dt = time.delta_seconds();
    for mut t in timers.iter_mut() {
        t.0 = (t.0 - dt).max(0.0);
    }
}
