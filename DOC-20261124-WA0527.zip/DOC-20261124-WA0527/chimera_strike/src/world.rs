//! Mapa de teste: piso e paredes com textura de grade (estilo "dev map" do CoD),
//! coberturas, rampa/contêiner, escada, estande de tiro com alvos de aço e
//! objetos dinâmicos (caixas e barris) simulados pelo Rapier.

use bevy::pbr::{CascadeShadowConfigBuilder, DirectionalLightShadowMap, NotShadowCaster};
use bevy::prelude::*;
use bevy::render::mesh::{Indices, PrimitiveTopology};
use bevy::render::render_asset::RenderAssetUsages;
use bevy::render::render_resource::{Extent3d, TextureDimension, TextureFormat};
use bevy::render::texture::{ImageAddressMode, ImageFilterMode, ImageSampler, ImageSamplerDescriptor};
use bevy_rapier3d::prelude::*;

pub struct WorldPlugin;
impl Plugin for WorldPlugin {
    fn build(&self, app: &mut App) {
        app.insert_resource(DirectionalLightShadowMap { size: 2048 })
            .add_systems(Startup, setup_world)
            .add_systems(Update, steel_target_flash);
    }
}

/// Grupo de colisão do cenário (o jogador e as cápsulas colidem com ele).
pub const WORLD_GROUP: Group = Group::GROUP_1;

/// Alvo de aço reativo: pisca quando atingido.
#[derive(Component)]
pub struct SteelTarget {
    pub flash: f32,
    pub material: Handle<StandardMaterial>,
}

/// Objeto físico que pode ser empurrado por tiros.
#[derive(Component)]
pub struct Prop;

/// Tamanho, em metros, coberto por uma repetição da textura de grade.
const TILE_M: f32 = 4.0;

fn grid_image(base: [u8; 3], minor: [u8; 3], major: [u8; 3]) -> Image {
    const S: usize = 256;
    let px_per_m = S as f32 / TILE_M;
    let mut lvl0 = vec![0u8; S * S * 4];
    for y in 0..S {
        for x in 0..S {
            let fx = x as f32 / px_per_m;
            let fy = y as f32 / px_per_m;
            let dmx = (fx - fx.round()).abs() * px_per_m;
            let dmy = (fy - fy.round()).abs() * px_per_m;
            let edge = x < 3 || y < 3 || x >= S - 3 || y >= S - 3;
            // leve variação para não ficar "chapado"
            let n = (((x * 7 + y * 13) ^ (x * y)) % 17) as i32 - 8;
            let mut c = if edge {
                major
            } else if dmx < 1.0 || dmy < 1.0 {
                minor
            } else {
                base
            };
            if !edge {
                for ch in c.iter_mut() {
                    *ch = (*ch as i32 + n / 3).clamp(0, 255) as u8;
                }
            }
            let i = (y * S + x) * 4;
            lvl0[i..i + 3].copy_from_slice(&c);
            lvl0[i + 3] = 255;
        }
    }
    let mut img = Image::new(
        Extent3d { width: S as u32, height: S as u32, depth_or_array_layers: 1 },
        TextureDimension::D2,
        lvl0.clone(),
        TextureFormat::Rgba8UnormSrgb,
        RenderAssetUsages::RENDER_WORLD,
    );
    // cadeia de mipmaps (evita cintilação do piso à distância no celular)
    let mut levels = 1u32;
    let mut prev = lvl0;
    let mut size = S;
    while size > 1 {
        let ns = size / 2;
        let mut next = vec![0u8; ns * ns * 4];
        for y in 0..ns {
            for x in 0..ns {
                for c in 0..4 {
                    let s = |xx: usize, yy: usize| prev[((yy * size) + xx) * 4 + c] as u32;
                    let v = s(2 * x, 2 * y) + s(2 * x + 1, 2 * y) + s(2 * x, 2 * y + 1) + s(2 * x + 1, 2 * y + 1);
                    next[(y * ns + x) * 4 + c] = (v / 4) as u8;
                }
            }
        }
        img.data.extend_from_slice(&next);
        prev = next;
        size = ns;
        levels += 1;
    }
    img.texture_descriptor.mip_level_count = levels;
    img.sampler = ImageSampler::Descriptor(ImageSamplerDescriptor {
        address_mode_u: ImageAddressMode::Repeat,
        address_mode_v: ImageAddressMode::Repeat,
        mag_filter: ImageFilterMode::Linear,
        min_filter: ImageFilterMode::Linear,
        mipmap_filter: ImageFilterMode::Linear,
        anisotropy_clamp: 8,
        ..default()
    });
    img
}

/// Caixa com UVs em escala de mundo (a grade fica com 1 m em qualquer face).
pub fn box_mesh(size: Vec3) -> Mesh {
    let h = size * 0.5;
    // (normal, eixo u, eixo v)
    let faces = [
        (Vec3::X, Vec3::NEG_Z, Vec3::Y),
        (Vec3::NEG_X, Vec3::Z, Vec3::Y),
        (Vec3::Y, Vec3::X, Vec3::NEG_Z),
        (Vec3::NEG_Y, Vec3::X, Vec3::Z),
        (Vec3::Z, Vec3::X, Vec3::Y),
        (Vec3::NEG_Z, Vec3::NEG_X, Vec3::Y),
    ];
    let mut pos = Vec::new();
    let mut nrm = Vec::new();
    let mut uv = Vec::new();
    let mut idx: Vec<u32> = Vec::new();
    for (n, u, v) in faces {
        let base = pos.len() as u32;
        let su = (u * size).length();
        let sv = (v * size).length();
        for (a, b) in [(-1.0f32, -1.0f32), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)] {
            let p = n * h + u * (a * su * 0.5) + v * (b * sv * 0.5);
            pos.push([p.x, p.y, p.z]);
            nrm.push([n.x, n.y, n.z]);
            uv.push([(a * 0.5 + 0.5) * su / TILE_M, (0.5 - b * 0.5) * sv / TILE_M]);
        }
        idx.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
    }
    Mesh::new(PrimitiveTopology::TriangleList, RenderAssetUsages::RENDER_WORLD)
        .with_inserted_attribute(Mesh::ATTRIBUTE_POSITION, pos)
        .with_inserted_attribute(Mesh::ATTRIBUTE_NORMAL, nrm)
        .with_inserted_attribute(Mesh::ATTRIBUTE_UV_0, uv)
        .with_inserted_indices(Indices::U32(idx))
}

struct Mats {
    floor: Handle<StandardMaterial>,
    wall: Handle<StandardMaterial>,
    orange: Handle<StandardMaterial>,
    dark: Handle<StandardMaterial>,
    crate_m: Handle<StandardMaterial>,
}

fn spawn_block(
    c: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mat: &Handle<StandardMaterial>,
    pos: Vec3,
    size: Vec3,
    rot: Quat,
) -> Entity {
    c.spawn((
        PbrBundle {
            mesh: meshes.add(box_mesh(size)),
            material: mat.clone(),
            transform: Transform::from_translation(pos).with_rotation(rot),
            ..default()
        },
        RigidBody::Fixed,
        Collider::cuboid(size.x * 0.5, size.y * 0.5, size.z * 0.5),
        CollisionGroups::new(WORLD_GROUP, Group::ALL),
        Friction::coefficient(0.8),
    ))
    .id()
}

fn setup_world(
    mut c: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
    mut images: ResMut<Assets<Image>>,
) {
    let tex_gray = images.add(grid_image([118, 122, 126], [92, 96, 100], [60, 64, 68]));
    let tex_orange = images.add(grid_image([196, 112, 46], [160, 88, 34], [110, 60, 24]));
    let tex_light = images.add(grid_image([170, 172, 168], [140, 142, 140], [100, 102, 100]));
    let mk = |mats: &mut Assets<StandardMaterial>, t: &Handle<Image>, tint: Color, rough: f32| {
        mats.add(StandardMaterial {
            base_color: tint,
            base_color_texture: Some(t.clone()),
            perceptual_roughness: rough,
            metallic: 0.0,
            ..default()
        })
    };
    let m = Mats {
        floor: mk(&mut *mats, &tex_gray, Color::WHITE, 0.9),
        wall: mk(&mut *mats, &tex_light, Color::WHITE, 0.85),
        orange: mk(&mut *mats, &tex_orange, Color::WHITE, 0.8),
        dark: mk(&mut *mats, &tex_gray, Color::srgb(0.55, 0.57, 0.6), 0.7),
        crate_m: mk(&mut *mats, &tex_orange, Color::srgb(0.75, 0.62, 0.45), 0.85),
    };

    // ---- sol (só camada 0 = mundo, com sombras)
    let sun_tf = Transform::from_xyz(20.0, 40.0, 14.0).looking_at(Vec3::ZERO, Vec3::Y);
    c.spawn(DirectionalLightBundle {
        directional_light: DirectionalLight {
            illuminance: 9_000.0,
            shadows_enabled: true,
            ..default()
        },
        transform: sun_tf,
        cascade_shadow_config: CascadeShadowConfigBuilder {
            num_cascades: 2,
            first_cascade_far_bound: 10.0,
            maximum_distance: 45.0,
            ..default()
        }
        .into(),
        ..default()
    });
    // mesma luz para o viewmodel (camada 1) sem sombras: a câmera da arma não gera mapas de sombra extras
    c.spawn((
        DirectionalLightBundle {
            directional_light: DirectionalLight { illuminance: 9_000.0, shadows_enabled: false, ..default() },
            transform: sun_tf,
            ..default()
        },
        bevy::render::view::RenderLayers::layer(crate::viewmodel::VM_LAYER),
    ));

    // ---- piso, paredes, coberturas, contêiner, rampa, plataforma e escada (layout em map.rs)
    for bl in crate::map::blocks() {
        let mat = match bl.mat {
            crate::map::Mat::Floor => &m.floor,
            crate::map::Mat::Wall => &m.wall,
            crate::map::Mat::Orange => &m.orange,
            crate::map::Mat::Dark => &m.dark,
            crate::map::Mat::Crate => &m.crate_m,
        };
        spawn_block(&mut c, &mut meshes, mat, bl.pos, bl.size, Quat::from_rotation_z(bl.rot_z));
    }

    // ---- estande de tiro: faixa de chão laranja + alvos de aço a 10/20/30/45 m
    let lane = mats.add(StandardMaterial {
        base_color: Color::srgb(0.9, 0.55, 0.25),
        base_color_texture: Some(tex_orange.clone()),
        perceptual_roughness: 0.9,
        ..default()
    });
    c.spawn((
        PbrBundle {
            mesh: meshes.add(box_mesh(Vec3::new(6.0, 0.02, 40.0))),
            material: lane,
            transform: Transform::from_xyz(0.0, 0.011, -18.0),
            ..default()
        },
        NotShadowCaster,
    ));
    let post_mat = mats.add(StandardMaterial { base_color: Color::srgb(0.2, 0.2, 0.22), perceptual_roughness: 0.6, metallic: 0.6, ..default() });
    for (i, d) in [10.0f32, 18.0, 33.0, 45.0].iter().enumerate() {
        for k in [-1.5f32, 1.5] {
            let x = k + if i % 2 == 0 { 0.0 } else { 0.4 };
            let z = 8.0 - d;
            c.spawn((
                PbrBundle {
                    mesh: meshes.add(Cuboid::new(0.08, 1.2, 0.08)),
                    material: post_mat.clone(),
                    transform: Transform::from_xyz(x, 0.6, z),
                    ..default()
                },
                RigidBody::Fixed,
                Collider::cuboid(0.04, 0.6, 0.04),
                CollisionGroups::new(WORLD_GROUP, Group::ALL),
            ));
            let tm = mats.add(StandardMaterial {
                base_color: Color::srgb(0.85, 0.85, 0.8),
                perceptual_roughness: 0.35,
                metallic: 0.8,
                ..default()
            });
            c.spawn((
                PbrBundle {
                    mesh: meshes.add(Cuboid::new(0.5, 0.65, 0.03)),
                    material: tm.clone(),
                    transform: Transform::from_xyz(x, 1.45, z),
                    ..default()
                },
                RigidBody::Fixed,
                Collider::cuboid(0.25, 0.325, 0.015),
                CollisionGroups::new(WORLD_GROUP, Group::ALL),
                SteelTarget { flash: 0.0, material: tm },
            ));
        }
    }

    // ---- objetos dinâmicos (física Rapier): pilha de caixas e barris
    let box_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(0.62, 0.48, 0.3),
        base_color_texture: Some(tex_orange.clone()),
        perceptual_roughness: 0.9,
        ..default()
    });
    let bsz = 0.5f32;
    let box_m = meshes.add(box_mesh(Vec3::splat(bsz)));
    for layer in 0..3 {
        for i in 0..(3 - layer) {
            let x = 5.0 + (i as f32 - (2 - layer) as f32 * 0.5) * (bsz + 0.02);
            let y = bsz * 0.5 + layer as f32 * bsz + 0.01;
            spawn_prop(&mut c, box_m.clone(), box_mat.clone(), Vec3::new(x, y, 4.5), Collider::cuboid(bsz * 0.5, bsz * 0.5, bsz * 0.5), 6.0);
        }
    }
    let barrel_mesh = meshes.add(Cylinder::new(0.3, 0.9));
    let barrel_mats = [
        mats.add(StandardMaterial { base_color: Color::srgb(0.12, 0.32, 0.6), perceptual_roughness: 0.45, metallic: 0.5, ..default() }),
        mats.add(StandardMaterial { base_color: Color::srgb(0.65, 0.12, 0.1), perceptual_roughness: 0.45, metallic: 0.5, ..default() }),
    ];
    for (i, p) in [Vec3::new(-6.0, 0.46, -3.0), Vec3::new(-6.7, 0.46, -3.3), Vec3::new(-6.3, 0.46, -2.4), Vec3::new(6.5, 0.46, -9.0), Vec3::new(7.2, 0.46, -9.3)]
        .iter()
        .enumerate()
    {
        spawn_prop(&mut c, barrel_mesh.clone(), barrel_mats[i % 2].clone(), *p, Collider::cylinder(0.45, 0.3), 14.0);
    }
}

fn spawn_prop(c: &mut Commands, mesh: Handle<Mesh>, mat: Handle<StandardMaterial>, pos: Vec3, col: Collider, mass: f32) {
    c.spawn((
        PbrBundle { mesh, material: mat, transform: Transform::from_translation(pos), ..default() },
        RigidBody::Dynamic,
        col,
        ColliderMassProperties::Mass(mass),
        Friction::coefficient(0.7),
        Restitution::coefficient(0.15),
        Damping { linear_damping: 0.2, angular_damping: 0.4 },
        ExternalImpulse::default(),
        CollisionGroups::new(WORLD_GROUP, Group::ALL),
        Prop,
    ));
}

fn steel_target_flash(time: Res<Time>, mut q: Query<&mut SteelTarget>, mut mats: ResMut<Assets<StandardMaterial>>) {
    for mut t in q.iter_mut() {
        if t.flash > 0.0 {
            t.flash = (t.flash - time.delta_seconds() * 4.0).max(0.0);
            if let Some(m) = mats.get_mut(&t.material) {
                let f = t.flash;
                m.emissive = LinearRgba::rgb(4.0 * f, 0.9 * f, 0.2 * f);
            }
        }
    }
}
