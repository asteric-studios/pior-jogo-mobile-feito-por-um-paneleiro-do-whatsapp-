//! Primeira pessoa estilo CoD: viewmodel próprio (braços + arma) desenhado por uma segunda
//! câmera com FOV fixo na camada de render 1 (nunca atravessa paredes), animação procedural
//! (ViewmodelAnim), luneta "fantasma" no ADS (corpo semitransparente + retículo no HUD) e corpo
//! do personagem visível ao olhar para baixo (cabeça e braços do modelo de 3ª pessoa recolhidos).

use crate::anim::{Anim, CurrentPose, FpHide, SoldierModel};
use crate::animator::{ViewmodelAnim, VmInput};
use crate::controls::PlayerInput;
use crate::player::{Player, PlayerCamera};
use crate::weapon::WeaponState;
use bevy::color::Alpha;
use bevy::core_pipeline::fxaa::Fxaa;
use bevy::hierarchy::HierarchyQueryExt;
use bevy::pbr::NotShadowCaster;
use bevy::prelude::*;
use bevy::render::camera::ClearColorConfig;
use bevy::render::view::{NoFrustumCulling, RenderLayers};
use bevy::ui::IsDefaultUiCamera;
use std::f32::consts::PI;

pub const VM_LAYER: usize = 1;

/// Modo de câmera e estado do viewmodel (lido pelo HUD/arma/câmera).
#[derive(Resource, Default)]
pub struct ViewMode {
    pub first: bool,
    pub ads_e: f32,
    pub model: Option<Entity>,
    cams: Option<(Entity, Entity)>,
    ui_on_vm: bool,
}

#[derive(Component)]
pub struct ViewmodelCam;
#[derive(Component)]
pub struct ViewmodelModel;
#[derive(Component, Default)]
pub struct VmAnim(pub ViewmodelAnim);
/// Materiais da luneta (clonados) para o efeito fantasma.
#[derive(Component, Default)]
struct ScopeFade {
    mats: Vec<Handle<StandardMaterial>>,
    ready: bool,
}

pub struct ViewmodelPlugin;
impl Plugin for ViewmodelPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<ViewMode>().add_systems(
            Update,
            (
                setup_viewmodel,
                vm_layers,
                vm_scope_setup,
                vm_update.after(crate::player::player_animate),
            ),
        );
    }
}

fn setup_viewmodel(
    mut c: Commands,
    assets: Res<AssetServer>,
    mut vm: ResMut<ViewMode>,
    cams: Query<Entity, With<PlayerCamera>>,
) {
    if vm.model.is_some() {
        return;
    }
    let Ok(cam) = cams.get_single() else { return };
    let model = c
        .spawn((
            SceneBundle {
                scene: assets.load("viewmodel.glb#Scene0"),
                visibility: Visibility::Hidden,
                ..default()
            },
            SoldierModel,
            CurrentPose::default(),
            ViewmodelModel,
            VmAnim::default(),
            ScopeFade::default(),
            RenderLayers::layer(VM_LAYER),
        ))
        .id();
    let vcam = c
        .spawn((
            Camera3dBundle {
                camera: Camera {
                    order: 1,
                    is_active: false,
                    clear_color: ClearColorConfig::None,
                    ..default()
                },
                projection: Projection::Perspective(PerspectiveProjection {
                    fov: 54f32.to_radians(),
                    near: 0.01,
                    far: 20.0,
                    ..default()
                }),
                ..default()
            },
            RenderLayers::layer(VM_LAYER),
            ViewmodelCam,
            Fxaa { enabled: false, ..default() },
        ))
        .id();
    // o HUD é desenhado pela última câmera ativa (por cima do viewmodel em 1ª pessoa)
    c.entity(cam).add_child(vcam).add_child(model).insert(IsDefaultUiCamera);
    vm.model = Some(model);
    vm.cams = Some((cam, vcam));
    vm.ui_on_vm = false;
}

/// Coloca todas as malhas do viewmodel na camada 1 (sem sombra). A luz do cano ilumina as duas camadas.
#[allow(clippy::type_complexity)]
fn vm_layers(
    mut c: Commands,
    roots: Query<Entity, With<ViewmodelModel>>,
    children: Query<&Children>,
    no_layer: Query<(), Without<RenderLayers>>,
    lights: Query<(), With<PointLight>>,
) {
    for root in roots.iter() {
        for e in children.iter_descendants(root) {
            if no_layer.get(e).is_ok() {
                if lights.get(e).is_ok() {
                    c.entity(e).insert(RenderLayers::from_layers(&[0, VM_LAYER]));
                } else {
                    // a AABB do skinned mesh é a da pose de bind: sem culling para não piscar
                    c.entity(e).insert((RenderLayers::layer(VM_LAYER), NotShadowCaster, NoFrustumCulling));
                }
            }
        }
    }
}

/// Clona os materiais da luneta do viewmodel para poder deixá-la semitransparente no ADS.
fn vm_scope_setup(
    mut roots: Query<(Entity, &mut ScopeFade), With<ViewmodelModel>>,
    children: Query<&Children>,
    names: Query<&Name>,
    mut handles: Query<&mut Handle<StandardMaterial>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
) {
    for (root, mut sf) in roots.iter_mut() {
        if sf.ready {
            continue;
        }
        let scope = children.iter_descendants(root).find(|e| names.get(*e).map(|n| n.as_str() == "Scope").unwrap_or(false));
        let Some(scope) = scope else { continue };
        let mut found = false;
        let list: Vec<Entity> = std::iter::once(scope).chain(children.iter_descendants(scope)).collect();
        for e in list {
            if let Ok(mut h) = handles.get_mut(e) {
                if let Some(m) = mats.get(&*h) {
                    let mut m2 = m.clone();
                    m2.alpha_mode = AlphaMode::Opaque;
                    let nh = mats.add(m2);
                    *h = nh.clone();
                    sf.mats.push(nh);
                    found = true;
                }
            }
        }
        sf.ready = found;
    }
}

#[allow(clippy::too_many_arguments, clippy::type_complexity)]
fn vm_update(
    time: Res<Time>,
    anim: Res<Anim>,
    inp: Res<PlayerInput>,
    mut ws: ResMut<WeaponState>,
    mut vm: ResMut<ViewMode>,
    mut c: Commands,
    players: Query<(&Player, &Transform), Without<ViewmodelModel>>,
    mut models: Query<(&mut Transform, &mut CurrentPose, &mut VmAnim, &mut Visibility, &ScopeFade), With<ViewmodelModel>>,
    mut cams: Query<(&mut Camera, &mut Fxaa), With<ViewmodelCam>>,
    mut main_fxaa: Query<&mut Fxaa, (With<PlayerCamera>, Without<ViewmodelCam>)>,
    mut mats: ResMut<Assets<StandardMaterial>>,
    mut prev: Local<(f32, f32, u32, bool, f32)>,
) {
    let dt = time.delta_seconds().min(0.05);
    if inp.view_toggle {
        vm.first = !vm.first;
    }
    let Ok((pl, ptf)) = players.get_single() else { return };
    let first = vm.first && !pl.dead;
    // corpo de 3ª pessoa: esconde cabeça/braços/arma em 1ª pessoa
    if first {
        c.entity(pl.model).insert(FpHide);
    } else {
        c.entity(pl.model).remove::<FpHide>();
    }
    if let Some((main, vcam)) = vm.cams {
        if vm.ui_on_vm != first {
            if first {
                c.entity(main).remove::<IsDefaultUiCamera>();
                c.entity(vcam).insert(IsDefaultUiCamera);
            } else {
                c.entity(vcam).remove::<IsDefaultUiCamera>();
                c.entity(main).insert(IsDefaultUiCamera);
            }
            vm.ui_on_vm = first;
        }
    }
    let android = cfg!(target_os = "android");
    if let Ok((mut cam, mut fx)) = cams.get_single_mut() {
        cam.is_active = first;
        fx.enabled = first && android;
    }
    if let Ok(mut fx) = main_fxaa.get_single_mut() {
        fx.enabled = !first && android;
    }
    let Some(model) = vm.model else { return };
    let Ok((mut tf, mut cur, mut va, mut vis, sf)) = models.get_mut(model) else { return };
    *vis = if first { Visibility::Inherited } else { Visibility::Hidden };

    let mut dyaw = pl.yaw - prev.0;
    if dyaw > PI {
        dyaw -= 2.0 * PI;
    } else if dyaw < -PI {
        dyaw += 2.0 * PI;
    }
    let dpitch = pl.pitch - prev.1;
    let shot = ws.shots != prev.2;
    let landed = if pl.grounded && !prev.3 { prev.4.max(0.0) } else { 0.0 };
    *prev = (pl.yaw, pl.pitch, ws.shots, pl.grounded, -pl.vel.y);
    ws.fp_rig = if first { Some(model) } else { None };
    if !first {
        vm.ads_e = 0.0;
        va.0 = ViewmodelAnim::default();
        return;
    }
    let fwd = ptf.rotation * Vec3::NEG_Z;
    let right = ptf.rotation * Vec3::X;
    let hv = Vec3::new(pl.vel.x, 0.0, pl.vel.z);
    let input = VmInput {
        dt,
        ads: pl.ads_effective,
        sprint: pl.sprint,
        crouch: pl.crouch,
        grounded: pl.grounded,
        vel_local: Vec2::new(-hv.dot(right), hv.dot(fwd)),
        reload_t: ws.reloading,
        yaw_delta: dyaw,
        pitch_delta: dpitch,
        shot,
        landed,
    };
    let (root, pose) = va.0.update(&anim, &input);
    tf.translation = root.p;
    tf.rotation = root.r;
    cur.0 = Some(pose);
    vm.ads_e = va.0.ads_e;
    // luneta fantasma: some até 18% no ADS para não bloquear a visão
    let a = 1.0 - 0.82 * va.0.ads_e;
    for h in sf.mats.iter() {
        if let Some(m) = mats.get_mut(h) {
            if a < 0.99 {
                m.alpha_mode = AlphaMode::Blend;
                m.base_color.set_alpha(a);
            } else if m.alpha_mode != AlphaMode::Opaque {
                m.alpha_mode = AlphaMode::Opaque;
                m.base_color.set_alpha(1.0);
            }
        }
    }
}
