//! Entrada: controles touch (joystick virtual + arrastar para mirar + botões)
//! e teclado/mouse para testar no PC.

use bevy::input::mouse::MouseMotion;
use bevy::prelude::*;
use bevy::window::{CursorGrabMode, PrimaryWindow};
use std::collections::HashMap;

#[derive(Resource, Default)]
pub struct PlayerInput {
    /// x = direita, y = frente (0..1)
    pub move_axis: Vec2,
    /// graus a girar neste quadro (x = yaw, y = pitch; positivo = direita / cima)
    pub look: Vec2,
    pub fire: bool,
    pub ads_toggle: bool,
    pub ads_hold: bool,
    pub jump: bool,
    pub crouch_toggle: bool,
    pub reload: bool,
    pub sprint: bool,
    pub god_toggle: bool,
    pub view_toggle: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum Btn {
    Fire,
    FireLeft,
    Aim,
    Jump,
    Crouch,
    Reload,
    God,
    View,
}

struct BtnDef {
    b: Btn,
    /// distância da borda (direita, ou esquerda se `left`) e de baixo, em px lógicos
    side: f32,
    bottom: f32,
    size: f32,
    label: &'static str,
    left: bool,
    /// ancorado no topo (usa `bottom` como distância do topo)
    top: bool,
}

const BUTTONS: [BtnDef; 8] = [
    BtnDef { b: Btn::Fire, side: 40.0, bottom: 70.0, size: 118.0, label: "FOGO", left: false, top: false },
    BtnDef { b: Btn::Aim, side: 175.0, bottom: 165.0, size: 82.0, label: "MIRA", left: false, top: false },
    BtnDef { b: Btn::Reload, side: 60.0, bottom: 215.0, size: 66.0, label: "R", left: false, top: false },
    BtnDef { b: Btn::Jump, side: 180.0, bottom: 40.0, size: 72.0, label: "PULO", left: false, top: false },
    BtnDef { b: Btn::Crouch, side: 275.0, bottom: 30.0, size: 66.0, label: "AGACH", left: false, top: false },
    BtnDef { b: Btn::FireLeft, side: 40.0, bottom: 300.0, size: 76.0, label: "FOGO", left: true, top: false },
    BtnDef { b: Btn::God, side: 200.0, bottom: 14.0, size: 64.0, label: "IMORTAL", left: false, top: true },
    BtnDef { b: Btn::View, side: 280.0, bottom: 14.0, size: 64.0, label: "1P/3P", left: false, top: true },
];
const JOY_R: f32 = 70.0;
const TOUCH_SENS: f32 = 0.20; // graus por px lógico
const MOUSE_SENS: f32 = 0.09;

impl BtnDef {
    fn center(&self, w: f32, h: f32) -> Vec2 {
        let x = if self.left { self.side + self.size * 0.5 } else { w - self.side - self.size * 0.5 };
        let y = if self.top { self.bottom + self.size * 0.5 } else { h - self.bottom - self.size * 0.5 };
        Vec2::new(x, y)
    }
}

#[derive(Clone, Copy)]
enum Role {
    Joy { origin: Vec2 },
    Look { last: Vec2 },
    Button(Btn),
}

#[derive(Component)]
struct BtnVisual(Btn);
#[derive(Component)]
struct JoyBase;
#[derive(Component)]
struct JoyKnob;

#[derive(Resource, Default)]
pub struct TouchState {
    roles: HashMap<u64, Role>,
    pub held: Vec<Btn>,
    joy: Option<(Vec2, Vec2)>,
}

pub struct ControlsPlugin;
impl Plugin for ControlsPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<PlayerInput>()
            .init_resource::<TouchState>()
            .add_systems(Startup, spawn_touch_ui)
            .add_systems(PreUpdate, (gather_input, update_touch_ui).chain().after(bevy::input::InputSystem));
    }
}

fn spawn_touch_ui(mut c: Commands) {
    for d in BUTTONS.iter() {
        let mut style = Style {
            position_type: PositionType::Absolute,
            width: Val::Px(d.size),
            height: Val::Px(d.size),
            border: UiRect::all(Val::Px(2.0)),
            justify_content: JustifyContent::Center,
            align_items: AlignItems::Center,
            ..default()
        };
        if d.left {
            style.left = Val::Px(d.side);
        } else {
            style.right = Val::Px(d.side);
        }
        if d.top {
            style.top = Val::Px(d.bottom);
        } else {
            style.bottom = Val::Px(d.bottom);
        }
        c.spawn((
            NodeBundle {
                style,
                background_color: BackgroundColor(Color::srgba(0.05, 0.05, 0.06, 0.35)),
                border_color: BorderColor(Color::srgba(1.0, 1.0, 1.0, 0.45)),
                border_radius: BorderRadius::MAX,
                ..default()
            },
            BtnVisual(d.b),
        ))
        .with_children(|p| {
            p.spawn(TextBundle::from_section(
                d.label,
                TextStyle { font_size: if d.size > 100.0 { 22.0 } else if d.label.len() > 5 { 12.0 } else { 15.0 }, color: Color::srgba(1.0, 1.0, 1.0, 0.85), ..default() },
            ));
        });
    }
    // joystick (base + manete); fica no canto quando não está em uso
    c.spawn((
        NodeBundle {
            style: Style {
                position_type: PositionType::Absolute,
                left: Val::Px(60.0),
                bottom: Val::Px(60.0),
                width: Val::Px(JOY_R * 2.0),
                height: Val::Px(JOY_R * 2.0),
                border: UiRect::all(Val::Px(2.0)),
                ..default()
            },
            background_color: BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 0.18)),
            border_color: BorderColor(Color::srgba(1.0, 1.0, 1.0, 0.35)),
            border_radius: BorderRadius::MAX,
            ..default()
        },
        JoyBase,
    ));
    c.spawn((
        NodeBundle {
            style: Style {
                position_type: PositionType::Absolute,
                left: Val::Px(60.0 + JOY_R - 28.0),
                bottom: Val::Px(60.0 + JOY_R - 28.0),
                width: Val::Px(56.0),
                height: Val::Px(56.0),
                ..default()
            },
            background_color: BackgroundColor(Color::srgba(1.0, 1.0, 1.0, 0.35)),
            border_radius: BorderRadius::MAX,
            ..default()
        },
        JoyKnob,
    ));
}

#[allow(clippy::too_many_arguments)]
fn gather_input(
    touches: Res<Touches>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
    mut motion: EventReader<MouseMotion>,
    mut windows: Query<&mut Window, With<PrimaryWindow>>,
    mut st: ResMut<TouchState>,
    mut inp: ResMut<PlayerInput>,
) {
    let Ok(mut window) = windows.get_single_mut() else { return };
    let (w, h) = (window.width(), window.height());
    let prev_held = st.held.clone();
    *inp = PlayerInput::default();

    // ---------------- touch
    for t in touches.iter_just_pressed() {
        let p = t.position();
        let mut role = None;
        for d in BUTTONS.iter() {
            if p.distance(d.center(w, h)) < d.size * 0.5 * 1.15 {
                role = Some(Role::Button(d.b));
                break;
            }
        }
        let role = role.unwrap_or_else(|| {
            let has_joy = st.roles.values().any(|r| matches!(r, Role::Joy { .. }));
            if p.x < w * 0.42 && !has_joy {
                Role::Joy { origin: p }
            } else {
                Role::Look { last: p }
            }
        });
        st.roles.insert(t.id(), role);
    }
    // remove toques soltos/cancelados
    st.roles.retain(|id, _| touches.get_pressed(*id).is_some());

    let mut held = Vec::new();
    let mut joy_vis = None;
    let ids: Vec<u64> = st.roles.keys().copied().collect();
    for id in ids {
        let Some(t) = touches.get_pressed(id) else { continue };
        let p = t.position();
        let role = st.roles[&id];
        match role {
            Role::Joy { origin } => {
                let raw = (p - origin) / JOY_R;
                let len = raw.length();
                let v = if len > 1.0 { raw / len } else { raw };
                inp.move_axis = Vec2::new(v.x, -v.y);
                // empurrar o joystick bem para frente = correr (como no CoD Mobile)
                if len > 1.35 && -raw.y > 0.8 * len {
                    inp.sprint = true;
                }
                joy_vis = Some((origin, origin + v * JOY_R));
            }
            Role::Look { last } => {
                let d = p - last;
                inp.look += Vec2::new(d.x, -d.y) * TOUCH_SENS;
                st.roles.insert(id, Role::Look { last: p });
            }
            Role::Button(b) => held.push(b),
        }
    }
    st.joy = joy_vis;
    let pressed = |b: Btn| held.contains(&b) && !prev_held.contains(&b);
    inp.fire = held.contains(&Btn::Fire) || held.contains(&Btn::FireLeft);
    inp.ads_toggle = pressed(Btn::Aim);
    inp.jump = pressed(Btn::Jump);
    inp.crouch_toggle = pressed(Btn::Crouch);
    inp.reload = pressed(Btn::Reload);
    inp.god_toggle = pressed(Btn::God);
    inp.view_toggle = pressed(Btn::View);
    st.held = held;

    // ---------------- teclado e mouse (teste no PC)
    if !cfg!(target_os = "android") {
        let mut m = Vec2::ZERO;
        if keys.pressed(KeyCode::KeyW) { m.y += 1.0; }
        if keys.pressed(KeyCode::KeyS) { m.y -= 1.0; }
        if keys.pressed(KeyCode::KeyD) { m.x += 1.0; }
        if keys.pressed(KeyCode::KeyA) { m.x -= 1.0; }
        if m != Vec2::ZERO {
            inp.move_axis = m.normalize();
        }
        let locked = window.cursor.grab_mode != CursorGrabMode::None;
        if mouse.just_pressed(MouseButton::Left) && !locked {
            window.cursor.grab_mode = CursorGrabMode::Locked;
            window.cursor.visible = false;
        }
        if keys.just_pressed(KeyCode::Escape) {
            window.cursor.grab_mode = CursorGrabMode::None;
            window.cursor.visible = true;
        }
        for ev in motion.read() {
            if locked {
                inp.look += Vec2::new(ev.delta.x, -ev.delta.y) * MOUSE_SENS;
            }
        }
        if locked {
            inp.fire |= mouse.pressed(MouseButton::Left);
            inp.ads_hold = mouse.pressed(MouseButton::Right);
        }
        inp.jump |= keys.just_pressed(KeyCode::Space);
        inp.crouch_toggle |= keys.just_pressed(KeyCode::KeyC) || keys.just_pressed(KeyCode::ControlLeft);
        inp.reload |= keys.just_pressed(KeyCode::KeyR);
        inp.god_toggle |= keys.just_pressed(KeyCode::KeyG);
        inp.view_toggle |= keys.just_pressed(KeyCode::KeyV);
        inp.sprint |= keys.pressed(KeyCode::ShiftLeft) && m.y > 0.0;
    } else {
        motion.clear();
    }
}

fn update_touch_ui(
    st: Res<TouchState>,
    god: Res<crate::player::GodMode>,
    vm: Res<crate::viewmodel::ViewMode>,
    mut btns: Query<(&BtnVisual, &mut BackgroundColor)>,
    mut base: Query<&mut Style, (With<JoyBase>, Without<JoyKnob>)>,
    mut knob: Query<&mut Style, (With<JoyKnob>, Without<JoyBase>)>,
    windows: Query<&Window, With<PrimaryWindow>>,
) {
    for (v, mut bg) in btns.iter_mut() {
        let on = st.held.contains(&v.0);
        bg.0 = if v.0 == Btn::God && god.0 {
            Color::srgba(0.2, 0.85, 0.35, 0.55)
        } else if v.0 == Btn::View && vm.first {
            Color::srgba(0.25, 0.55, 0.95, 0.55)
        } else if on {
            Color::srgba(1.0, 0.75, 0.2, 0.45)
        } else {
            Color::srgba(0.05, 0.05, 0.06, 0.35)
        };
    }
    let Ok(win) = windows.get_single() else { return };
    let h = win.height();
    let (o, k) = st.joy.unwrap_or((
        Vec2::new(60.0 + JOY_R, h - 60.0 - JOY_R),
        Vec2::new(60.0 + JOY_R, h - 60.0 - JOY_R),
    ));
    if let Ok(mut s) = base.get_single_mut() {
        s.left = Val::Px(o.x - JOY_R);
        s.top = Val::Px(o.y - JOY_R);
        s.bottom = Val::Auto;
    }
    if let Ok(mut s) = knob.get_single_mut() {
        s.left = Val::Px(k.x - 28.0);
        s.top = Val::Px(k.y - 28.0);
        s.bottom = Val::Auto;
    }
}
