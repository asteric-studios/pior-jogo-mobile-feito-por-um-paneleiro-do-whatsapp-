//! Manequim inimigo (Spetsnaz de neve) com IA inspirada no CoD MW2:
//! percepção (visão com FOV + linha de visada, audição de tiros, supressão), escolha de
//! cobertura válida + A*, segurar/espiar/atirar em rajadas, recarga protegida, troca de
//! cobertura avançando, combate em movimento sem cobertura, investigação, patrulha,
//! queda e arrasto quando leva tiro na perna, morte direcional e arma solta com física.

use crate::anim::{Anim, CurrentPose, FlashTimer, Rig, SoldierModel};
use crate::animator::{AnimInput, Animator, UpperMode, U_AIM};
use crate::map;
use crate::nav::{gen_covers, hitboxes, point_segment_dist, ray_capsule, CoverPoint, NavGrid, Part};
use crate::player::{Player, PlayerHit, ENEMY_GROUP};
use crate::weapon::{spawn_sparks, spawn_tracer, xorshift, EnemyHit, Fx, Hitboxes, PlayerShot, WeaponState, SHELL_GROUP};
use crate::world::WORLD_GROUP;
use bevy::prelude::*;
use bevy_rapier3d::prelude::*;
use std::f32::consts::PI;

const CENTER_H: f32 = 0.85;
const MAG: u32 = 30;
const RELOAD_T: f32 = 2.3;

#[derive(Resource)]
pub struct NavRes {
    pub grid: NavGrid,
    pub covers: Vec<CoverPoint>,
}

#[derive(Resource)]
struct Director {
    respawn_t: f32,
    rng: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Ai {
    Patrol,
    Investigate,
    Combat,
    WoundFall,
    Wounded,
    Dying,
    Dead,
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Tactic {
    ToCover,
    Hold,
    Peek,
    Engage,
}

#[derive(Component)]
pub struct Enemy {
    pub model: Entity,
    pub ai: Ai,
    tactic: Tactic,
    tt: f32,
    think: f32,
    pub health: f32,
    leg_dmg: f32,
    yaw: f32,
    prev_yaw: f32,
    aim_yaw: f32,
    aim_pitch: f32,
    prev_pitch: f32,
    vel: Vec3,
    grounded: bool,
    crouch: bool,
    sprint: bool,
    path: Vec<Vec3>,
    path_i: usize,
    sees: bool,
    aware: f32,
    last_seen: Option<Vec3>,
    since_seen: f32,
    vis_time: f32,
    cover: Option<usize>,
    peeks: u32,
    hold_for: f32,
    peek_side: f32,
    burst: u32,
    fire_cd: f32,
    mag: u32,
    reload: Option<f32>,
    reaction: f32,
    suppress: f32,
    stagger: f32,
    recoil: f32,
    full: Option<(&'static str, f32)>,
    wound_aim: bool,
    wound_t: f32,
    dead_t: f32,
    weapon_drop: Option<Entity>,
    patrol_i: usize,
    strafe: f32,
    strafe_t: f32,
    rng: u64,
}

impl Enemy {
    fn new(model: Entity, yaw: f32, seed: u64) -> Self {
        Enemy {
            model,
            ai: Ai::Patrol,
            tactic: Tactic::ToCover,
            tt: 0.0,
            think: 0.0,
            health: 100.0,
            leg_dmg: 0.0,
            yaw,
            prev_yaw: yaw,
            aim_yaw: 0.0,
            aim_pitch: 0.0,
            prev_pitch: 0.0,
            vel: Vec3::ZERO,
            grounded: true,
            crouch: false,
            sprint: false,
            path: Vec::new(),
            path_i: 0,
            sees: false,
            aware: 0.0,
            last_seen: None,
            since_seen: 99.0,
            vis_time: 0.0,
            cover: None,
            peeks: 0,
            hold_for: 1.0,
            peek_side: 1.0,
            burst: 4,
            fire_cd: 0.0,
            mag: MAG,
            reload: None,
            reaction: 0.4,
            suppress: 0.0,
            stagger: 0.0,
            recoil: 0.0,
            full: None,
            wound_aim: false,
            wound_t: 0.0,
            dead_t: 0.0,
            weapon_drop: None,
            patrol_i: (seed % 5) as usize,
            strafe: 1.0,
            strafe_t: 0.0,
            rng: seed | 1,
        }
    }
    fn r(&mut self) -> f32 {
        xorshift(&mut self.rng)
    }
    fn alive(&self) -> bool {
        !matches!(self.ai, Ai::Dying | Ai::Dead)
    }
    fn set_tactic(&mut self, t: Tactic) {
        if self.tactic != t {
            self.tactic = t;
            self.tt = 0.0;
        }
    }
}

#[derive(Component, Default)]
pub struct EnemyAnim(pub Animator);

pub struct EnemyPlugin;
impl Plugin for EnemyPlugin {
    fn build(&self, app: &mut App) {
        let obs = map::obstacles();
        let grid = NavGrid::build(&obs, map::HALF, 0.5, 0.45);
        let covers = gen_covers(&obs, &grid);
        app.insert_resource(NavRes { grid, covers })
            .insert_resource(Director { respawn_t: 3.0, rng: 0x51ED_2701_99AB_C3D1 })
            .add_systems(
                Update,
                (director, enemy_damage, enemy_ai, enemy_drop_weapon, enemy_animate)
                    .chain()
                    .after(crate::player::player_animate),
            );
    }
}

fn yaw_to(v: Vec3) -> f32 {
    (-v.x).atan2(-v.z)
}
fn wrap(a: f32) -> f32 {
    let mut a = a;
    while a > PI {
        a -= 2.0 * PI;
    }
    while a < -PI {
        a += 2.0 * PI;
    }
    a
}
fn world_filter() -> QueryFilter<'static> {
    QueryFilter::default().groups(CollisionGroups::new(WORLD_GROUP, WORLD_GROUP))
}

fn spawn_enemy(c: &mut Commands, assets: &AssetServer, pos: Vec3, yaw: f32, seed: u64) {
    let model = c
        .spawn((
            SceneBundle {
                scene: assets.load("spetsnaz.glb#Scene0"),
                transform: Transform::from_xyz(0.0, -CENTER_H, 0.0).with_rotation(Quat::from_rotation_y(PI)),
                ..default()
            },
            SoldierModel,
            CurrentPose::default(),
        ))
        .id();
    c.spawn((
        SpatialBundle::from_transform(Transform::from_xyz(pos.x, CENTER_H + 0.05, pos.z).with_rotation(Quat::from_rotation_y(yaw))),
        RigidBody::KinematicPositionBased,
        Collider::capsule_y(0.55, 0.3),
        KinematicCharacterController {
            offset: CharacterLength::Absolute(0.02),
            up: Vec3::Y,
            max_slope_climb_angle: 50f32.to_radians(),
            min_slope_slide_angle: 40f32.to_radians(),
            autostep: Some(CharacterAutostep {
                max_height: CharacterLength::Absolute(0.4),
                min_width: CharacterLength::Absolute(0.15),
                include_dynamic_bodies: false,
            }),
            snap_to_ground: Some(CharacterLength::Absolute(0.3)),
            apply_impulse_to_dynamic_bodies: true,
            filter_groups: Some(CollisionGroups::new(ENEMY_GROUP, WORLD_GROUP | Group::GROUP_2 | ENEMY_GROUP)),
            ..default()
        },
        CollisionGroups::new(ENEMY_GROUP, WORLD_GROUP | Group::GROUP_2 | ENEMY_GROUP),
        Enemy::new(model, yaw, seed),
        EnemyAnim::default(),
        Hitboxes::default(),
    ))
    .add_child(model);
}

/// Mantém um manequim no mapa (renasce longe do jogador depois de morrer).
fn director(
    mut c: Commands,
    time: Res<Time>,
    assets: Res<AssetServer>,
    mut dir: ResMut<Director>,
    enemies: Query<&Enemy>,
    players: Query<&Transform, With<Player>>,
) {
    let alive = enemies.iter().filter(|e| e.alive()).count();
    if alive > 0 {
        dir.respawn_t = 0.0;
        return;
    }
    dir.respawn_t += time.delta_seconds();
    if dir.respawn_t < 4.0 {
        return;
    }
    dir.respawn_t = 0.0;
    let pp = players.get_single().map(|t| t.translation).unwrap_or(Vec3::ZERO);
    let mut best = map::ENEMY_SPAWNS[0];
    let mut bd = -1.0;
    for s in map::ENEMY_SPAWNS.iter() {
        let d = s.distance(pp) + xorshift(&mut dir.rng) * 6.0;
        if d > bd {
            bd = d;
            best = *s;
        }
    }
    let yaw = yaw_to(pp - best);
    let seed = (xorshift(&mut dir.rng).abs() * 1.0e9) as u64 + 7;
    spawn_enemy(&mut c, &assets, best, yaw, seed);
}

fn die(e: &mut Enemy, local_dir: Vec3, ws: &mut WeaponState) {
    let clip = if matches!(e.ai, Ai::Wounded | Ai::WoundFall) {
        "death_wounded"
    } else if local_dir.z > 0.0 {
        "death_fwd" // atingido pelas costas: cai para frente
    } else {
        "death_back"
    };
    e.ai = Ai::Dying;
    e.full = Some((clip, 0.0));
    e.dead_t = 0.0;
    e.vel = Vec3::ZERO;
    e.reload = None;
    ws.kills += 1;
}

fn enemy_damage(
    mut ev: EventReader<EnemyHit>,
    mut ws: ResMut<WeaponState>,
    players: Query<&Transform, (With<Player>, Without<Enemy>)>,
    mut q: Query<(&mut Enemy, &Transform, &mut EnemyAnim)>,
) {
    let pp = players.get_single().map(|t| t.translation).ok();
    for h in ev.read() {
        let Ok((mut e, tf, mut an)) = q.get_mut(h.enemy) else { continue };
        if !e.alive() {
            continue;
        }
        let l = tf.rotation.inverse() * h.dir;
        let local = Vec3::new(-l.x, l.y, -l.z); // espaço do modelo (girado 180°)
        let (dmg, part_id, strength) = match h.part {
            Part::Head => (200.0, 0u8, 1.0),
            Part::Torso => (34.0, 1, 1.0),
            Part::Arm => (20.0, 2, 0.8),
            Part::Leg => (25.0, 3, 1.0),
        };
        an.0.hit(local, part_id, strength);
        e.health -= dmg;
        e.stagger = 0.3;
        e.aware = 1.6;
        e.suppress = (e.suppress + 0.5).min(2.0);
        if let Some(p) = pp {
            e.last_seen = Some(p);
            e.since_seen = 0.0;
        }
        if matches!(e.ai, Ai::Patrol | Ai::Investigate) {
            e.ai = Ai::Combat;
            e.set_tactic(Tactic::ToCover);
            e.cover = None;
        }
        if e.health <= 0.0 {
            die(&mut e, local, &mut ws);
            continue;
        }
        if h.part == Part::Leg {
            e.leg_dmg += dmg;
            let fall = e.leg_dmg >= 50.0 || e.r() > -0.4; // ~70% de chance no primeiro tiro na perna
            if fall && !matches!(e.ai, Ai::Wounded | Ai::WoundFall) {
                e.ai = Ai::WoundFall;
                e.full = Some(("wound_fall", 0.0));
                e.vel = Vec3::ZERO;
                e.reload = None;
                e.crouch = false;
                e.sprint = false;
            }
        }
    }
}

/// Escolhe a melhor cobertura que protege do jogador.
fn pick_cover(e: &mut Enemy, pos: Vec3, player_eye: Vec3, nav: &NavRes, rapier: &RapierContext, advance: bool) -> Option<usize> {
    let pp = Vec3::new(player_eye.x, 0.0, player_eye.z);
    let cur_dp = e.cover.map(|i| nav.covers[i].pos.distance(pp)).unwrap_or(999.0);
    let mut cands: Vec<(f32, usize)> = Vec::new();
    for (i, cp) in nav.covers.iter().enumerate() {
        if Some(i) == e.cover {
            continue;
        }
        let de = cp.pos.distance(Vec3::new(pos.x, 0.0, pos.z));
        let dp = cp.pos.distance(pp);
        if de > 28.0 || !(5.0..=42.0).contains(&dp) {
            continue;
        }
        // a cobertura precisa ficar entre o ponto e o jogador
        let to_p = (pp - cp.pos).normalize_or_zero();
        if to_p.dot(-cp.normal) < 0.35 {
            continue;
        }
        let mut s = -de * 0.55 - (dp - 15.0).abs() * 0.35 + e.r() * 1.5;
        if advance && dp < cur_dp - 2.0 {
            s += 4.0;
        }
        cands.push((s, i));
    }
    cands.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
    for (_, i) in cands.into_iter().take(10) {
        let cp = nav.covers[i];
        let head = cp.pos + Vec3::Y * if cp.low { 1.0 } else { 1.5 };
        let d = head - player_eye;
        let len = d.length();
        // protegida = o raio do jogador até a cabeça do soldado bate no cenário antes
        if rapier.cast_ray(player_eye, d / len, len - 0.3, true, world_filter()).is_some() {
            return Some(i);
        }
    }
    None
}

fn cover_valid(cp: &CoverPoint, player_eye: Vec3, rapier: &RapierContext) -> bool {
    let head = cp.pos + Vec3::Y * if cp.low { 1.0 } else { 1.5 };
    let d = head - player_eye;
    let len = d.length();
    len > 4.0 && rapier.cast_ray(player_eye, d / len, len - 0.3, true, world_filter()).is_some()
}

#[allow(clippy::too_many_arguments, clippy::type_complexity)]
fn enemy_ai(
    mut c: Commands,
    time: Res<Time>,
    nav: Res<NavRes>,
    rapier: Res<RapierContext>,
    fx: Res<Fx>,
    mut shots: EventReader<PlayerShot>,
    mut player_hits: EventWriter<PlayerHit>,
    players: Query<(&Transform, &Player), Without<Enemy>>,
    mut q: Query<(
        Entity,
        &mut Enemy,
        &mut Transform,
        Option<&mut KinematicCharacterController>,
        Option<&KinematicCharacterControllerOutput>,
        &EnemyAnim,
    )>,
    mut rigs: Query<(&Rig, &mut FlashTimer)>,
    gts: Query<&GlobalTransform>,
) {
    let dt = time.delta_seconds().min(0.05);
    let shot_list: Vec<(Vec3, Vec3)> = shots.read().map(|s| (s.from, s.to)).collect();
    let (pp, pl_alive, p_crouch, p_vel) = match players.get_single() {
        Ok((t, p)) => (t.translation, !p.dead, p.crouch, p.vel),
        Err(_) => (Vec3::ZERO, false, false, Vec3::ZERO),
    };
    let p_center_h = if p_crouch { 0.6 } else { CENTER_H };
    let p_eye = pp + Vec3::Y * if p_crouch { 0.5 } else { 0.73 };

    for (ent, mut e, mut tf, kcc, out, an) in q.iter_mut() {
        e.prev_yaw = e.yaw;
        e.prev_pitch = e.aim_pitch;
        e.recoil *= (-dt * 14.0).exp();
        e.stagger = (e.stagger - dt).max(0.0);
        e.suppress *= (-dt * 0.8).exp();
        e.fire_cd -= dt;
        if let Some(o) = out {
            e.grounded = o.grounded;
        }

        // ------------------------------------------------ morto / morrendo
        if e.ai == Ai::Dead {
            e.dead_t += dt;
            if e.dead_t > 12.0 {
                if let Some(w) = e.weapon_drop {
                    if let Some(ec) = c.get_entity(w) {
                        ec.despawn_recursive();
                    }
                }
                c.entity(ent).despawn_recursive();
            }
            continue;
        }
        if e.ai == Ai::Dying {
            e.dead_t += dt;
            if let Some((n, t)) = e.full {
                e.full = Some((n, t + dt));
            }
            if e.dead_t > 1.5 {
                e.ai = Ai::Dead;
                e.dead_t = 0.0;
            }
            continue;
        }

        let pos = tf.translation;
        let rot = Quat::from_rotation_y(e.yaw);
        let fwd = rot * Vec3::NEG_Z;
        let wounded = matches!(e.ai, Ai::Wounded | Ai::WoundFall);

        // ------------------------------------------------ percepção
        let eye = pos + Vec3::Y * if wounded { -0.2 } else if e.crouch { 0.3 } else { 0.72 };
        let tgt = pp + Vec3::Y * 0.45;
        let to = tgt - eye;
        let dist = to.length().max(0.01);
        let dir = to / dist;
        let fwd_h = Vec3::new(fwd.x, 0.0, fwd.z).normalize_or_zero();
        let dir_h = Vec3::new(dir.x, 0.0, dir.z).normalize_or_zero();
        let fov = fwd_h.dot(dir_h) > 0.42 || dist < 5.0 || (e.ai == Ai::Combat && e.since_seen < 3.0);
        let los = fov && dist < 85.0 && rapier.cast_ray(eye, dir, dist - 0.4, true, world_filter()).is_none();
        e.sees = pl_alive && los;
        if e.sees {
            let gain = 0.8 + 25.0 / dist.max(1.0);
            e.aware = (e.aware + dt * gain).min(2.0);
            e.last_seen = Some(pp);
            e.since_seen = 0.0;
            e.vis_time += dt;
        } else {
            e.since_seen += dt;
            e.vis_time = 0.0;
            e.aware = (e.aware - dt * 0.08).max(0.0);
        }
        for (from, to2) in shot_list.iter() {
            if from.distance(pos) < 70.0 {
                e.aware = e.aware.max(1.2);
                if e.last_seen.is_none() || e.ai == Ai::Patrol {
                    e.last_seen = Some(*from);
                }
            }
            let head = pos + Vec3::Y * 0.75;
            if point_segment_dist(head, *from, *to2) < 1.6 {
                e.suppress = (e.suppress + 0.35).min(2.0);
                e.aware = 1.6;
            }
        }
        if !pl_alive && e.ai == Ai::Combat && e.since_seen > 2.0 {
            e.ai = Ai::Patrol;
            e.path.clear();
        }
        if e.aware >= 1.0 && matches!(e.ai, Ai::Patrol | Ai::Investigate) && pl_alive {
            e.ai = Ai::Combat;
            e.set_tactic(Tactic::ToCover);
            e.cover = None;
            e.reaction = 0.3 + e.r().abs() * 0.3;
        }
        if e.sees {
            e.reaction -= dt;
        }

        // ------------------------------------------------ recarga
        if let Some(t) = e.reload {
            let t = t + dt;
            if t >= RELOAD_T {
                e.reload = None;
                e.mag = MAG;
            } else {
                e.reload = Some(t);
            }
        }

        // ------------------------------------------------ decisões
        let mut desired = Vec3::ZERO; // velocidade horizontal desejada
        let mut face: Option<Vec3> = None; // ponto para onde olhar
        let mut want_fire = false;
        e.sprint = false;
        e.tt += dt;
        e.think -= dt;

        let ai_now = e.ai;
        match ai_now {
            Ai::WoundFall => {
                if let Some((n, t)) = e.full {
                    e.full = Some((n, t + dt));
                    if t + dt >= 1.25 {
                        e.ai = Ai::Wounded;
                        e.wound_aim = false;
                        e.wound_t = 0.0;
                    }
                }
            }
            Ai::Wounded => {
                e.wound_t += dt;
                if let Some(lp) = e.last_seen {
                    face = Some(lp);
                }
                let close = dist < 9.0 && e.sees;
                if !e.wound_aim {
                    e.full = Some(("wound_crawl", e.wound_t));
                    // arrasta-se para trás (para longe do jogador)
                    let back = -fwd_h;
                    if nav.grid.walkable(pos + back * 0.7) {
                        desired = back * 0.32;
                    }
                    if e.wound_t > 2.6 || close {
                        e.wound_aim = true;
                        e.wound_t = 0.0;
                        e.reaction = 0.5 + e.r().abs() * 0.4;
                    }
                } else {
                    e.full = Some(("wound_aim", e.wound_t));
                    want_fire = true;
                    if e.wound_t > 3.8 && !close {
                        e.wound_aim = false;
                        e.wound_t = 0.0;
                    }
                }
                if e.mag == 0 && e.reload.is_none() {
                    e.mag = MAG; // ferido: troca rápida
                }
            }
            Ai::Patrol => {
                e.full = None;
                if e.path_i >= e.path.len() {
                    if e.tt > 2.0 {
                        e.patrol_i = (e.patrol_i + 1) % map::PATROL.len();
                        e.path = nav.grid.path(pos, map::PATROL[e.patrol_i]).unwrap_or_default();
                        e.path_i = 1;
                        e.tt = 0.0;
                    }
                } else {
                    desired = follow(&mut e, pos) * 1.4;
                }
            }
            Ai::Investigate => {
                e.full = None;
                if e.path_i >= e.path.len() {
                    if e.tt > 4.0 {
                        e.ai = Ai::Patrol;
                        e.tt = 0.0;
                    }
                } else {
                    desired = follow(&mut e, pos) * 1.8;
                }
                if let Some(lp) = e.last_seen {
                    face = Some(lp);
                }
            }
            Ai::Combat => {
                e.full = None;
                let lp = e.last_seen.unwrap_or(pp);
                face = Some(if e.sees { pp } else { lp });
                if e.since_seen > 8.0 {
                    // perdeu o jogador: vai investigar a última posição
                    e.ai = Ai::Investigate;
                    e.tt = 0.0;
                    e.path = nav.grid.path(pos, lp).unwrap_or_default();
                    e.path_i = 1;
                    e.aware = 0.6;
                } else {
                    let think = e.think <= 0.0;
                    if think {
                        e.think = 0.2;
                    }
                    let cover_ok = e.cover.map(|i| cover_valid(&nav.covers[i], p_eye, &rapier)).unwrap_or(false);
                    let tac = e.tactic;
                    match tac {
                        Tactic::ToCover => {
                            if think && (e.cover.is_none() || !cover_ok) {
                                let adv = e.peeks >= 2;
                                e.cover = pick_cover(&mut e, pos, p_eye, &nav, &rapier, adv);
                                e.peeks = 0;
                                match e.cover {
                                    Some(i) => {
                                        e.path = nav.grid.path(pos, nav.covers[i].pos).unwrap_or_default();
                                        e.path_i = 1;
                                        if e.path.is_empty() {
                                            e.cover = None;
                                            e.set_tactic(Tactic::Engage);
                                        }
                                    }
                                    None => e.set_tactic(Tactic::Engage),
                                }
                            }
                            if let Some(i) = e.cover {
                                let cp = nav.covers[i];
                                let d = Vec3::new(cp.pos.x - pos.x, 0.0, cp.pos.z - pos.z).length();
                                let far = d > 6.0;
                                e.sprint = far && !e.sees && e.reload.is_none();
                                let spd = if e.sprint { 5.2 } else { 3.4 };
                                desired = follow(&mut e, pos) * spd;
                                if e.sprint {
                                    face = None; // corre olhando para frente
                                }
                                if d < 0.45 || e.path_i >= e.path.len() {
                                    e.set_tactic(Tactic::Hold);
                                    e.hold_for = 0.6 + e.r().abs() * 1.1 + e.suppress;
                                }
                                // sem visada: atira enquanto se move se estiver vendo o jogador de perto
                                want_fire = e.sees && !e.sprint && dist < 18.0;
                            }
                        }
                        Tactic::Hold => {
                            if let Some(i) = e.cover {
                                let cp = nav.covers[i];
                                e.crouch = cp.low;
                                desired = (Vec3::new(cp.pos.x - pos.x, 0.0, cp.pos.z - pos.z) * 3.0).clamp_length_max(1.8);
                                if think && !cover_ok {
                                    e.set_tactic(Tactic::ToCover);
                                    e.crouch = false;
                                } else if e.reload.is_none() && e.mag < 12 {
                                    e.reload = Some(0.0);
                                } else if e.tt > e.hold_for && e.reload.is_none() && e.suppress < 0.9 {
                                    e.set_tactic(Tactic::Peek);
                                    e.burst = 3 + (e.r().abs() * 4.0) as u32;
                                    e.reaction = e.reaction.max(0.2 + e.r().abs() * 0.25);
                                    e.peek_side = if e.r() > 0.0 { 1.0 } else { -1.0 };
                                }
                            } else {
                                e.set_tactic(Tactic::ToCover);
                            }
                        }
                        Tactic::Peek => {
                            if let Some(i) = e.cover {
                                let cp = nav.covers[i];
                                let peek_pos = if cp.low {
                                    e.crouch = false; // levanta por cima da cobertura baixa
                                    cp.pos
                                } else {
                                    e.crouch = false; // passo lateral na cobertura alta
                                    cp.pos + cp.tangent * e.peek_side * (cp.half_len + 0.45).min(1.0)
                                };
                                desired = (Vec3::new(peek_pos.x - pos.x, 0.0, peek_pos.z - pos.z) * 3.0).clamp_length_max(1.8);
                                want_fire = true;
                                let done = (e.burst == 0 && e.fire_cd <= 0.0) || (e.tt > 2.2 && !e.sees) || e.tt > 4.5;
                                if done || e.suppress > 1.1 || e.reload.is_some() {
                                    e.peeks += 1;
                                    if e.peeks >= 3 + (e.r().abs() * 2.0) as u32 {
                                        e.set_tactic(Tactic::ToCover); // muda de cobertura avançando
                                        e.cover = None;
                                    } else {
                                        e.set_tactic(Tactic::Hold);
                                        e.hold_for = 0.7 + e.r().abs() * 1.3 + e.suppress * 1.5;
                                    }
                                }
                            } else {
                                e.set_tactic(Tactic::ToCover);
                            }
                        }
                        Tactic::Engage => {
                            // sem cobertura: anda de lado mantendo distância e atirando
                            e.crouch = false;
                            e.strafe_t -= dt;
                            if e.strafe_t <= 0.0 {
                                e.strafe = if e.r() > 0.0 { 1.0 } else { -1.0 };
                                e.strafe_t = 1.2 + e.r().abs() * 1.6;
                            }
                            let to_p = Vec3::new(pp.x - pos.x, 0.0, pp.z - pos.z);
                            let dp = to_p.length().max(0.01);
                            let side = Vec3::new(-to_p.z, 0.0, to_p.x) / dp;
                            let mut v = side * e.strafe;
                            if dp < 6.0 {
                                v -= to_p / dp * 0.8;
                            } else if dp > 22.0 {
                                v += to_p / dp * 0.8;
                            }
                            if !nav.grid.walkable(pos + v.normalize_or_zero() * 0.8) {
                                e.strafe = -e.strafe;
                                v = -v;
                            }
                            desired = v.normalize_or_zero() * 1.8;
                            want_fire = true;
                            if e.mag == 0 && e.reload.is_none() {
                                e.reload = Some(0.0);
                            }
                            if think && e.tt > 2.5 {
                                e.set_tactic(Tactic::ToCover);
                                e.cover = None;
                            }
                        }
                    }
                }
            }
            Ai::Dying | Ai::Dead => {}
        }
        if !matches!(e.tactic, Tactic::Hold | Tactic::Peek) || e.ai != Ai::Combat {
            if !wounded {
                e.crouch = false;
            }
        }
        desired = desired.clamp_length_max(5.5);
        if e.stagger > 0.0 {
            desired *= 0.2;
        }

        // ------------------------------------------------ orientação
        let target_yaw = match face {
            Some(p) => yaw_to(p - pos),
            None => {
                let v = Vec3::new(e.vel.x, 0.0, e.vel.z);
                if v.length() > 0.5 { yaw_to(v) } else { e.yaw }
            }
        };
        let turn = if wounded { 1.4 } else { 5.0 } * dt;
        let dy = wrap(target_yaw - e.yaw);
        e.yaw = wrap(e.yaw + dy.clamp(-turn, turn));
        let rot = Quat::from_rotation_y(e.yaw);
        // mira no espaço do modelo (+Z frente, +X esquerda)
        let aim_tgt = if e.sees { tgt } else { e.last_seen.map(|l| l + Vec3::Y * 0.45).unwrap_or(eye + fwd) };
        let rl = rot.inverse() * (aim_tgt - eye);
        let ml = Vec3::new(-rl.x, rl.y, -rl.z);
        let horiz = Vec2::new(ml.x, ml.z).length().max(0.01);
        let ay = ml.x.atan2(ml.z).clamp(-1.0, 1.0);
        let ap = ml.y.atan2(horiz).clamp(-0.9, 0.9);
        e.aim_yaw += (ay - e.aim_yaw) * (1.0 - (-dt * 10.0).exp());
        e.aim_pitch += (ap - e.aim_pitch) * (1.0 - (-dt * 10.0).exp());

        // ------------------------------------------------ movimento
        let accel = if e.grounded { 9.0 } else { 2.0 };
        let h = Vec3::new(e.vel.x, 0.0, e.vel.z);
        let nh = h + (desired - h) * (accel * dt).min(1.0);
        e.vel.x = nh.x;
        e.vel.z = nh.z;
        if e.grounded && e.vel.y <= 0.0 {
            e.vel.y = -2.0;
        } else {
            e.vel.y -= 17.0 * dt;
        }
        if let Some(mut k) = kcc {
            k.translation = Some(e.vel * dt);
        }
        tf.rotation = rot;

        // ------------------------------------------------ tiro
        let aiming_ready = if wounded { e.full.map(|f| f.0 == "wound_aim").unwrap_or(false) && e.wound_t > 0.3 } else { an.0.uw[U_AIM] > 0.6 };
        if want_fire
            && e.sees
            && pl_alive
            && e.reload.is_none()
            && e.mag > 0
            && e.fire_cd <= 0.0
            && e.reaction <= 0.0
            && e.aim_yaw.abs() < 0.5
            && aiming_ready
            && (e.burst > 0 || e.tactic == Tactic::Engage || wounded)
        {
            if let Ok((rig, mut flash)) = rigs.get_mut(e.model) {
                if let Ok(mg) = gts.get(rig.muzzle) {
                    let muzzle = mg.translation();
                    let pspeed = Vec2::new(p_vel.x, p_vel.z).length();
                    let mut spread = 1.3 + dist * 0.035 + pspeed * 0.35 + e.suppress * 2.5;
                    if e.vis_time < 1.2 {
                        spread += (1.2 - e.vis_time) * 2.2; // primeiros tiros menos precisos (MW2)
                    }
                    if wounded {
                        spread += 2.0;
                    }
                    if p_crouch {
                        spread *= 0.85;
                    }
                    let aimp = pp + Vec3::Y * (0.05 + e.r().abs() * 0.55);
                    let d0 = (aimp - muzzle).normalize_or_zero();
                    let side = d0.cross(Vec3::Y).normalize_or_zero();
                    let up = side.cross(d0);
                    let sr = spread.to_radians() * 0.5;
                    let (r1, r2) = (e.r(), e.r());
                    let sd = (d0 + side * r1 * sr + up * r2 * sr).normalize_or_zero();
                    let wh = rapier.cast_ray_and_get_normal(muzzle, sd, 150.0, true, world_filter());
                    let wt = wh.map(|(_, h)| h.time_of_impact).unwrap_or(150.0);
                    let a = pp - Vec3::Y * (p_center_h - 0.3);
                    let b = pp + Vec3::Y * (p_center_h - 0.3);
                    let pt = ray_capsule(muzzle, sd, a, b, 0.32).filter(|t| *t < wt);
                    let end = pt.unwrap_or(wt);
                    spawn_tracer(&mut c, &fx, muzzle, sd, end);
                    if pt.is_some() {
                        player_hits.send(PlayerHit { dir: sd, dmg: 9.0 });
                    } else if let Some((_, h)) = wh {
                        let n = if h.normal.length_squared() > 0.5 { h.normal.normalize() } else { -sd };
                        spawn_sparks(&mut c, &fx, &mut e.rng, h.point, n, false);
                    }
                    flash.0 = 0.05;
                    e.recoil = 1.0;
                    e.mag -= 1;
                    e.fire_cd = 0.1;
                    if e.burst > 0 {
                        e.burst -= 1;
                    }
                    if e.burst == 0 {
                        e.fire_cd = 0.45 + e.r().abs() * 0.5;
                        if e.tactic == Tactic::Engage || wounded {
                            e.burst = 3 + (e.r().abs() * 4.0) as u32;
                        }
                    }
                    if e.mag == 0 {
                        e.reload = Some(0.0);
                    }
                }
            }
        }
    }
}

/// Segue o caminho atual e devolve a direção horizontal (unitária ou zero).
fn follow(e: &mut Enemy, pos: Vec3) -> Vec3 {
    while e.path_i < e.path.len() {
        let t = e.path[e.path_i];
        let d = Vec3::new(t.x - pos.x, 0.0, t.z - pos.z);
        if d.length() < 0.4 {
            e.path_i += 1;
            continue;
        }
        return d.normalize();
    }
    Vec3::ZERO
}

/// Ao morrer: solta a arma (vira corpo rígido) e desliga a cápsula de movimento.
fn enemy_drop_weapon(mut c: Commands, mut q: Query<(Entity, &mut Enemy)>, mut rigs: Query<&mut Rig>) {
    for (ent, mut e) in q.iter_mut() {
        if e.ai != Ai::Dying || e.weapon_drop.is_some() || e.dead_t < 0.25 {
            continue;
        }
        let Ok(mut rig) = rigs.get_mut(e.model) else { continue };
        let w = rig.weapon;
        rig.weapon_free = true;
        e.weapon_drop = Some(w);
        let (r1, r2) = (e.r(), e.r());
        c.entity(w).remove_parent_in_place().insert((
            RigidBody::Dynamic,
            Collider::compound(vec![(Vec3::new(0.0, -0.03, 0.08), Quat::IDENTITY, Collider::cuboid(0.03, 0.08, 0.42))]),
            ColliderMassProperties::Mass(3.5),
            Friction::coefficient(0.8),
            Restitution::coefficient(0.1),
            Velocity { linvel: Vec3::new(r1 * 1.2, 1.0, r2 * 1.2), angvel: Vec3::new(r2 * 3.0, r1 * 2.0, 1.5) },
            CollisionGroups::new(SHELL_GROUP, WORLD_GROUP),
        ));
        c.entity(ent).remove::<(KinematicCharacterController, Collider, RigidBody)>();
    }
}

#[allow(clippy::type_complexity)]
fn enemy_animate(
    time: Res<Time>,
    anim: Res<Anim>,
    mut q: Query<(&Enemy, &Transform, &mut EnemyAnim, &mut Hitboxes)>,
    mut models: Query<(&mut CurrentPose, &Transform), Without<Enemy>>,
) {
    let dt = time.delta_seconds().min(0.05);
    for (e, tf, mut an, mut hb) in q.iter_mut() {
        let Ok((mut cur, mtf)) = models.get_mut(e.model) else { continue };
        let fwd = tf.rotation * Vec3::NEG_Z;
        let right = tf.rotation * Vec3::X;
        let hv = Vec3::new(e.vel.x, 0.0, e.vel.z);
        let vel_local = Vec2::new(-hv.dot(right), hv.dot(fwd));
        let moving = vel_local.length() > 0.25;
        let aim = match e.ai {
            Ai::Combat => matches!(e.tactic, Tactic::Peek | Tactic::Engage) || (e.tactic == Tactic::ToCover && e.sees && !e.sprint),
            Ai::Investigate => true,
            _ => false,
        };
        let upper = if e.sprint && moving {
            UpperMode::Sprint
        } else if aim {
            UpperMode::Aim
        } else {
            UpperMode::Low
        };
        let input = AnimInput {
            dt,
            vel_local,
            grounded: true,
            crouch: e.crouch,
            sprint: e.sprint,
            ads: aim,
            upper,
            reload_t: e.reload,
            aim_yaw: e.aim_yaw,
            aim_pitch: e.aim_pitch,
            root_yaw_delta: wrap(e.yaw - e.prev_yaw),
            pitch_delta: e.aim_pitch - e.prev_pitch,
            recoil: e.recoil,
            feet: None,
            full: e.full,
        };
        let pose = an.0.update(&anim, &input);
        cur.0 = Some(pose);
        // hitboxes no mundo
        let m = tf.compute_matrix() * mtf.compute_matrix();
        let fk = anim.fk(&pose);
        hb.0.clear();
        for (a, b, r, part) in hitboxes(&fk).iter() {
            hb.0.push((m.transform_point3(*a), m.transform_point3(*b), *r, *part));
        }
    }
}
