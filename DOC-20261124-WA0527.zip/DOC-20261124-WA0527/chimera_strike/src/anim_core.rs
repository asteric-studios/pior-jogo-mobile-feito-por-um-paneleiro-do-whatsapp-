//! Núcleo do runtime de animação (sem ECS). Porta 1:1 de tools/anim.py + tools/runtime.py.
//! - IK anatômico de duas juntas (cotovelo/joelho dobram só no eixo de dobradiça)
//! - ossos de torção do antebraço (evita o "braço fino" do skinning linear)
//! - camadas: inferior (locomoção) + superior (mira/baixa/sprint/recarga) + corpo inteiro
//! - procedurais: giro das pernas, IK dos pés no terreno, balanço do passo, inclinação,
//!   correção de mira, olhar, atraso da arma ao girar, reação a tiro e recuo.
#![allow(dead_code)]
use bevy::math::{Quat, Vec3};
use std::collections::HashMap;

pub const NB: usize = 28;
pub const BONE_NAMES: [&str; NB] = [
    "Hips", "Spine", "Spine1", "Spine2", "Neck", "Head", "RightShoulder", "RightArm",
    "RightForeArm", "RightHand", "RightFingers", "LeftShoulder", "LeftArm", "LeftForeArm",
    "LeftHand", "LeftFingers", "RightUpLeg", "RightLeg", "RightFoot", "RightToeBase",
    "LeftUpLeg", "LeftLeg", "LeftFoot", "LeftToeBase", "RightForeArmTwist1",
    "RightForeArmTwist2", "LeftForeArmTwist1", "LeftForeArmTwist2",
];
pub const PARENT: [i32; NB] = [
    -1, 0, 1, 2, 3, 4, 3, 6, 7, 8, 9, 3, 11, 12, 13, 14, 0, 16, 17, 18, 0, 20, 21, 22, 8, 8, 13, 13,
];
pub const LOWER: [usize; 9] = [0, 16, 17, 18, 19, 20, 21, 22, 23];
pub const HIPS: usize = 0;
pub const SPINE: usize = 1;
pub const SPINE1: usize = 2;
pub const SPINE2: usize = 3;
pub const NECK: usize = 4;
pub const HEAD: usize = 5;
pub const R_ARM: usize = 7;
pub const R_FORE: usize = 8;
pub const R_HAND: usize = 9;
pub const L_ARM: usize = 12;
pub const L_FORE: usize = 13;
pub const L_HAND: usize = 14;
pub const R_UPLEG: usize = 16;
pub const R_LEG: usize = 17;
pub const R_FOOT: usize = 18;
pub const L_UPLEG: usize = 20;
pub const L_LEG: usize = 21;
pub const L_FOOT: usize = 22;
const R_TW1: usize = 24;
const R_TW2: usize = 25;
const L_TW1: usize = 26;
const L_TW2: usize = 27;
const POLE_R: Vec3 = Vec3::new(-0.6, -1.0, -0.25);
const POLE_L: Vec3 = Vec3::new(0.5, -1.0, -0.2);
const ARM_FLEX: Vec3 = Vec3::Z;
const LEG_FLEX: Vec3 = Vec3::NEG_Z;

// ------------------------------------------------------------------ math
pub fn qpow(q: Quat, t: f32) -> Quat {
    Quat::IDENTITY.slerp(q, t)
}
pub fn fromto(a: Vec3, b: Vec3) -> Quat {
    let (a, b) = (a.normalize_or_zero(), b.normalize_or_zero());
    if a == Vec3::ZERO || b == Vec3::ZERO {
        return Quat::IDENTITY;
    }
    Quat::from_rotation_arc(a, b)
}
fn twist_of(r: Quat, axis: Vec3) -> Quat {
    let v = Vec3::new(r.x, r.y, r.z);
    let p = axis * v.dot(axis);
    let t = Quat::from_xyzw(p.x, p.y, p.z, r.w);
    let n = t.length();
    if n < 1e-9 {
        Quat::IDENTITY
    } else {
        t / n
    }
}
/// rotação a partir de uma base ortonormal (colunas X, Y, Z)
fn from_basis(x: Vec3, y: Vec3, z: Vec3) -> Quat {
    Quat::from_mat3(&bevy::math::Mat3::from_cols(x, y, z)).normalize()
}
pub fn axis_angle(v: Vec3) -> Quat {
    let a = v.length();
    if a < 1e-8 {
        Quat::IDENTITY
    } else {
        Quat::from_axis_angle(v / a, a)
    }
}
/// yaw (Y), pitch (X), roll (Z) em radianos, mesma convenção do Python `ypr`
pub fn ypr(y: f32, p: f32, r: f32) -> Quat {
    Quat::from_rotation_y(y) * Quat::from_rotation_x(p) * Quat::from_rotation_z(r)
}
pub fn aim_dir(yaw: f32, pitch: f32) -> Vec3 {
    Vec3::new(yaw.sin() * pitch.cos(), pitch.sin(), yaw.cos() * pitch.cos())
}

// ------------------------------------------------------------------ pose
#[derive(Clone, Copy)]
pub struct Pose {
    pub rot: [Quat; NB],
    pub hips: Vec3,
    pub wpos: Vec3,
    pub wrot: Quat,
    pub mpos: Vec3,
    pub mrot: Quat,
    pub ikl: f32,
    pub ikr: f32,
    pub aimw: f32,
    pub aimoff: f32,
}
impl Default for Pose {
    fn default() -> Self {
        Pose {
            rot: [Quat::IDENTITY; NB],
            hips: Vec3::new(-0.02, 0.97, 0.0),
            wpos: Vec3::ZERO,
            wrot: Quat::IDENTITY,
            mpos: Vec3::ZERO,
            mrot: Quat::IDENTITY,
            ikl: 1.0,
            ikr: 1.0,
            aimw: 1.0,
            aimoff: 0.0,
        }
    }
}

pub struct Fk {
    pub gr: [Quat; NB],
    pub gp: [Vec3; NB],
    pub wp: Vec3,
    pub wr: Quat,
}

/// Parâmetros procedurais (todos no espaço do modelo: +Z frente, +X esquerda, +Y cima).
#[derive(Clone, Copy, Default)]
pub struct Procedural {
    pub legs_yaw: f32,
    pub hips_dy: f32,
    /// alturas do chão sob os pés (esquerdo, direito) relativas à raiz
    pub feet: Option<(f32, f32)>,
    pub bob_phase: f32,
    pub bob_amt: f32,
    pub lean_roll: f32,
    pub lean_pitch: f32,
    pub sway_yaw: f32,
    pub sway_pitch: f32,
    pub flinch: Vec3,
    pub recoil: f32,
}

#[derive(Clone)]
pub struct Clip {
    /// 0 inferior (loop), 1 superior (loop), 2 superior sem loop, 3 corpo inteiro (loop), 4 corpo inteiro sem loop
    pub kind: u32,
    pub dur: f32,
    pub speed: f32,
    pub frames: Vec<Pose>,
}

pub struct AnimData {
    pub t0: [Vec3; NB],
    pub grips: [(Vec3, Quat); 2],
    pub mag_rest: Vec3,
    pub clips: HashMap<String, Clip>,
}

struct Rd<'a> {
    b: &'a [u8],
    o: usize,
}
impl<'a> Rd<'a> {
    fn u32(&mut self) -> u32 {
        let v = u32::from_le_bytes(self.b[self.o..self.o + 4].try_into().unwrap());
        self.o += 4;
        v
    }
    fn f32(&mut self) -> f32 {
        let v = f32::from_le_bytes(self.b[self.o..self.o + 4].try_into().unwrap());
        self.o += 4;
        v
    }
    fn v3(&mut self) -> Vec3 {
        Vec3::new(self.f32(), self.f32(), self.f32())
    }
    fn q(&mut self) -> Quat {
        Quat::from_xyzw(self.f32(), self.f32(), self.f32(), self.f32()).normalize()
    }
}

impl AnimData {
    pub fn parse(bytes: &[u8]) -> AnimData {
        assert_eq!(&bytes[0..4], b"CHA2", "anims.bin inválido");
        let mut r = Rd { b: bytes, o: 4 };
        let nb = r.u32() as usize;
        assert_eq!(nb, NB, "número de ossos diferente");
        let mut t0 = [Vec3::ZERO; NB];
        for t in t0.iter_mut() {
            *t = r.v3();
        }
        let g0 = (r.v3(), r.q());
        let g1 = (r.v3(), r.q());
        let mag_rest = r.v3();
        let nclips = r.u32();
        let mut clips = HashMap::new();
        for _ in 0..nclips {
            let nl = r.u32() as usize;
            let name = String::from_utf8_lossy(&bytes[r.o..r.o + nl]).to_string();
            r.o += nl;
            let kind = r.u32();
            let dur = r.f32();
            let speed = r.f32();
            let nf = r.u32() as usize;
            let mut frames = Vec::with_capacity(nf);
            for _ in 0..nf {
                let mut p = Pose::default();
                for i in 0..NB {
                    p.rot[i] = r.q();
                }
                p.hips = r.v3();
                p.wpos = r.v3();
                p.wrot = r.q();
                p.mpos = r.v3();
                p.mrot = r.q();
                p.ikl = r.f32();
                p.ikr = r.f32();
                p.aimw = r.f32();
                p.aimoff = r.f32();
                frames.push(p);
            }
            clips.insert(name, Clip { kind, dur, speed, frames });
        }
        AnimData { t0, grips: [g0, g1], mag_rest, clips }
    }

    pub fn clip(&self, name: &str) -> &Clip {
        self.clips
            .get(name)
            .unwrap_or_else(|| panic!("clip {name} não encontrado"))
    }

    pub fn fk(&self, p: &Pose) -> Fk {
        let mut gr = [Quat::IDENTITY; NB];
        let mut gp = [Vec3::ZERO; NB];
        for i in 0..NB {
            let pa = PARENT[i];
            if pa < 0 {
                gr[i] = p.rot[i];
                gp[i] = p.hips;
            } else {
                let pa = pa as usize;
                gp[i] = gp[pa] + gr[pa] * self.t0[i];
                gr[i] = gr[pa] * p.rot[i];
            }
        }
        let wp = gp[SPINE2] + gr[SPINE2] * p.wpos;
        let wr = gr[SPINE2] * p.wrot;
        Fk { gr, gp, wp, wr }
    }

    /// IK anatômico de duas juntas (igual ao `anim.ik2` do Python).
    #[allow(clippy::too_many_arguments)]
    pub fn ik2(&self, p: &mut Pose, ia: usize, ib: usize, ic: usize, tp: Vec3, tr: Quat, pole: Vec3, flex: Vec3, w: f32) {
        if w <= 0.0 {
            return;
        }
        let f = self.fk(p);
        let a = f.gp[ia];
        let b = f.gp[ib];
        let l1 = self.t0[ib].length();
        let l2 = self.t0[ic].length();
        let d = tp - a;
        let dist0 = d.length();
        let u = d / dist0.max(1e-6);
        let dist = dist0.clamp((l1 - l2).abs() + 1e-3, (l1 + l2) * 0.9999);
        let mut v = pole - pole.dot(u) * u;
        if v.length() < 1e-6 {
            v = (b - a) - (b - a).dot(u) * u;
        }
        if v.length() < 1e-6 {
            v = u.cross(Vec3::X);
        }
        let v = v.normalize();
        let ca = ((l1 * l1 + dist * dist - l2 * l2) / (2.0 * l1 * dist)).clamp(-1.0, 1.0);
        let sa = (1.0 - ca * ca).max(0.0).sqrt();
        let e = a + u * l1 * ca + v * l1 * sa;
        // base de repouso do osso (direção + eixo de dobradiça)
        let d1b = self.t0[ib] / l1;
        let hb = d1b.cross(flex).normalize();
        let d1 = (e - a) / l1;
        let mut n = v.cross(u);
        n = (n - n.dot(d1) * d1).normalize();
        let ra = from_basis(d1, n, d1.cross(n)) * from_basis(d1b, hb, d1b.cross(hb)).inverse();
        let tgt = a + u * dist;
        let fl = ra.inverse() * (tgt - e).normalize();
        let lb = fromto(self.t0[ic] / l2, fl);
        let gb = ra * lb;
        let par = PARENT[ia] as usize;
        let na = f.gr[par].inverse() * ra;
        let nc = gb.inverse() * tr;
        p.rot[ia] = p.rot[ia].slerp(na, w);
        p.rot[ib] = p.rot[ib].slerp(lb, w);
        p.rot[ic] = p.rot[ic].slerp(nc, w);
    }

    pub fn pre_rotate_chain(&self, p: &mut Pose, bones: &[usize], qtot: Quat) {
        let qs = qpow(qtot, 1.0 / bones.len() as f32);
        for &b in bones {
            let f = self.fk(p);
            let par = PARENT[b] as usize;
            p.rot[b] = f.gr[par].inverse() * (qs * f.gr[b]);
        }
    }

    fn aim_correct(&self, p: &mut Pose, desired: Vec3, w: f32) {
        if w <= 0.0 {
            return;
        }
        for _ in 0..2 {
            let f = self.fk(p);
            let fwd = f.wr * Vec3::Z;
            self.pre_rotate_chain(p, &[SPINE, SPINE1, SPINE2], qpow(fromto(fwd, desired), w));
        }
    }

    fn head_look(&self, p: &mut Pose, desired: Vec3, w: f32) {
        if w <= 0.0 {
            return;
        }
        let f = self.fk(p);
        let fwd = f.gr[HEAD] * Vec3::Z;
        self.pre_rotate_chain(p, &[NECK, HEAD], qpow(fromto(fwd, desired), w));
    }

    fn arm_ik(&self, p: &mut Pose, wr: f32, wl: f32) {
        let f = self.fk(p);
        let chest = f.gr[SPINE2];
        let (rp, rr) = self.grips[0];
        let (lp, lr) = self.grips[1];
        self.ik2(p, R_ARM, R_FORE, R_HAND, f.wp + f.wr * rp, f.wr * rr, chest * POLE_R, ARM_FLEX, wr);
        self.ik2(p, L_ARM, L_FORE, L_HAND, f.wp + f.wr * lp, f.wr * lr, chest * POLE_L, ARM_FLEX, wl);
    }

    /// Distribui a torção do pulso nos ossos de twist do antebraço.
    fn apply_twist(&self, p: &mut Pose) {
        for (h, t1, t2) in [(R_HAND, R_TW1, R_TW2), (L_HAND, L_TW1, L_TW2)] {
            let ax = self.t0[h].normalize();
            let mut tw = twist_of(p.rot[h], ax);
            if tw.w < 0.0 {
                tw = -tw;
            }
            p.rot[t1] = qpow(tw, 1.0 / 3.0);
            p.rot[t2] = qpow(tw, 2.0 / 3.0);
        }
    }

    /// Ajusta as pernas à altura do chão sob cada pé.
    fn foot_ground(&self, p: &mut Pose, dl: f32, dr: f32) {
        let drop = 0.0f32.min(dl).min(dr);
        let f = self.fk(p);
        let feet = [
            (R_UPLEG, R_LEG, R_FOOT, dr, f.gp[R_FOOT], f.gr[R_FOOT], f.gp[R_LEG], f.gp[R_UPLEG]),
            (L_UPLEG, L_LEG, L_FOOT, dl, f.gp[L_FOOT], f.gr[L_FOOT], f.gp[L_LEG], f.gp[L_UPLEG]),
        ];
        p.hips.y += drop;
        for (ia, ib, ic, d, ank, fr, knee, hip) in feet {
            if (d - drop).abs() < 1e-4 && drop.abs() < 1e-4 {
                continue;
            }
            let tgt = ank + Vec3::new(0.0, d, 0.0);
            let mid = (hip + ank) * 0.5;
            let mut pole = knee - mid;
            if pole.length() < 1e-4 {
                pole = fr * Vec3::Z;
            }
            self.ik2(p, ia, ib, ic, tgt, fr, pole, LEG_FLEX, 1.0);
        }
    }

    /// Pose do viewmodel (primeira pessoa): só mãos na arma + torção. A posição vem da raiz.
    pub fn viewmodel_pose(&self, upper: &Pose) -> Pose {
        let mut p = *upper;
        let (ikr, ikl) = (p.ikr, p.ikl);
        self.arm_ik(&mut p, ikr, ikl);
        self.apply_twist(&mut p);
        p
    }

    /// Amostra um clipe com interpolação entre quadros.
    pub fn sample(&self, name: &str, t: f32) -> Pose {
        let c = self.clip(name);
        let n = c.frames.len();
        if n == 1 {
            return c.frames[0];
        }
        let (i0, i1, u) = if c.kind == 2 || c.kind == 4 {
            let f = (t * 30.0).clamp(0.0, (n - 1) as f32);
            let i0 = f.floor() as usize;
            (i0, (i0 + 1).min(n - 1), f - i0 as f32)
        } else {
            let f = (t / c.dur).rem_euclid(1.0) * n as f32;
            let i0 = (f.floor() as usize) % n;
            (i0, (i0 + 1) % n, f - f.floor())
        };
        lerp_pose(&c.frames[i0], &c.frames[i1], u)
    }

    /// Composição final (mesma ordem de `runtime.compose2` no Python).
    pub fn compose(&self, lower: &Pose, upper: &Pose, aim_yaw: f32, aim_pitch: f32, pr: &Procedural) -> Pose {
        let mut p = *upper;
        p.hips = lower.hips;
        for &i in LOWER.iter() {
            p.rot[i] = lower.rot[i];
        }
        // 1) giro das pernas + queda do quadril
        if pr.legs_yaw.abs() > 1e-6 {
            let r = Quat::from_rotation_y(pr.legs_yaw);
            p.rot[HIPS] = r * p.rot[HIPS];
            let hx = r * Vec3::new(p.hips.x, 0.0, p.hips.z);
            p.hips = Vec3::new(hx.x, p.hips.y, hx.z);
        }
        p.hips.y += pr.hips_dy;
        // 2) pés no terreno
        if let Some((dl, dr)) = pr.feet {
            self.foot_ground(&mut p, dl, dr);
        }
        // 3) balanço do passo e inclinação
        if pr.bob_amt > 0.0 {
            let s = (2.0 * std::f32::consts::PI * pr.bob_phase).sin();
            let s2 = (4.0 * std::f32::consts::PI * pr.bob_phase).sin();
            let a = pr.bob_amt;
            p.rot[SPINE1] *= ypr((4.0 * a * s).to_radians(), (1.5 * a * s2).to_radians(), (3.0 * a * s).to_radians());
        }
        if pr.lean_roll.abs() + pr.lean_pitch.abs() > 1e-6 {
            self.pre_rotate_chain(&mut p, &[SPINE], Quat::from_rotation_x(pr.lean_pitch) * Quat::from_rotation_z(pr.lean_roll));
        }
        // 4) mira + cabeça
        let (aimw, aimoff) = (p.aimw, p.aimoff);
        self.aim_correct(&mut p, aim_dir(aim_yaw, aim_pitch - aimoff.to_radians()), aimw);
        self.head_look(&mut p, aim_dir(aim_yaw, aim_pitch), 0.5 * aimw + 0.2);
        // 5) atraso da arma + reação a tiro
        let qs = ypr(pr.sway_yaw, pr.sway_pitch, 0.0) * axis_angle(pr.flinch);
        if qs.w.abs() < 0.999_999 {
            self.pre_rotate_chain(&mut p, &[SPINE1, SPINE2], qs);
        }
        if pr.flinch.length() > 1e-6 {
            self.pre_rotate_chain(&mut p, &[NECK, HEAD], axis_angle(pr.flinch * 0.6));
        }
        // 6) recuo
        if pr.recoil > 0.0 {
            let f = self.fk(&p);
            let par = PARENT[SPINE2] as usize;
            let kick = Quat::from_rotation_x(-pr.recoil * 3.5f32.to_radians());
            p.rot[SPINE2] = f.gr[par].inverse() * (kick * f.gr[SPINE2]);
            p.wpos += p.wrot * Vec3::new(0.0, 0.004 * pr.recoil, -0.03 * pr.recoil);
            p.wrot *= Quat::from_rotation_x(-pr.recoil * 2.5f32.to_radians());
        }
        // 7) mãos na arma + torção do antebraço
        let (ikr, ikl) = (p.ikr, p.ikl);
        self.arm_ik(&mut p, ikr, ikl);
        self.apply_twist(&mut p);
        p
    }
}

fn nlerp(a: Quat, b: Quat, t: f32) -> Quat {
    let b = if a.dot(b) < 0.0 { -b } else { b };
    (a * (1.0 - t) + b * t).normalize()
}

pub fn lerp_pose(a: &Pose, b: &Pose, t: f32) -> Pose {
    let mut p = *a;
    for i in 0..NB {
        p.rot[i] = nlerp(a.rot[i], b.rot[i], t);
    }
    p.hips = a.hips.lerp(b.hips, t);
    p.wpos = a.wpos.lerp(b.wpos, t);
    p.wrot = nlerp(a.wrot, b.wrot, t);
    p.mpos = a.mpos.lerp(b.mpos, t);
    p.mrot = nlerp(a.mrot, b.mrot, t);
    p.ikl = a.ikl + (b.ikl - a.ikl) * t;
    p.ikr = a.ikr + (b.ikr - a.ikr) * t;
    p.aimw = a.aimw + (b.aimw - a.aimw) * t;
    p.aimoff = a.aimoff + (b.aimoff - a.aimoff) * t;
    p
}

/// Mistura ponderada de N poses (pesos > 0).
pub fn blend(poses: &[(Pose, f32)]) -> Pose {
    let mut acc: Option<(Pose, f32)> = None;
    for (p, w) in poses.iter() {
        if *w <= 1e-4 {
            continue;
        }
        acc = Some(match acc {
            None => (*p, *w),
            Some((a, aw)) => {
                let tot = aw + w;
                (lerp_pose(&a, p, w / tot), tot)
            }
        });
    }
    acc.map(|(p, _)| p).unwrap_or_default()
}
