//! Para testar no PC: `cargo run --release --example desktop`
//! WASD move, mouse mira (clique para capturar), botão esquerdo atira,
//! direito mira, R recarrega, Espaço pula, C agacha, Shift corre.
fn main() {
    chimera_strike::run_app();
}
